﻿namespace MyLibAzure.Azure_Cost_Cli.Commands;
public enum TimeframeType
{
    BillingMonthToDate,
    Custom,
    MonthToDate,
    TheLastBillingMonth,
    TheLastMonth,
    WeekToDate,
}