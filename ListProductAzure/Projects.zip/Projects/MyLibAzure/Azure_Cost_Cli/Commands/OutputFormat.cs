﻿namespace MyLibAzure.Azure_Cost_Cli.Commands;
public enum OutputFormat
{
    Console,
    Json,
    Markdown,
    Text,
    Jsonc,
    Csv
}