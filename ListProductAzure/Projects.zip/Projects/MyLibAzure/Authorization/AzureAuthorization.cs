﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MyLibAzure.Authorization
{
    public class AzureAuthorization
    {
        private readonly string _tenantId;
        private readonly string _clientId;
        private readonly string _clientSecret;
        private readonly string _subscriptionId;
        private readonly HttpClient _httpClient;

        public AzureAuthorization()
        {
        }

        /// <summary>
        /// Processo acesso Via TenanID via oauth2/v2.0/token
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="clientId"></param>
        /// <param name="clientSecret"></param>
        /// <param name="subscriptionId"></param>
        public AzureAuthorization(string tenantId, string clientId, string clientSecret, string subscriptionId)
        {
            _tenantId = tenantId;
            _clientId = clientId;
            _clientSecret = clientSecret;
            _subscriptionId = subscriptionId;
            _httpClient = new HttpClient();
        }

        /// <summary>
        ///  Processo de autenticacao ao Modulo de Bill via aplicacao
        /// </summary>
        /// <returns>Retorma token de autenticacao para transaçao</returns>
        public async Task<string> GetAccessTokenAsync()
        {
            var url = $"https://login.microsoftonline.com/{_tenantId}/oauth2/v2.0/token";
            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials"),
                new KeyValuePair<string, string>("client_id", _clientId),
                new KeyValuePair<string, string>("client_secret", _clientSecret),
                new KeyValuePair<string, string>("scope", "https://management.azure.com/.default")
            });

            var response = await _httpClient.PostAsync(url, content);
            response.EnsureSuccessStatusCode();
            var responseBody = await response.Content.ReadAsStringAsync();
            var tokenResponse = JsonSerializer.Deserialize<JsonElement>(responseBody);
            return tokenResponse.GetProperty("access_token").GetString();
        }

        /// <summary>
        ///  Processo de Requisicao de chamadas de Get Azure
        /// </summary>
        /// <param name="p_url"></param>
        /// <param name="accessToken"></param>
        /// <returns></returns>
        public async Task<string> GetAPI(string p_url,string accessToken)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            var response = await _httpClient.GetAsync(p_url);
            response.EnsureSuccessStatusCode();
            var responseBody = await response.Content.ReadAsStringAsync();
            return responseBody;
        }

        /// <summary>
        ///  Processo de GET Simples chama de URL 
        /// </summary>
        /// <param name="p_url"></param>
        /// <returns> Retorna </returns>
        public async Task<string> GetAPISimples(string p_url)
        {
            var response = await _httpClient.GetAsync(p_url);
            response.EnsureSuccessStatusCode();
            var responseBody = await response.Content.ReadAsStringAsync();
            return responseBody;
        }
    }
}
