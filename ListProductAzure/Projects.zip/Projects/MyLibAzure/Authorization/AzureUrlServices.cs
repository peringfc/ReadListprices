﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibAzure.Authorization
{

    /// <summary>
    ///  Lista de servicos disponivels Azure
    /// </summary>
    public class AzureUrlServices
    {
        string _url_price = "https://prices.azure.com";
        string _url_service = "https://prices.azure.com";

        /// <summary>
        ///  List de service Primario
        /// </summary>
        /// <returns></returns>
        public string List_price_primary()
        { 
            return _url_price+ "/api/retail/prices?api-version=2023-01-01-preview&meterRegion='primary'";
        }
    }
}
