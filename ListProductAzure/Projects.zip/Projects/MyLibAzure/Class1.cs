﻿namespace MyLibAzure
{
    public class Class1
    {

    }
}
