﻿using MyLibAzure.Authorization;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace MyLibAzure.Billing
{
    public class ManagedResourcesAzurePrices
    {
        AzureAuthorization oAzureAuthorization = new AzureAuthorization();
        AzureUrlServices oAzureUrlServices = new AzureUrlServices();
        /// <summary>
        ///  Carregar List de Servicos e Preços Azure
        /// </summary>
        /// <returns> Retorna Lista de servícos</returns>
        public async Task<List<ManagedResourcesAzurePrices>> ManagedResourcesAsync()
        { 
            List<ManagedResourcesAzurePrices> ListManagedResourcesAzurePrices = new List<ManagedResourcesAzurePrices>();
            try
            {
                var response = await oAzureAuthorization.GetAPISimples(oAzureUrlServices.List_price_primary());
                ManagedResourcesAzurePrices myManagedResourcesAzurePrices =
                    JsonConvert.DeserializeObject<ManagedResourcesAzurePrices>(response);

            }
            catch (Exception)
            {
                throw;
            }
            return ListManagedResourcesAzurePrices;
        }
        /// <summary>
        /// Lista de Servicos Secundarios
        /// </summary>
        /// <param name="p_url"></param>
        /// <returns></returns>
        public async Task<List<ManagedResourcesAzurePrices>> ManagedResourcesAsyncSecundary(string p_url)
        {
            List<ManagedResourcesAzurePrices> ListManagedResourcesAzurePrices = new List<ManagedResourcesAzurePrices>();
            try
            {
                var response = await oAzureAuthorization.GetAPISimples(p_url);
                ManagedResourcesAzurePrices myManagedResourcesAzurePrices =
                    JsonConvert.DeserializeObject<ManagedResourcesAzurePrices>(response);

            }
            catch (Exception)
            {
                throw;
            }
            return ListManagedResourcesAzurePrices;
        }
    }
}
