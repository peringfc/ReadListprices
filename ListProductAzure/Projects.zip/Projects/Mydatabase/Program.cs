﻿namespace Mydatabase
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("+------------------------------------------+");
            Console.WriteLine("| Mydatabase                               |");
            Console.WriteLine("+------------------------------------------+");
        }
    }
}
