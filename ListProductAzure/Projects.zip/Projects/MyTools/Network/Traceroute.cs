﻿using MyTools.Network;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace MyTools.Network
{
    public class Traceroute
    {
        public async Task<List<string>> PerformTracerouteAsync(string url)
        {
            List<string> results = new List<string>();
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = RuntimeInformation.IsOSPlatform(OSPlatform.Windows) ? "tracert" : "traceroute",
                Arguments = url,
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using (Process process = new Process { StartInfo = startInfo })
            {
                process.Start();
                using (var reader = process.StandardOutput)
                {
                    string line;
                    while ((line = await reader.ReadLineAsync()) != null)
                    {
                        results.Add(line);
                    }
                }
                await process.WaitForExitAsync();
            }

            return results;
        }
    }
}


//Exemplo
//class Program
//{
//    static async Task Main()
//    {
//        Console.WriteLine("Digite uma URL ou endereço IP para realizar o traceroute:");
//        string url = Console.ReadLine();
//        Traceroute traceroute = new Traceroute();
//        List<string> tracerouteResults = await traceroute.PerformTracerouteAsync(url);
//        Console.WriteLine("Resultados do Traceroute:");
//        foreach (string result in tracerouteResults)
//        {
//            Console.WriteLine(result);
//        }
//    }
//}