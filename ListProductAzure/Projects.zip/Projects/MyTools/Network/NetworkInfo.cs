﻿using System;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace MyTools.Network
{
    /// <summary>
    ///  Coleta informa dos ip em que a maquina se encontra
    /// </summary>
    public class NetworkInfo
    {

        /// <summary>
        ///  Retorna dados da coleta do IPs da maquinas
        /// </summary>
        /// <returns>retorna uma lista de IPs</returns>
        public List<string> GetIPAddresses()
        {
            List<string> ipAddresses = new List<string>();
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                IPInterfaceProperties properties = ni.GetIPProperties();
                foreach (UnicastIPAddressInformation ip in properties.UnicastAddresses)
                {
                    if (ip.Address.AddressFamily == AddressFamily.InterNetwork ||
                        ip.Address.AddressFamily == AddressFamily.InterNetworkV6)
                    {
                        ipAddresses.Add(ip.Address.ToString());
                    }
                }
            }
            return ipAddresses;
        }
    }
}
