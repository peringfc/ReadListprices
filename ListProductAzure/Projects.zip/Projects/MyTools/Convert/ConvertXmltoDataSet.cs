﻿using System;
using System.Data;
using System.IO;
using System.Xml;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTools.Convert
{

    /// <summary>
    ///  Class de manipulação de XML Conversão de XML para DataSet e DataSet para XML 
    /// </summary>
    public class ConvertXmltoDataSet
    {
        /// <summary>
        ///  Conversor de XML para DataSet e necessario apenas informa o XML para ser convertido para DataSet
        /// </summary>
        /// <param name="xmlData"> String com o XML</param>
        /// <returns></returns>
        public DataSet ConvertXMLToDataSet(string xmlData)
        {
            StringReader  stream = null;
            XmlTextReader reader = null;
            try
            {
                DataSet xmlDS = new DataSet();
                stream = new StringReader(xmlData);
                // Load the XmlTextReader from the stream
                reader = new XmlTextReader(stream);
                xmlDS.ReadXml(reader);
                return xmlDS;
            }
            catch
            {
                return null;
            }
            finally
            {
                if (reader != null) reader.Close();
            }
        }

        /// <summary>
        ///  Converte Dataset em XML ultilizando unico de formatação Universal
        /// </summary>
        /// <param name="xmlDS"> Informe o DataSet para que seja convertido</param>
        /// <returns></returns>
        public string ConvertDataSetToXML(DataSet xmlDS)
        {
            MemoryStream stream = null;
            XmlTextWriter writer = null;
            try
            {
                stream = new MemoryStream();
                // Load the XmlTextReader from the stream
                writer = new XmlTextWriter(stream, Encoding.Unicode);
                // Write to the file with the WriteXml method.
                xmlDS.WriteXml(writer);
                int count = (int)stream.Length;
                byte[] arr = new byte[count];
                stream.Seek(0, SeekOrigin.Begin);
                stream.Read(arr, 0, count);
                UnicodeEncoding utf = new UnicodeEncoding();
                return utf.GetString(arr).Trim();
            }
            catch
            {
                return String.Empty;
            }
            finally
            {
                if (writer != null) writer.Close();
            }
        }
    }

}
