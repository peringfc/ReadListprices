﻿using System;
using System.Data;
using Newtonsoft.Json;

namespace MyTools.Convert
{
    public class JSONtoXML
    {
        /// <summary>
        /// Convert Json para XML
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        public String Convert(String json)
        {
            try
            {
                DataSet oRetorno = JsonConvert.DeserializeObject<DataSet>(json);
                return oRetorno.GetXml();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

}
