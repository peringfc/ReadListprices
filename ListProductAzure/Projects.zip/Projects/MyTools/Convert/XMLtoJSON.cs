﻿using System;
using System.Data;
using Newtonsoft.Json;

namespace MyTools.Convert
{
    public class XMLtoJSON
    {
        /// <summary>
        /// Conversao de um dataset para uma estrutura JSON
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        public String Convert(DataSet dataSet)
        {
            try
            {
                string json = JsonConvert.SerializeObject(dataSet, Formatting.Indented);
                return json;
            }
            catch (Exception)
            {
                throw;
            }

        }

    }

}
