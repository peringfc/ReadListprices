﻿using MyTools.SSH.Structure;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTools.SSH
{
    public class Transation
    {
        /// <summary>
        ///  Conexão via SSH no servidor Informaçoes para conexão e comando de execução em um servidor SSH
        /// </summary>
        /// <param name="p_struTransation"></param>
        /// <returns> Retorna o dados do retorno de exeução do Servidor.</returns>
        private String ExecuteCMD(StruTransation p_struTransation)
        {
            String oReturn = "No Execute! Cmd.";
            try
            {
                String oUserSSH = p_struTransation.UserSSH;
                String oPwdSSH = p_struTransation.PwdSSH;
                String oServerSSH = p_struTransation.ServerSSH;
                int oPort = p_struTransation.Port;

                using (var client = new SshClient( 
                           oServerSSH,
                           oPort, 
                           oUserSSH, 
                           oPwdSSH))
                {
                    client.Connect();
                    client.RunCommand(p_struTransation.Command);
                    oReturn = client.ToString();
                    client.Disconnect();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return oReturn;
        }
    }
}
