﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTools.SSH.Structure
{
    public class StruMemoryUsageInfo
    {
        public string Total { get; set; }
        public string Used { get; set; }
        public string Free { get; set; }
        public string Shared { get; set; }
        public string Buffers { get; set; }
        public string Cached { get; set; }
        public string Available { get; set; }
    }
}
