﻿
namespace MyTools.SSH.Structure
{
    public class StruDiskUsageInfo
    {
        public string? Filesystem { get; set; }
        public string? Size { get; set; }
        public string? Used { get; set; }
        public string? Available { get; set; }
        public string? UsePercentage { get; set; }
        public string? MountedOn { get; set; }
    }
}
