﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTools.SSH.Structure
{
    public class StruTopProcessInfo
    {
        public string? PID { get; set; }
        public string? User { get; set; }
        public string? PR { get; set; }
        public string? NI { get; set; }
        public string? VIRT { get; set; }
        public string? RES { get; set; }
        public string? SHR { get; set; }
        public string? S { get; set; }
        public string? CPU { get; set; }
        public string? MEM { get; set; }
        public string? TIME { get; set; }
        public string? Command { get; set; }
    }
}
