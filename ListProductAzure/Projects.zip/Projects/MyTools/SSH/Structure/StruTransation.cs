﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTools.SSH.Structure
{
    public class StruTransation
    {
        public string UserSSH { get; set; }
        public string PwdSSH { get; set; }
        public string ServerSSH { get; set; }
        public string Command { get; set; }
        public int Port { get; set; }

        /// <summary>
        ///  Estrutura de dados para solicitaçäo de dados para conexáo em sercidores SSH
        /// </summary>
        /// <param name="userSSH"> Usuario de conexão no Servidor</param>
        /// <param name="pwdSSH"> Senha de acesso ao servidor</param>
        /// <param name="serverSSH"> Endereco do conexão do servidor </param>
        /// <param name="command"> Commando que sera executado no servidor </param>
        /// <param name="Port"> Numero da Porta de conexão </param>
        public StruTransation(string userSSH,
                              string pwdSSH,
                              string serverSSH,
                              string command,
                              int Port)
        {
            this.UserSSH   = userSSH;
            this.PwdSSH    = pwdSSH;
            this.ServerSSH = serverSSH;
            this.Command   = command;
            this.Port = Port;
        }
    }

}
