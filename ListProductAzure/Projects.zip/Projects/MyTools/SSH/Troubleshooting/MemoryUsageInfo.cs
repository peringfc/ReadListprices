﻿using MyTools.SSH.Structure;
using MyTools.SSH.Troubleshooting;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTools.SSH.Troubleshooting
{
    public class MemoryUsageInfo(string host, string username, string password)
    {
        private readonly string _host = host;
        private readonly string _username = username;
        private readonly string _password = password;

        public StruMemoryUsageInfo GetMemoryUsage()
        {
            StruMemoryUsageInfo memoryUsageInfo = null;

            using (var client = new SshClient(_host, _username, _password))
            {
                client.Connect();

                // Executa o comando free -h para verificar o uso de memória
                var cmd = client.CreateCommand("free -h");
                var result = cmd.Execute();

                // Processa a saída do comando
                var lines = result.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

                if (lines.Length >= 2)
                {
                    var parts = lines[1].Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length >= 7)
                    {
                        memoryUsageInfo = new StruMemoryUsageInfo
                        {
                            Total = parts[1],
                            Used = parts[2],
                            Free = parts[3],
                            Shared = parts[4],
                            Buffers = parts[5],
                            Cached = parts[6],
                            Available = parts[7]
                        };
                    }
                }

                client.Disconnect();
            }

            return memoryUsageInfo;
        }
    }
}


//exemplo

//    class Program
//{
//    static void Main()
//    {
//        Console.WriteLine("Informe o host do servidor SSH:");
//        string host = Console.ReadLine();
//        Console.WriteLine("Informe o nome de usuário:");
//        string username = Console.ReadLine();
//        Console.WriteLine("Informe a senha:");
//        string password = Console.ReadLine();

//        var sshClient = new SSHClient(host, username, password);
//        MemoryUsageInfo memoryUsage = sshClient.GetMemoryUsage();

//        if (memoryUsage != null)
//        {
//            Console.WriteLine("Uso de memória:");
//            Console.WriteLine($"Total: {memoryUsage.Total}, Usado: {memoryUsage.Used}, Livre: {memoryUsage.Free}, Compartilhado: {memoryUsage.Shared}, Buffers: {memoryUsage.Buffers}, Cache: {memoryUsage.Cached}, Disponível: {memoryUsage.Available}");
//        }
//        else
//        {
//            Console.WriteLine("Não foi possível obter informações de uso de memória.");
//        }
//    }
//}