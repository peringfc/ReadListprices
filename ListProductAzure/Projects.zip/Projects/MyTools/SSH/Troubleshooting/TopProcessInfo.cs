﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.JavaScript;
using MyTools.SSH.Structure;
using MyTools.SSH.Troubleshooting;
using Renci.SshNet;

namespace MyTools.SSH.Troubleshooting
{
    public class TopProcessInfo
    {
        private readonly string _host;
        private readonly string _username;
        private readonly string _password;

        public TopProcessInfo(string host, string username, string password)
        {
            _host = host;
            _username = username;
            _password = password;
        }

        public List<StruTopProcessInfo> ExecuteTopCommand()
        {
            var processInfos = new List<StruTopProcessInfo>();
            using (var client = new SshClient(_host, _username, _password))
            {
                client.Connect();
                // Executa o comando top e captura a saída
                var cmd = client.CreateCommand("top -b -n 1");
                var result = cmd.Execute();
                // Processa a saída do comando
                var lines = result.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                // Ignora as duas primeiras linhas (cabeçalho do top)
                for (int i = 7; i < lines.Length; i++)
                {
                    var parts = lines[i].Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length >= 12)
                    {
                        var processInfo = new StruTopProcessInfo
                        {
                            PID = parts[0],
                            User = parts[1],
                            PR = parts[2],
                            NI = parts[3],
                            VIRT = parts[4],
                            RES = parts[5],
                            SHR = parts[6],
                            S = parts[7],
                            CPU = parts[8],
                            MEM = parts[9],
                            TIME = parts[10],
                            Command = string.Join(" ", parts, 11, parts.Length - 11)
                        };
                        processInfos.Add(processInfo);
                    }
                }
                client.Disconnect();
            }
            return processInfos;
        }
    }
}
// Exemplo
//class Program
//{
//    static void Main()
//    {
//        Console.WriteLine("Informe o host do servidor SSH:");
//        string host = Console.ReadLine();
//        Console.WriteLine("Informe o nome de usuário:");
//        string username = Console.ReadLine();
//        Console.WriteLine("Informe a senha:");
//        string password = Console.ReadLine();

//        var sshClient = new SSHClient(host, username, password);
//        List<TopProcessInfo> processInfos = sshClient.ExecuteTopCommand();

//        Console.WriteLine("Processos em execução:");
//        foreach (var info in processInfos)
//        {
//            Console.WriteLine($"PID: {info.PID}, User: {info.User}, CPU: {info.% CPU}, Mem: {info.% MEM}, Command: {info.Command}");
//        }
//    }
//}