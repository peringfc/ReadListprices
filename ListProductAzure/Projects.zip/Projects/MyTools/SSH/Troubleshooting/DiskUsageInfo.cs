﻿using MyTools.SSH.Structure;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.JavaScript;
using System.Text;
using System.Threading.Tasks;

namespace MyTools.SSH.Troubleshooting
{
    public class DiskUsageInfo(string host, string username, string password)
    {
        private readonly string _host = host;
        private readonly string _username = username;
        private readonly string _password = password;

        public List<StruDiskUsageInfo> GetDiskUsage()
        {
            var diskUsages = new List<StruDiskUsageInfo>();

            using (var client = new SshClient(_host, _username, _password))
            {
                client.Connect();

                // Executa o comando df -h para verificar o uso do espaço em disco
                var cmd = client.CreateCommand("df -h");
                var result = cmd.Execute();

                // Processa a saída do comando
                var lines = result.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

                // Ignora a linha do cabeçalho
                for (int i = 1; i < lines.Length; i++)
                {
                    var parts = lines[i].Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length >= 6)
                    {
                        var diskUsageInfo = new StruDiskUsageInfo
                        {
                            Filesystem = parts[0],
                            Size = parts[1],
                            Used = parts[2],
                            Available = parts[3],
                            UsePercentage = parts[4],
                            MountedOn = parts[5]
                        };
                        diskUsages.Add(diskUsageInfo);
                    }
                }

                client.Disconnect();
            }

            return diskUsages;
        }
    }
}

//    exemplo
//    class Program
//{
//    static void Main()
//    {
//        Console.WriteLine("Informe o host do servidor SSH:");
//        string host = Console.ReadLine();
//        Console.WriteLine("Informe o nome de usuário:");
//        string username = Console.ReadLine();
//        Console.WriteLine("Informe a senha:");
//        string password = Console.ReadLine();

//        var sshClient = new SSHClient(host, username, password);
//        List<DiskUsageInfo> diskUsages = sshClient.GetDiskUsage();

//        Console.WriteLine("Uso do espaço em disco:");
//        foreach (var usage in diskUsages)
//        {
//            Console.WriteLine($"Filesystem: {usage.Filesystem}, Size: {usage.Size}, Used: {usage.Used}, Available: {usage.Available}, Use Percentage: {usage.UsePercentage}, Mounted On: {usage.MountedOn}");
//        }
//    }
//}