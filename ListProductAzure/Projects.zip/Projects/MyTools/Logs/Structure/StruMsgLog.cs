﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTools.Logs.Structure
{
    public class StruMsgLog
    {
        public string? id_message { get; set; }
        public string? id_app { get; set; }
        public DateTime dtcreate { get; set; }
        public string? type_message { get; set; }
        public string? CodeError { get; set; }
        public string? CodeAPP { get; set; }
        public string? text_message { get; set; }
        public string? MessageAPP { get; set; }
        public DateTime DtStartTransation { get; set; }
        public DateTime DtEndTransation { get; set; }
    }
}
