﻿using System;
using System.IO;

namespace MyTools.Files
{
    public class FileIO
    {
        /// <summary>
        /// Verifica a existencia do arquivo retornando o se o arquivo existe ou nao 
        /// </summary>
        /// <param name="p_FileName"></param>
        /// <returns>(True) para a existencia do arquivo e
        ///          (False) para nao existencia do arquivo
        /// </returns>
        public bool FileExiste(String p_FileName)
        {
            bool oRetorn = false;
            try
            {
                oRetorn = File.Exists(p_FileName);
            }
            catch (Exception)
            {
                throw;
            }
            return oRetorn;
        }

        /// <summary>
        ///  Delete arquivo e necessario informa o path e nome do arquivo para que seja deletado
        ///  o processo deletara o arquivo simplesmente
        /// </summary>
        /// <param name="p_FileName"> Nome do Arquivo que devera ser apagado.</param>
        /// 
        public void DeleteFile(String p_FileName)
        {
            try
            {
                File.Delete(p_FileName);
            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        ///  Processo de copia de arquivos 
        /// </summary>
        /// <param name="p_Dir_Source">Diretorio de origem do arquivo</param>
        /// <param name="p_FileNameSource">Arquivo de Origem de sera copiado</param>
        /// <param name="p_Dir_Destiny">Diretorio de Destino para a copia do arquivo</param>
        /// <param name="p_FileNameDestiny">Arquivo de destino</param>
        ///
		public void CopyFile(
                                String p_Dir_Source,
                                String p_FileNameSource,
                                String p_Dir_Destiny,
                                String p_FileNameDestiny
                                )
        {
            try
            {
                File.Copy(Path.Combine(p_Dir_Source, p_FileNameSource), Path.Combine(p_Dir_Destiny, p_FileNameDestiny));
            }
            catch (IOException)
            {
                throw;
            }
        }

        /// <summary>
        /// Processo para salvar um arquivo
        /// </summary>
        /// <param name="p_PathFilename"> Informe Caminho (Path) e nome do arquivo </param>
        /// <param name="p_Text"> informe texto que deverá ser gravado no arquivo</param>
        public void SalveFile(String p_PathFilename, String p_Text)
        {
            try
            {
                File.WriteAllText(p_PathFilename, p_Text);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// processo de Inclusão de informaçoes em um arquivo existente caso não exsita o arquivos ele
        /// sera criado com o nome informado e estara gravando os dados informado para gravação.
        /// </summary>
        /// <param name="p_PathFilename"> Caminho e nome do arquivo que sera adicinado os dados caso não exsite sera criado.</param>
        /// <param name="p_Text"> Teste a ser incluso nos arquivo informado.</param>
        public void AppendFile(String p_PathFilename, String p_Text)
        {
            try
            {
                if (!File.Exists(p_PathFilename))
                {
                    File.WriteAllText(p_PathFilename, p_Text + Environment.NewLine);
                }
                else
                {
                    File.AppendAllText(p_PathFilename, p_Text + Environment.NewLine);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

}
