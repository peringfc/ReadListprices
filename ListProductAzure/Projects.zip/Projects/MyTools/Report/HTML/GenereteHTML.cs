﻿using MyTools.Files;
using System;
using System.Data;

namespace MyTools.Report.HTML
{
    public class GenereteHTML
    {
        /// <summary>
        ///  Instaciando o Conversor de XML
        /// </summary>
        public Convert.ConvertXmltoDataSet oConvertXml = new Convert.ConvertXmltoDataSet();

        /// <summary>
        ///  Gerar Html com Dicionario de dados 
        /// </summary>
        /// <param name="p_xml"> XML em formato para processo </param>
        /// <param name="p_dicionario"> nome do dicionario </param>
        /// <param name="p_type_html"> Tipo do Formato utilizado  </param>
        /// <returns></returns>
        public String Convert_XML_html(String p_xml,
                                       String p_dicionario,
                                       String p_type_html)
        {
            String oRetorno = null;
            /// Leitura do XML e conversão para HTML
            try
            {
                ///
                /// Convertendo o XML para um DataSet para processamento
                /// 
                DataSet oReadXML = new DataSet();
                oReadXML = oConvertXml.ConvertXMLToDataSet(p_xml);

                if (oReadXML != null)
                {
                    // Inicializando processo de escrita de HTML
                    switch (p_type_html.ToUpper())
                    {
                        case "SIMPLES":
                            break;
                        default:
                            oRetorno = "<h1> Unidentified html type..<h1>" + DateTime.Now.ToString();
                            break;
                    }
                }

            }
            catch (Exception)
            {  /// Caso ocorra algum erro estarei retornado o processo para metodo executor
                throw;
            }
            return oRetorno;
        }

        public string write_html_simples(DataSet p_dataSet,
                                         String p_Title,
                                         String p_Languagem)
        {
            String oReturn_html = "<!DOCTYPE html><html lang='" + p_Languagem + "'><head><title>" + p_Title + "</title><meta charset='utf-8'>" +
                                  "<meta name= 'viewport' content = 'width=device-width, initial-scale=1'>" +
                                  "<link rel = 'stylesheet' href = 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css [maxcdn.bootstrapcdn.com]'>" +
                                  "<script src = 'https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js [ajax.googleapis.com]'></script>" +
                                  "<script src = 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js [maxcdn.bootstrapcdn.com]'></script>" +
                                  "</head ><body>";

            int oLines = 0;
            int oHeard = 0;

            foreach (DataTable table in p_dataSet.Tables)
            {
                oLines = table.Rows.Count;
                if (oLines == 1)
                {
                    ///
                    /// Gera Detail View para um linha
                    /// 
                    oReturn_html = oReturn_html + "<div class='container - fluid'><h3>" + table.TableName.ToString() + "</h3> <div class='row'>";
                    foreach (DataRow row in table.Rows)
                    {
                        foreach (DataColumn column in table.Columns)
                        {
                            oReturn_html = oReturn_html + "<div class='col-sm-4' style='background-color:lavender;'>" + column.ColumnName.ToString() + "</div>";
                            if (row[column].ToString().Trim().TrimEnd().TrimStart() == "")
                            {
                                oReturn_html = oReturn_html + "<div class='col-sm-8' style='background-color:lavenderblush;'> - </div>";
                            }
                            else
                            {
                                oReturn_html = oReturn_html + "<div class='col-sm-8' style='background-color:lavenderblush;'>" + row[column].ToString() + "</div>";
                            }
                        }
                    }
                    oReturn_html = oReturn_html + "</div></div>";
                }
                else
                {
                    /// Gera Tabela
                    /// 
                    oReturn_html = oReturn_html + " ";
                    // foreach (DataRow row in table.Rows)
                    // {
                    //foreach (DataColumn column in table.Columns)
                    //{
                    if (oHeard == 0)
                    {
                        oReturn_html = oReturn_html + "<div class='container'><h2>" +
                //                                table.TableName.ToString() + "</h2><table class='table table-striped'>";
                table.TableName.ToString() + "</h2><table with= '100%' border='1'>";
                        /// Header de Table
                        //foreach (DataRow row_h in table.Rows)
                        //{
                        oReturn_html = oReturn_html + "<thead>";
                        foreach (DataColumn column_h in table.Columns)
                        {
                            oReturn_html = oReturn_html + "<th>" + column_h.ColumnName.ToString() + "</th>";
                        }
                        oReturn_html = oReturn_html + "</tr></thead>";
                        oHeard++;
                        //}
                    }
                    foreach (DataRow row_g in table.Rows)
                    {
                        oReturn_html = oReturn_html + "<tr>";
                        foreach (DataColumn column_g in table.Columns)
                        {
                            oReturn_html = oReturn_html + "<td>" + row_g[column_g].ToString() + "</td>";
                        }
                        oReturn_html = oReturn_html + "</tr>";
                    }
                    //}

                }
                oReturn_html = oReturn_html + "</table></div>";
                //}
            }
            oReturn_html = oReturn_html + "<div><h6>" + DateTime.Now.ToString() + "</h6></div>";
            return oReturn_html;
        }


        public string Forms_html_simples(DataSet p_dataSet,
                                         String p_Title,
                                         String p_Title_sub,
                                         String p_Languagem,
                                         String p_dicionario)
        {

            String oReturn_html = "";

            String oHeard_html = "<!DOCTYPE html>" +
                                 "<html>" +
                                 "<head>" +
                                 "  <meta name = 'viewport' content = 'width=device-width, initial-scale=1'>" +
                                 "      <link rel = 'stylesheet' href = 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css [maxcdn.bootstrapcdn.com]' >" +
                                 "        <script src = 'https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js [ajax.googleapis.com]' ></script >" +
                                 "         <script src = 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js [maxcdn.bootstrapcdn.com]' ></script >" +
                                 "         </head>" +
                                 "         <body>" +
                                 "<div class='container'> " +
                                 "<h4>" + p_Title + "</h4>" +
                                 "<h5>" + p_Title_sub + "</h5>";
            int oLines = 0;
            int oHeard = 0;



            String oButton = "";
            String wTitule = null;
            foreach (DataTable table in p_dataSet.Tables)
            {
                oLines = table.Rows.Count;
                if (oLines != 0)
                {
                    if (oLines == 1)
                    {
                        ///
                        /// Gera Detail View para um linha
                        /// 

                        wTitule = search_xml_display(table.TableName.ToString(), table.TableName.ToString(), "TABLE", @p_dicionario);
                        if (wTitule != "-NO-")
                        {
                            oButton = oButton + "<button type='button' class='btn btn-default' data-toggle='collapse' data-target='#" + table.TableName.ToString() + "'>" + wTitule + "</button>";
                            // oReturn_html = oReturn_html + "<h3>" + wTitule + "</h3>";

                            foreach (DataRow row in table.Rows)
                            {
                                oReturn_html = oReturn_html + " <div class='well well-sm'>" +
                                             "<button type='button' class='btn btn-default' data-toggle='collapse' data-target='#" +
                                             table.TableName.ToString() + "'>" +
                                             wTitule + "</button> <div id='" +
                                             table.TableName.ToString() + "' class='collapse'> <table class='table table-striped'>";

                                foreach (DataColumn column in table.Columns)
                                {
                                    wTitule = search_xml_display(table.TableName.ToString(), column.ColumnName.ToString(), "FIELD", @p_dicionario);
                                    if (wTitule != "-NO-")
                                    {
                                        oReturn_html = oReturn_html + "<tr><td><b>" + wTitule + "</b></td>";
                                        if (row[column].ToString().Trim().TrimEnd().TrimStart() == "") { oReturn_html = oReturn_html + "<td> - </td>"; }
                                        else { oReturn_html = oReturn_html + "<td>" + row[column].ToString() + "</td></tr>"; }
                                    }
                                }
                            }
                            oReturn_html = oReturn_html + "</table></div></div>";
                        }
                    }
                    else
                    {
                        oReturn_html = oReturn_html + " ";
                        if (oHeard == 0)
                        {
                            wTitule = search_xml_display(table.TableName.ToString(), table.TableName.ToString(), "TABLE", @p_dicionario);

                            oButton = oButton + "<button type='button' class='btn btn-default' data-toggle='collapse' data-target='#" + table.TableName.ToString() + "'>" + wTitule + "</button>";

                            oReturn_html = oReturn_html + " <div class='well well-sm'> <a name='#" + table.TableName.ToString() + "'></a> <button type='button' class='btn btn-default' data-toggle='collapse' data-target='#" + table.TableName.ToString() + "'>" + wTitule + "</button> <div id='" + table.TableName.ToString() + "' class='collapse'>";
                            //oReturn_html = oReturn_html + "<div id='" + table.TableName.ToString() + "' class='collapse'>";
                            oReturn_html = oReturn_html + "<h2>" + wTitule + "</h2><table class='table table-striped'>";
                            oReturn_html = oReturn_html + "  <thead><tr>";
                            foreach (DataColumn column_h in table.Columns)
                            {
                                wTitule = search_xml_display(table.TableName.ToString(), column_h.ColumnName.ToString(), "FIELD", @p_dicionario);
                                if (wTitule != "-NO-")
                                {
                                    oReturn_html = oReturn_html + "<th>" + wTitule + "</th>";
                                }
                            }
                            oReturn_html = oReturn_html + "</tr></thead>";
                            oHeard++;
                        }
                        foreach (DataRow row_g in table.Rows)
                        {
                            oReturn_html = oReturn_html + "<tr>";
                            foreach (DataColumn column_g in table.Columns)
                            {
                                wTitule = search_xml_display(table.TableName.ToString(), column_g.ColumnName.ToString(), "FIELD", @p_dicionario);
                                if (wTitule != "-NO-")
                                {
                                    oReturn_html = oReturn_html + "<td>" + row_g[column_g].ToString() + "</td>";
                                }
                            }
                            oReturn_html = oReturn_html + "</tr>";
                        }
                        oReturn_html = oReturn_html + "</table></div></div>";
                        oHeard = 0;
                    }
                    //oReturn_html = oReturn_html + "<h6>" + DateTime.Now.ToString() + "</h6>";
                }
            }
            return oHeard_html + oButton + oReturn_html + "</div></body></html>";
        }


        /// <summary>
        ///  Retorno de HMTL no Formato Boot Strap
        /// </summary>
        /// <param name="p_dataSet"></param>
        /// <param name="p_Title"></param>
        /// <param name="p_Title_sub"></param>
        /// <param name="p_Languagem"></param>
        /// <param name="p_dicionario"></param>
        /// <returns></returns>
        public string dataset_html_bootStrap
                                        (DataSet p_dataSet,
                                         String p_Title,
                                         String p_Title_sub,
                                         String p_Languagem,
                                         String p_dicionario)
        {

            String oReturn_html = "";

            String oHeard_html = "<!DOCTYPE html>" +
                                 "<html>" +
                                 "<head>" +
                                 "  <meta name = 'viewport' content = 'width=device-width, initial-scale=1'>" +
                                 "      <link rel = 'stylesheet' href = 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css [maxcdn.bootstrapcdn.com]' >" +
                                 "        <script src = 'https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js [ajax.googleapis.com]' ></script >" +
                                 "         <script src = 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js [maxcdn.bootstrapcdn.com]' ></script >" +
                                 "         </head>" +
                                 "         <body>" +
                                 "<div class='container'> " +
                                 "<h4>" + p_Title + "</h4>" +
                                 "<h5>" + p_Title_sub + "</h5>";
            int oLines = 0;
            int oHeard = 0;

            //            String oButton = "";

            String wTitule = null;

            foreach (DataTable table in p_dataSet.Tables)
            {
                oLines = table.Rows.Count;
                if (oLines != 0)
                {
                    if (oLines == 1)
                    {
                        ///
                        /// Gera Detail View para um linha
                        /// 

                        wTitule = search_xml_display(table.TableName.ToString(), table.TableName.ToString(), "TABLE", @p_dicionario);
                        if (wTitule != "-NO-")
                        {
                            //oButton = oButton + "<button type='button' class='btn btn-default' data-toggle='collapse' data-target='#" + table.TableName.ToString() + "'>" + wTitule + "</button>";
                            // oReturn_html = oReturn_html + "<h3>" + wTitule + "</h3>";

                            foreach (DataRow row in table.Rows)
                            {
                                oReturn_html = oReturn_html + " <div class='well well-sm'>" +
                                             //"<button type='button' class='btn btn-default' data-toggle='collapse' data-target='#" +
                                             //table.TableName.ToString() + "'>" +
                                             //wTitule + "</button> <div id='" +
                                             //table.TableName.ToString() + "' class='collapse'> <table class='table table-striped'>";
                                             table.TableName.ToString() + "'<table class='table table-striped'>";

                                foreach (DataColumn column in table.Columns)
                                {
                                    wTitule = search_xml_display(table.TableName.ToString(), column.ColumnName.ToString(), "FIELD", @p_dicionario);
                                    if (wTitule != "-NO-")
                                    {
                                        oReturn_html = oReturn_html + "<tr><td><b>" + wTitule + "</b></td>";
                                        if (row[column].ToString().Trim().TrimEnd().TrimStart() == "") { oReturn_html = oReturn_html + "<td> - </td>"; }
                                        else { oReturn_html = oReturn_html + "<td>" + row[column].ToString() + "</td></tr>"; }
                                    }
                                }
                            }
                            oReturn_html = oReturn_html + "</table></div></div>";
                        }
                    }
                    else
                    {
                        oReturn_html = oReturn_html + " ";
                        if (oHeard == 0)
                        {
                            wTitule = search_xml_display(table.TableName.ToString(), table.TableName.ToString(), "TABLE", @p_dicionario);

                            //                            oButton = oButton + "<button type='button' class='btn btn-default' data-toggle='collapse' data-target='#" + table.TableName.ToString() + "'>" + wTitule + "</button>";

                            //oReturn_html = oReturn_html + " <div class='well well-sm'> <a name='#" + table.TableName.ToString() + "'></a> <button type='button' class='btn btn-default' data-toggle='collapse' data-target='#" + table.TableName.ToString() + "'>" + wTitule + "</button> <div id='" + table.TableName.ToString() + "' class='collapse'>";
                            //oReturn_html = oReturn_html + "<div id='" + table.TableName.ToString() + "' class='collapse'>";
                            oReturn_html = oReturn_html + "<h2>" + wTitule + "</h2><table class='table table-striped'>";
                            oReturn_html = oReturn_html + "  <thead><tr>";

                            foreach (DataColumn column_h in table.Columns)
                            {
                                wTitule = search_xml_display(table.TableName.ToString(), column_h.ColumnName.ToString(), "FIELD", @p_dicionario);
                                if (wTitule != "-NO-")
                                {
                                    oReturn_html = oReturn_html + "<th>" + wTitule + "</th>";
                                }
                            }
                            oReturn_html = oReturn_html + "</tr></thead>";
                            oHeard++;
                        }
                        foreach (DataRow row_g in table.Rows)
                        {
                            oReturn_html = oReturn_html + "<tr>";
                            foreach (DataColumn column_g in table.Columns)
                            {
                                wTitule = search_xml_display(table.TableName.ToString(), column_g.ColumnName.ToString(), "FIELD", @p_dicionario);
                                if (wTitule != "-NO-")
                                {
                                    oReturn_html = oReturn_html + "<td>" + row_g[column_g].ToString() + "</td>";
                                }
                            }
                            oReturn_html = oReturn_html + "</tr>";
                        }
                        oReturn_html = oReturn_html + "</table></div></div>";
                        oHeard = 0;
                    }
                    //oReturn_html = oReturn_html + "<h6>" + DateTime.Now.ToString() + "</h6>";
                }
            }
            //return oHeard_html + oButton + oReturn_html + "</div></body></html>";
            return oHeard_html + oReturn_html + "</div></body></html>";
        }

        public string dataset_html_simples(DataSet p_dataSet,
                                         String p_Title,
                                         String p_Title_sub,
                                         String p_Languagem,
                                         String p_dicionario)
        {
            String oReturn_html = "";
            String oHeard_html = "<!DOCTYPE html>" +
                                 "<html>" +
                                 "<head>" +
                                 " <style> " +
                                 " table { " +
                                 " font-family: arial, sans - serif; " +
                                 " border-collapse: collapse; " +
                                 " width: 100%; " +
                                 " }" +
                                 " td,th {" +
                                 " border: 1px solid #dddddd;" +
                                 " text-align: left;" +
                                 " padding: 8px;" +
                                 " }" +
                                 " tr:nth-child(even) { " +
                                 " background - color: #dddddd; " +
                                 " } " +
                                 " </style> " +
                                 " </head><body>" +
                                 "<div class='container'> " +
                                 "<h4>" + p_Title + "</h4>" +
                                 "<h5>" + p_Title_sub + "</h5>";
            int oLines = 0;
            int oHeard = 0;
            //            String oButton = "";
            String wTitule = null;
            foreach (DataTable table in p_dataSet.Tables)
            {
                oLines = table.Rows.Count;
                if (oLines != 0)
                {
                    if (oLines == 1)
                    {
                        ////// Gera Detail View para um linha /// 

                        wTitule = search_xml_display(table.TableName.ToString(), table.TableName.ToString(), "TABLE", @p_dicionario);
                        if (wTitule != "-NO-")
                        {
                            foreach (DataRow row in table.Rows)
                            {
                                oReturn_html = oReturn_html + "<table class='table table-striped'>";

                                foreach (DataColumn column in table.Columns)
                                {
                                    wTitule = search_xml_display(table.TableName.ToString(), column.ColumnName.ToString(), "FIELD", @p_dicionario);
                                    if (wTitule != "-NO-")
                                    {
                                        oReturn_html = oReturn_html + "<tr><td><b>" + wTitule + "</b></td>";
                                        if (row[column].ToString().Trim().TrimEnd().TrimStart() == "") { oReturn_html = oReturn_html + "<td> - </td>"; }
                                        else { oReturn_html = oReturn_html + "<td>" + row[column].ToString() + "</td></tr>"; }
                                    }
                                }
                            }
                            oReturn_html = oReturn_html + "</table>";
                        }
                    }
                    else
                    {
                        oReturn_html = oReturn_html + " ";
                        if (oHeard == 0)
                        {
                            wTitule = search_xml_display(table.TableName.ToString(), table.TableName.ToString(), "TABLE", @p_dicionario);

                            oReturn_html = oReturn_html + "<h2>" + wTitule + "</h2> <table>";
                            oReturn_html = oReturn_html + "  <thead><tr>";

                            foreach (DataColumn column_h in table.Columns)
                            {
                                wTitule = search_xml_display(table.TableName.ToString(), column_h.ColumnName.ToString(), "FIELD", @p_dicionario);
                                if (wTitule != "-NO-")
                                {
                                    oReturn_html = oReturn_html + "<th>" + wTitule + "</th>";
                                }
                            }
                            oReturn_html = oReturn_html + "</tr></thead>";
                            oHeard++;
                        }
                        foreach (DataRow row_g in table.Rows)
                        {
                            oReturn_html = oReturn_html + "<tr>";
                            foreach (DataColumn column_g in table.Columns)
                            {
                                wTitule = search_xml_display(table.TableName.ToString(), column_g.ColumnName.ToString(), "FIELD", @p_dicionario);
                                if (wTitule != "-NO-")
                                {
                                    oReturn_html = oReturn_html + "<td>" + row_g[column_g].ToString() + "</td>";
                                }
                            }
                            oReturn_html = oReturn_html + "</tr>";
                        }
                        oReturn_html = oReturn_html + "</table>";
                        oHeard = 0;
                    }
                    //oReturn_html = oReturn_html + "<h6>" + DateTime.Now.ToString() + "</h6>";
                }
            }
            //return oHeard_html + oButton + oReturn_html + "</div></body></html>";
            return oHeard_html + oReturn_html + "</div></body></html>";
        }


        /// <summary>
        ///  Processo que pesquisa dados no dicionario caso nao exista no dicionario ele sera atualizado durante o processo
        ///  ele adiciona os dados no processo.
        /// </summary>
        /// <param name="p_table_name">Nome da tabela o nó de dados</param>
        /// <param name="p_field_name">Nome do campo ou Field encontrado na estruturaa de dados</param>
        /// <param name="p_type_data">Tipo primitico de dados do campo </param>
        /// <param name="p_dicionario">Nome do arquivo do dicionario. a pesquisar o conteudo</param>
        /// <returns></returns>
        public string search_xml_display(String p_table_name, String p_field_name, String p_type_data, String p_dicionario)
        {
            String oRetorn = null;
            DataSet DicTable = new DataSet();
            DicTable = Stru_parameters_html(@p_dicionario);

            try
            {
                string expression = "DATA_TABLE_NAME = '" + p_table_name + "' and  DATA_NAME_FIELD = '" +
                    p_field_name + "' and DATA_TYPE_NAME = '" + p_type_data + "' ";
                // string expression = "OrderQuantity = 2 and OrderID = 2";
                string sortOrder = "DATA_TABLE_NAME ASC";
                DataRow[] foundRows;
                // Use the Select method to find all rows matching the filter.
                foundRows = DicTable.Tables[0].Select(expression, sortOrder);
                // Print column 0 of each returned row.
                for (int i = 0; i < foundRows.Length; i++)
                {
                    if (foundRows[i]["VIEWER"].ToString() == "Y")
                    {
                        oRetorn = foundRows[i]["DATA_TABLE_DISPLAY"].ToString();
                    }
                    else
                    {
                        oRetorn = "-NO-";
                    }

                }
                if (oRetorn == null)
                {
                    DataRow row;
                    row = DicTable.Tables[0].NewRow();
                    row["DATA_TABLE_NAME"] = p_table_name;
                    row["DATA_NAME_FIELD"] = p_field_name;
                    row["DATA_TYPE_NAME"] = p_type_data;
                    row["DATA_TABLE_DISPLAY"] = p_field_name;
                    row["DATA_SIZE"] = "";
                    row["VIEWER"] = "Y";
                    DicTable.Tables[0].Rows.Add(row);
                    DicTable.WriteXml(@p_dicionario);
                    oRetorn = p_field_name;
                }
            }
            catch (Exception)
            {
                oRetorn = p_field_name;
            }

            return oRetorn;
        }

        /// <summary>
        /// Estrutura de Dicionario de dados 
        /// </summary>
        /// <param name="p_dicionario">informe onde esta o aqruivo de configuração do dicionario</param>
        /// <returns> Caso o Dicionario exista ele carrega o arquivo do dicionario caso nao exsite e criar e estrutura para ser
        ///  Gerada automaticamnte. </returns>
        public DataSet Stru_parameters_html(String p_dicionario)
        {
            FileIO oFile_IO = new FileIO();
            DataSet oReturn = new DataSet();
            if (!oFile_IO.FileExiste(p_dicionario))
            {
                DataTable oDataTable = new DataTable("STRU_DATA");
                oDataTable.Columns.Add("DATA_TABLE_NAME", typeof(string));
                oDataTable.Columns.Add("DATA_NAME_FIELD", typeof(string));
                oDataTable.Columns.Add("DATA_TYPE_NAME", typeof(string));
                oDataTable.Columns.Add("DATA_TABLE_DISPLAY", typeof(string));
                oDataTable.Columns.Add("DATA_SIZE", typeof(string));
                oDataTable.Columns.Add("VIEWER", typeof(string));
                oDataTable.Columns.Add("MASK", typeof(string));
                oDataTable.Columns.Add("FUNCTION", typeof(string));
                oReturn.Tables.Add(oDataTable);
                oReturn.WriteXml(@p_dicionario);
            }
            else
            {
                oReturn.ReadXml(@p_dicionario);
            }
            return oReturn;
        }
    }
}
