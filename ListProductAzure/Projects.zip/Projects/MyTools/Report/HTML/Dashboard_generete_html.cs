﻿using System;
using System.Data;

namespace MyTools.Report.HTML
{
    public class Dashboard_generete_html
    {
        /// <summary>
        ///  Criar estrutura de Dashbord de retorno em panel box.
        /// </summary>
        /// <param name="p_dataTable"></param>
        /// <returns></returns>
        public string Dashboard_panel_box(DataTable p_dataTable)
        {
            String oReturn_html = "<div class='row'>";
            String wCOR = "";
            String wIMAGE = "";
            String wTEXT_COMMENT = "";
            String wTEXT_VIEW = "";
            String wLINK = "";
            String wHUGE = "";
            foreach (DataRow row in p_dataTable.Rows)
            {
                /// Escrevendo Estrutura de dados 
                wIMAGE = row["IMAGE"].ToString();
                wTEXT_COMMENT = row["TEXT_COMMENT"].ToString();
                wTEXT_VIEW = row["TEXT_VIEW"].ToString();
                wLINK = row["LINK"].ToString();
                wHUGE = row["HUGE"].ToString();
                switch (row["COR"].ToString())
                {
                    //bg-red - active,
                    //bg-yellow - active,
                    //bg-aqua - active,
                    //bg-blue - active,
                    //bg-light - blue - active,
                    //bg-green - active,
                    //bg-navy - active,
                    //bg-teal - active,
                    //bg-olive - active,
                    //bg-lime - active,
                    //bg-orange - active,
                    //bg-fuchsia - active,
                    //bg-purple - active,
                    //bg-maroon - active,
                    //bg-black - active,

                    case "panel-danger":
                        wCOR = "bg-red";
                        break;
                    case "panel-success":
                        wCOR = "bg-green";
                        break;
                    case "panel-info":
                        wCOR = "bg-aqua";
                        break;
                    case "panel-warning":
                        wCOR = "bg-yellow";
                        break;
                    case "Undefined":
                        wCOR = "bg-yellow";
                        break;
                    default:
                        wCOR = "bg-purple";
                        break;
                }

                oReturn_html = oReturn_html + " <div class='col-md-3 col-sm-3 col-xs-12'>" +
                                             "  <div class='info-box " + wCOR + "'>" +
                                             "    <span class='info-box-icon'><i class='" + wIMAGE + "'></i></span>" +
                                             "    <div class='info-box-content'>" +
                                             "      <span class='info-box-text'>" + wTEXT_VIEW + "</span>" +
                                             "      <span class='info-box-number'>" + wHUGE + "</span>" +
                                             " <a href = '" + wLINK + "' > VIEWER </a> " +
                                             "      <div class='progress'>" +
                                             "        <div class='progress-bar' style='width: " + wHUGE + "% '>" +
                                             "</div>" +
                                             "      </div>" +
                                             "          <span class='progress-description'>" + wTEXT_COMMENT + " </span>" +
                                             "    </div>" +
                                             "  </div> " +
                                             "</div> ";
            }
            oReturn_html = oReturn_html + "</div>";
            return oReturn_html;
        }
        public string Dashboard_panel_2_box_(DataTable p_dataTable)
        {
            String oReturn_html = "<div class='row'>";
            String wCOR = "";
            String wIMAGE = "";
            String wTEXT_COMMENT = "";
            String wTEXT_VIEW = "";
            String wLINK = "";
            String wHUGE = "";

            foreach (DataRow row in p_dataTable.Rows)
            {
                /// Escrevendo Estrutura de dados 
                wCOR = row["COR"].ToString();
                wIMAGE = row["IMAGE"].ToString();
                wTEXT_COMMENT = row["TEXT_COMMENT"].ToString();
                wTEXT_VIEW = row["TEXT_VIEW"].ToString();
                wLINK = row["LINK"].ToString();
                wHUGE = row["HUGE"].ToString();

                oReturn_html = oReturn_html + "<div class='col-lg-4 col-md-6'>" +
                                                    "<div class='panel " + wCOR + "'>" +
                                                        "<div class='panel-heading'>" +
                                                            "<div class='row'>" +
                                                               "<div class='col-xs-3'>" +
                                                                    "<i class='" + wIMAGE + "' ></i>" +
                                                                      "</div>" +
                                                               "<div class='col-xs-9' > " +
                                                                    "<div class='huge'>" + wHUGE + " .</div>" +
                                                                    "<div><h5>" + wTEXT_COMMENT + "</h5></div>" +
                                                               "</div>" +
                                                            "</div>" +
                                                          "</div>" +
                                                          "<a href = '" + wLINK + "' >" +
                                                             "<div class='panel-footer'>" +
                                                                 "<span class='pull-left'>" + wTEXT_VIEW + "</span>" +
                                                                 "<span class='pull-right'><i class='fa fa-arrow-circle-right'></i></span>" +
                                                                 "<div class='clearfix'></div>" +
                                                             "</div>" +
                                                          "</a>" +
                                                       "</div>" +
                                                     "</div>";
            }
            oReturn_html = oReturn_html + "</div>";
            return oReturn_html;
        }
        /// <summary>
        ///  Dashboard Time Line 
        /// </summary>
        /// <param name="p_title"> Informa Titulo do Timeline</param>
        /// <param name="p_dataTable"> Informar datatable estrutura Timeline para montar Timeline</param>
        /// <returns></returns>
        public string Dashboard_time_line(String p_title, DataTable p_dataTable)
        {
            String oReturn_html = "<div class='panel panel-default'> <div class='panel-heading'>" +
                                  "<i class='fa fa-clock-o fa-fw'></i>" + p_title +
                                  "</div><div class='panel-body'><ul class='timeline'>";

            String wSide = "";
            String wLINK = "";
            String wTEXT_VIEW = "";
            String wTEXT_COMMENT = "";
            String wIMAGE = "";
            String wCor = "";

            foreach (DataRow row in p_dataTable.Rows)
            {
                /// Escrevendo Estrutura de dados 
                wSide = row["SIDE"].ToString();
                wIMAGE = row["IMAGE"].ToString();
                wTEXT_COMMENT = row["TEXT_COMMENT"].ToString();
                wTEXT_VIEW = row["TEXT_VIEW"].ToString();
                wLINK = row["LINK"].ToString();
                wCor = row["COR"].ToString();

                if (wSide == "I") // Se informar I o processo sera Invertido caso não seja informado o processo sera normal
                {
                    oReturn_html = oReturn_html + "<li class='timeline - inverted'>";
                }
                else
                {
                    oReturn_html = oReturn_html + "<li>";
                }

                oReturn_html = oReturn_html + "<div class='timeline-badge " + wCor +
                    "'><i class='fa fa-credit-card'></i></div>" +
                    "<div class='timeline-panel'><div class='timeline-heading'>" +
                    "<h4 class='timeline-title'><a href=" + wLINK +
                    ">link text</a>" + wTEXT_VIEW + "</h4></div>" +
                    "<div class='timeline-body'>" + wTEXT_COMMENT +
                    "</div></div></li>";
            }
            oReturn_html = oReturn_html + "</ul></div></div>";
            return oReturn_html;
        }
        /// <summary>
        ///  Dashboard Time Line 
        /// </summary>
        /// <param name="p_title"> Informa Titulo do Timeline</param>
        /// <param name="p_dataTable"> Informar datatable estrutura Timeline para montar Timeline</param>
        /// <returns></returns>
        public string Dashboard_time_2_line(String p_title, DataTable p_dataTable)
        {
            String oReturn_html = "<div class='panel panel-default'> <div class='panel-heading'>" +
                                  "<i class='fa fa-clock-o fa-fw'></i>" + p_title +
                                  "</div><div class='panel-body'><ul class='timeline'>";

            String wSide = "";
            String wLINK = "";
            String wTEXT_VIEW = "";
            String wTEXT_COMMENT = "";
            String wIMAGE = "";
            String wCor = "";

            int wRow = 0;

            DateTime wValid_Data;
            String wValid_Data_curr = "";
            String wVar_Valid_Data = "";
            String wVar_Valid_Data_hora = "";

            foreach (DataRow row in p_dataTable.Rows)
            {
                /// Escrevendo Estrutura de dados 
                wSide = row["SIDE"].ToString();
                wIMAGE = row["IMAGE"].ToString();
                wTEXT_COMMENT = row["TEXT_COMMENT"].ToString();
                wTEXT_VIEW = row["TEXT_VIEW"].ToString();
                wLINK = row["LINK"].ToString();
                wCor = row["COR"].ToString();

                if (wRow == 0) // Inicio de processo
                {
                    oReturn_html = oReturn_html + "<div class='tab-pane' id='timeline'><ul class='timeline timeline-inverse'>";
                }

                if (row["DATE_TILE"].ToString() == "" && row["DATE_TILE"].ToString() == null)
                { oReturn_html = oReturn_html + " <li class='time-label'> <span class='bg-red'>-------</span></li>"; }
                else
                {
                    try
                    {
                        wValid_Data = DateTime.Parse(row["DATE_TILE"].ToString());
                        wValid_Data_curr = wValid_Data.ToString("yyyy-MM-dd");
                        wVar_Valid_Data_hora = wValid_Data.ToString("HH':'mm':'ss");
                    }
                    catch (Exception) { oReturn_html = oReturn_html + " <li class='time-label'> <span class='bg-red'>-------</span></li>"; }
                }
                if (wVar_Valid_Data == "")
                {
                    wVar_Valid_Data = wValid_Data_curr;
                    oReturn_html = oReturn_html + " <li class='time-label'> <span class='bg-red'>" + wVar_Valid_Data + "</span></li>";
                }
                else
                {
                    if (wVar_Valid_Data != wValid_Data_curr)
                    {
                        oReturn_html = oReturn_html + " <li class='time-label'> <span class='bg-red'>" + wVar_Valid_Data + "</span></li>";
                    }
                }
                oReturn_html = oReturn_html +
                "        <li><i class='" + wIMAGE + "'></i> " +
                "            <div class='timeline-item'> " +
                "                <span class='time'><i class='fa fa-clock-o'></i>" + wVar_Valid_Data_hora + "</span> " +
                "                <h3 class='timeline-header'><a href = '#' > Texto hyperLink</a> sub Texto hyperLink</h3> " +
                "                <div class='timeline-body'> texto 1 </div> " +
                "                <div class='timeline-footer'> rodapé</div> " +
                "            </div> " +
                "        </li> ";

            }
            oReturn_html = oReturn_html + "<li><i class='fa fa-clock-o bg-gray'></i></li></ul></div>";
            return oReturn_html;
        }
        public string Dashboard_flowup(String p_title, DataTable p_dataTable)
        {
            String oReturn_html = "<div class='panel-body'>< ul class='chat'>";

            String wName_user = "";
            String wDate = "";
            String wLink = "";
            String wIMAGE = "";
            String wSide = "";
            String wTEXT_COMMENT = "";

            foreach (DataRow row in p_dataTable.Rows)
            {
                /// Escrevendo Estrutura de dados 
                wSide = row["SIDE"].ToString();
                wIMAGE = row["IMAGE"].ToString();
                wTEXT_COMMENT = row["TEXT_COMMENT"].ToString();
                wDate = row["DATE"].ToString();
                wLink = row["LINK"].ToString();

                if (wSide == "I") // Se informar I o processo sera Invertido caso não seja informado o processo sera normal
                {
                    oReturn_html = oReturn_html + "<li class='timeline - inverted'>";
                }
                else
                {
                    oReturn_html = oReturn_html + "<li>";
                }

                oReturn_html = oReturn_html + "<li class='left clearfix'><span class='chat-img pull-left'>" +
                                              "<img src = '" + wIMAGE + "' alt='User Avatar' class='img-circle'/></span>" +
                                              "<div class='chat-body clearfix'><div class='header'>";
                if (wSide == "I") // Se informar I o processo sera Invertido caso não seja informado o processo sera normal
                {
                    oReturn_html = oReturn_html + "<strong class='primary-font'>" + wName_user + "</strong>" +
                                                  "<small class='pull-right text-muted'>";
                }
                else
                {
                    oReturn_html = oReturn_html + "<small class='pull-right text-muted'>" +
                                                  "<strong class='primary-font'>" + wName_user + "</strong>";
                }

                oReturn_html = oReturn_html + "<i class='fa fa-clock-o fa-fw'></i>" + wDate + "</small></div><p>" +
                                              wTEXT_COMMENT + "</p></div></li>";
            }
            oReturn_html = oReturn_html + "</ul></div></div>";
            return oReturn_html;
        }
        /// <summary>
        ///  Criar Estrutura necessaria para o processo para Panel KPI
        /// </summary>
        /// <returns> Retorno de estrutura necessar para o processo de montagem destes dados.</returns>
        public DataTable Create_Dashboard_panel_box()
        {
            DataTable oReturn = new DataTable();
            oReturn.Columns.Add("COR", typeof(string));
            oReturn.Columns.Add("IMAGE", typeof(string));
            oReturn.Columns.Add("TEXT_COMMENT", typeof(string));
            oReturn.Columns.Add("TEXT_VIEW", typeof(string));
            oReturn.Columns.Add("LINK", typeof(string));
            oReturn.Columns.Add("HUGE", typeof(string));
            return oReturn;
        }
        /// <summary>
        /// Criar Estrutura necessario para o processo de Time Line de KPI
        /// </summary>
        /// <returns></returns>
        public DataTable Create_Dashboard_time_line()
        {
            DataTable oReturn = new DataTable();
            oReturn.Columns.Add("NAME_USER", typeof(string));
            oReturn.Columns.Add("DATE", typeof(string));
            oReturn.Columns.Add("LINK", typeof(string));
            oReturn.Columns.Add("IMAGE", typeof(string));
            oReturn.Columns.Add("SIDE", typeof(string));
            oReturn.Columns.Add("TEXT_COMMENT", typeof(string));
            return oReturn;
        }
    }
}
