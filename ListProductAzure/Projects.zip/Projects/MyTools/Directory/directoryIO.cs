﻿using System;
using System.Data;
using System.IO;
using Newtonsoft.Json;

namespace MyTools.Directory
{
    public class directoryIO
    {
        DataSet oListDt = new DataSet();
        /// <summary>
        ///  Iniciando os Metodos
        /// </summary>
        public directoryIO()
        {

        }
        /// <summary>
        /// Verifica de o diretorio existe ou não
        /// </summary>
        /// <param name="p_path"> Caminho do Arquivo</param>
        /// <returns> Retorno (True) para diretorio existente e (False) para diretorio nao exsitente. </returns>
        ///
        public bool ExistDirectory(String p_path)
        {
            bool oDiretory = System.IO.Directory.Exists(p_path);
            return oDiretory;
        }
        /// <summary>
        ///  Lista uma Path ou diretorio de Forma Recursiva e retorna no formato de Json ou XML
        /// </summary>
        /// <param name="p_path"> Path que deseja lista recursivamente </param>
        /// <param name="p_type_return"> Json ca informado diferente sera retornado um XML</param>
        /// <returns></returns>
        public String ListDirectory(String p_path, String p_type_return)
        {
            String oRetorn = null;
            oListDt = ListStru();
            DataSet oProcesso = ProcessDirectory(p_path, oListDt);

            if (p_type_return.ToUpper() == "JSON")
            {
                oRetorn = JsonConvert.SerializeObject(oProcesso, Formatting.Indented);
            }
            else
            {
                oRetorn = oProcesso.GetXml();
            }
            return oRetorn;
        }
        // Processa todos os arquivos no diretório passado, recorre em qualquer diretório
        // que são encontrados e processam os arquivos que eles contêm.
        protected DataSet ProcessDirectory(string p_Directory, DataSet p_ListStru)
        {
            DataSet oRetorno = p_ListStru;
            // Processa a lista de arquivos encontrados no diretório.
            string[] fileEntries = System.IO.Directory.GetFiles(p_Directory);
            foreach (string fileName in fileEntries)
            {
                FileInfo oFile = new FileInfo(fileName);
                DataRow oRown = oRetorno.Tables[0].NewRow();
                oRown[0] = oFile.Name.ToString();
                oRown[1] = oFile.LastWriteTime.ToString();
                oRown[2] = oFile.LastWriteTimeUtc.ToString();
                oRetorno.Tables[0].Rows.Add(oRown);
            }

            // Recurse em subdiretórios deste diretório.
            string[] subdirectoryEntries = System.IO.Directory.GetDirectories(p_Directory);
            foreach (string subdirectory in subdirectoryEntries)
            {
                oRetorno = ProcessDirectory(subdirectory, oRetorno);
            }
            return oRetorno;
        }
        // Criando estrutura de Armazenamento de estrutura de arquivos.
        protected DataSet ListStru()
        {
            DataSet oReturn = new DataSet("List");
            DataTable oDataTable = new DataTable("Files");
            oDataTable.Columns.Add("Filename", typeof(string));
            oDataTable.Columns.Add("LastWriteTime", typeof(string));
            oDataTable.Columns.Add("LastWriteTimeUtc", typeof(string));
            oReturn.Tables.Add(oDataTable);
            return oReturn;
        }
        /// <summary>
        ///  Criar Diretorio no Path Informado.
        /// </summary>
        /// <param name="p_Path"> Path diretorio a se gerado.</param>
        public void MkDir(String p_Path)
        {
            try
            {
                DirectoryInfo di = System.IO.Directory.CreateDirectory(p_Path);
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        ///  Criar sub diretorios (Pasta) do mesmo nivel que esta posicionado seu programa.
        /// </summary>
        /// <param name="p_Directory"> informe a pasta que deseja criar sem caracter especiais.</param>
        public String AddNivelMkDir(String p_Directory)
        {
            try
            {
                String oPath = System.IO.Directory.GetCurrentDirectory();
                oPath = oPath + p_Directory;
                MkDir(oPath);
                return oPath;
            }
            catch (Exception)
            {
                throw;
            }

        }
    }

}
