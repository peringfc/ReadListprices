﻿using MyBase.Database;
using MyTools.Files;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBase.Config
{

    public class Parameters
    {
        /// <summary>
        /// Carregando Metodos de dados para Gerenciamento de Arquivos.
        /// </summary>
        FileIO oFileIO = new FileIO();
        //string oFile = "/tmp/NFLFramework.json";
        //string oFileDatabase = "/tmp/NFLFramework_database.json";
        string oPath = "/Users/u013235/temp";
        string oFile = "/Users/u013235/temp/NFLFramework.json";
        string oFileDatabase = "/Users/u013235/temp/NFLFramework_database.json";

        /// <summary>
        ///  Carregando arquivo de paramentros de configuracao
        /// </summary>
        /// <returns>retorno arquivo de parametros carregados. </returns>
        /// <exception cref="InvalidOperationException"></exception>
        protected DataSet Load_Config()
        {
            DataSet oRetorn = new DataSet();
            try
            {
                if (oFileIO.FileExiste(@oFile))
                {
                    try
                    {
                        StreamReader r = new StreamReader(@oFile);
                        string jsonString = r.ReadToEnd();
                        oRetorn = JsonConvert.DeserializeObject<DataSet>(jsonString);
                        return oRetorn;
                    }
                    catch (Exception) { throw; }
                }
                else
                {
                    throw new InvalidOperationException($"{oFile}: file not found, there is no configuration for this application");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Carregando arquivos de configuração de Alias Informado para processo de estruturação
        /// <b>Obs.:</b> o usuarios que estiver realizando leitura deste arquivo devera ter acesso de leitura para esta arquivo
        /// que esta sendo acessado
        /// </summary>
        /// <param name="p_Filename"> Path completo do arquivo que sera acessao</param>
        /// <returns> Dataset com dados de configuração para o banco em questão.</returns>
        /// <exception cref="InvalidOperationException"></exception>
        protected DataSet Parameter(String p_Filename)
        {
            DataSet oRetorn = new DataSet();
            try
            {
                if (oFileIO.FileExiste(p_Filename))
                {
                    try
                    {
                        StreamReader r = new StreamReader(p_Filename);
                        string jsonString = r.ReadToEnd();
                        oRetorn = JsonConvert.DeserializeObject<DataSet>(jsonString);
                        return oRetorn;
                    }
                    catch (Exception) { throw; }
                }
                else
                {
                    throw new InvalidOperationException(p_Filename + ".json: file not found, there is no configuration for this application");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="p_KeyAlias"></param>
        /// <returns></returns>
        public DataSet LoadParameter(String p_KeyAlias)
        {
            DataSet oLoad = new DataSet();
            oLoad = Load_Config();

            DataSet oRetorn = new DataSet();

            String oFilename = null;
            foreach (DataRow oRow in oLoad.Tables["DATABASE"].Rows)
            {
                if (p_KeyAlias == oRow["ALIAS"].ToString())
                {
                    oFilename = oRow["FILENAME"].ToString();
                }
            }
            try
            {
                oRetorn = Parameter(oFilename);
            }
            catch (Exception)
            {
                throw;
            }
            return oRetorn;
        }

        /// <summary>
        ///  Carregar Configurações do Banco de dados da Chave Alias Informada (p_KeyAlais)
        /// </summary>
        /// <param name="p_KeyAlias"></param>
        /// <returns></returns>
        public DataSet LoadConfig(String p_KeyAlias)
        {
            DataSet oLoad = new DataSet();
            oLoad = Load_Config();

            DataSet oRetorn = new DataSet();

            String oFilename = null;
            String oReturn = "";

            try
            {
                if (oFileIO.FileExiste(oFile))
                {
                    oReturn = oReturn + $"- {oFile} - OK - Localizado com sucesso." + Environment.NewLine;
                    try
                    {
                        foreach (DataRow oRow in oLoad.Tables["DATABASE"].Rows)
                        {
                            if (p_KeyAlias == oRow["ALIAS"].ToString())
                            {
                                oFilename = oRow["FILENAME"].ToString();
                            }
                        }
                        try
                        {
                            oRetorn = Parameter(oFilename);
                        }
                        catch (Exception) { throw; }
                    }
                    catch (Exception) { throw; }
                }
            }
            catch (Exception) { throw; }
            return oRetorn;
        }

        /// <summary>
        ///  Carrega Chave de Criptografia Informada 
        /// </summary>
        /// <param name="KeyAlias">Alias da chave desejada para acesso a dos</param>
        /// <param name="TypeKey"> Public / Private </param>
        /// <returns> Resulta Chave de Criptografia desejada para acesso a dados</returns>
        /// <exception cref="InvalidOperationException"></exception>
        public String LoadKey(String KeyAlias, String TypeKey)
        {
            DataSet oLoad = new DataSet();
            oLoad = Load_Config();
            String oReturn = "KEY";
            try
            {
                switch (TypeKey.ToUpper().Trim().TrimEnd().TrimStart())
                {
                    case "PUBLIC":
                        if (oFileIO.FileExiste(@oFile))
                        {
                            try
                            {
                                foreach (DataRow oRow in oLoad.Tables["DATABASE"].Rows)
                                {
                                    if (KeyAlias == oRow["ALIAS"].ToString())
                                    {
                                        oReturn = oRow["ID_FILENAME"].ToString();
                                    }
                                }
                            }
                            catch (Exception) { throw; }
                        }
                        break;
                    case "PRIVATE":
                        if (oFileIO.FileExiste(@oFile))
                        {
                            try
                            {
                                foreach (DataRow oRow in oLoad.Tables["DATAFILE"].Rows)
                                {
                                    oReturn = oRow["ID_FILENAME"].ToString();
                                }
                            }
                            catch (Exception) { throw; }
                        }
                        break;
                    default:
                        throw new InvalidOperationException("Tipo de base de acesso nao foi informanda corretamente !! Verifique !!");
                }
            }
            catch (Exception) { throw; }
            return oReturn;
        }

        /// <summary>
        /// Informar tipo de banco de dados  da chave informada.
        /// </summary>
        /// <param name="KeyAlias">Informe alias de autenticação de dados.</param>
        /// <returns> Retorna o tipo de banco de dados.</returns>
        public String LoadTypeDatabase(String KeyAlias)
        {
            DataSet oLoad = new DataSet();
            oLoad = Load_Config();
            String oReturn = null;

            try
            {
                if (oFileIO.FileExiste(oFile))
                {
                    try
                    {
                        foreach (DataRow oRow in oLoad.Tables["DATABASE"].Rows)
                        {
                            if (KeyAlias == oRow["ALIAS"].ToString())
                            {
                                oReturn = oRow["TYPEDB"].ToString();
                            }
                        }
                    }
                    catch (Exception) { throw; }
                }
            }
            catch (Exception) { throw; }
            return oReturn;
        }

        /// <summary>
        ///  Processo de Validação de existencia de arquivos e validação dos arquivos de conexao de arquivos ao banco de dados.
        /// </summary>
        /// <returns> Lista informações e Validação de arquivos de conexão /returns>
        public String Load_ValidConfig()
        {
            String oReturn = "- Path:" + Directory.GetCurrentDirectory() + Environment.NewLine;
            DataSet oValid = new DataSet();
            try
            {
                if (oFileIO.FileExiste(oFile))
                {
                    oReturn = oReturn + $"- {oFile} - OK - Localizado com sucesso." + Environment.NewLine;
                    try
                    {
                        StreamReader r = new StreamReader(oFile);
                        string jsonString = r.ReadToEnd();
                        oValid = JsonConvert.DeserializeObject<DataSet>(jsonString);
                        try
                        {
                            foreach (DataRow oRow in oValid.Tables["DATABASE"].Rows)
                            {
                                try
                                {
                                    if (oFileIO.FileExiste(oRow["FILENAME"].ToString()))
                                    {
                                        oReturn = oReturn + "- Database - " + oRow["ALIAS"].ToString() +
                                            " - " + oRow["FILENAME"].ToString() + " OK " + Environment.NewLine;
                                    }
                                    else
                                    {
                                        oReturn = oReturn + "- Database - " + oRow["ALIAS"].ToString() +
                                            " - " + oRow["FILENAME"].ToString() + " Arquivo Não Localizado" + Environment.NewLine;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    oReturn = oReturn + "- Database - " + oRow["ALIAS"].ToString() + " - " + ex.Message.ToString() + Environment.NewLine;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            oReturn = oReturn + "- Database - Error - " + ex.Message.ToString() + Environment.NewLine;
                        }

                    }
                    catch (Exception ex)
                    {
                        oReturn = oReturn + "- Database - Error - " + ex.Message.ToString() + Environment.NewLine;
                    }
                }
                else
                {
                    oReturn = oReturn + $"- {oFile} - Não Localizado - Error. " + Environment.NewLine;
                }
            }
            catch (Exception ex)
            {
                oReturn = oReturn + $"- {oFile} - Não Localizado - Error. " + ex.Message.ToString() + Environment.NewLine;
            }
            return oReturn;
        }


        /// <summary>
        /// Display de validação de arquivos
        /// </summary>
        /// <returns> String com texto de validação de confirmação de links de arquivos</returns>
        public String Display_Config()
        {
            string oReturn = "";
            DataSet oValid = new DataSet();
            try
            {
                if (oFileIO.FileExiste(@oFile))
                {
                    oReturn = oReturn + $"- {oFile} - OK - Localizado com sucesso." + Environment.NewLine;
                    try
                    {
                        StreamReader r = new StreamReader(oFile);
                        oReturn = r.ReadToEnd();
                    }
                    catch (Exception ex)
                    {
                        oReturn = oReturn + "- Database - Error - " + ex.Message.ToString() + Environment.NewLine;
                    }
                }
                else
                {
                    oReturn = oReturn + $"- {oFile} - Não Localizado - Error. " + Environment.NewLine;
                }
            }
            catch (Exception ex)
            {
                oReturn = oReturn + $"- {oFile} - Não Localizado - Error. " + ex.Message.ToString() + Environment.NewLine;
            }
            return oReturn;

        }


        /// <summary>
        ///  Teste a existencia de todos os arquivos de configuração
        /// </summary>
        /// <returns></returns>
        public String Load_TestConfig()
        {
            Console.WriteLine("Valid config. DATABASE.");
            String oReturn = "- Path:" + Directory.GetCurrentDirectory() + Environment.NewLine;
            DataSet oValid = new DataSet();

            DatabaseConect oDatabaseConect = new DatabaseConect();

            try
            {
                if (oFileIO.FileExiste(@oFile))
                {
                    oReturn = oReturn + $"- {oFile} - OK - Localizado com sucesso." + Environment.NewLine;
                    try
                    {
                        StreamReader r = new StreamReader(oFile);
                        string jsonString = r.ReadToEnd();
                        oValid = JsonConvert.DeserializeObject<DataSet>(jsonString);
                        try
                        {
                            foreach (DataRow oRow in oValid.Tables["DATABASE"].Rows)
                            {
                                try
                                {
                                    if (oFileIO.FileExiste(oRow["FILENAME"].ToString()))
                                    {
                                        oReturn = oReturn + "- Database - " + oRow["ALIAS"].ToString() +
                                            " - " + oRow["FILENAME"].ToString() + " OK " + Environment.NewLine;

                                        oReturn = oReturn + "-> " +
                                            oDatabaseConect.ExecuteTest(oRow["ALIAS"].ToString()) + " OK " + Environment.NewLine;


                                    }
                                    else
                                    {
                                        oReturn = oReturn + "- Database - " + oRow["ALIAS"].ToString() +
                                            " - " + oRow["FILENAME"].ToString() + " Arquivo Não Localizado" + Environment.NewLine;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    oReturn = oReturn + "- Database - " + oRow["ALIAS"].ToString() + " - " + ex.Message.ToString() + Environment.NewLine;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            oReturn = oReturn + "- Database - Error - " + ex.Message.ToString() + Environment.NewLine;
                        }
                    }
                    catch (Exception ex)
                    {
                        oReturn = oReturn + "- Database - Error - " + ex.Message.ToString() + Environment.NewLine;
                    }
                }
                else
                {
                    oReturn = oReturn + $"- {oFile} - Não Localizado - Error. " + Environment.NewLine;
                }
            }
            catch (Exception ex)
            {
                oReturn = oReturn + $"- {oFile} - Não Localizado - Error. " + ex.Message.ToString() + Environment.NewLine;
            }
            return oReturn;
        }
    }

}
