﻿using MyTools.Convert;
using MyTools.Cripto;
using MyTools.Directory;
using MyTools.Files;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBase.Setup
{
    /// <summary>
    ///  Processp de Setup de banco de dados configuracao de senha de acesso
    /// </summary>
    public class Setup
    {
        FileIO oFileIO = new FileIO();
        XMLtoJSON oXMLtoJSON = new XMLtoJSON();
        Cryptography oCryptography = new Cryptography();
        directoryIO odirectoryIO = new directoryIO();

        /// <summary>
        /// Informe Path onde se encontra o Caminho de configuração (PAth) 
        ///  exemplo Windows c:\caminho\ ou  Linux ou Mac /caminho/
        /// </summary>
        public string? oPath { get; set; }

        /// <summary>
        ///  Informe caminho e nome do arquivo de configuração de chave de acesso
        ///  ao banco de dados
        ///   exemplo Windows c:\caminho\arquivo.json ou  Linux ou Mac /caminho/arquivo.json
        /// </summary>
        public string? oFile { get; set; }
        public string? oFileDatabase { get; set; }

        /// <summary>
        ///  Criação de Estrutura de Setup para arquivos de configuração <NFLFramework>
        /// </summary>
        public void SetupConfig()
        {
            try
            {
                if (!oFileIO.FileExiste(oFile))
                {
                    CreateFileConf();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///  Processo para salvar arquivo em disco
        /// </summary>
        /// <param name="p_FilePath"> Caminho e nome do arquivo a ser salvo</param>
        /// <param name="p_Text"> Texto a ser salvo.</param>
        protected void SalveFileConfigText(String p_FilePath, String p_Text)
        {
            try
            {
                oFileIO.SalveFile(p_FilePath, p_Text);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///  Salvoando arquivos do formato DataSet em Json
        /// </summary>
        /// <param name="p_FilePath"> Caminho e nome do arquivo a ser salvo</param>
        /// <param name="p_DataSet"> DataSet que sera salvo</param>
        protected void SalveFileConfDts(String p_FilePath, DataSet p_DataSet)
        {
            try
            {
                String oJson = oXMLtoJSON.Convert(p_DataSet);
                SalveFileConfigText(p_FilePath, oJson);
            }
            catch (Exception)
            {
                throw;
            }


        }

        /// <summary>
        /// Criação de estrutura de arquivo de configuração de dados
        /// </summary>
        protected void CreateFileConf()
        {
            try
            {
                Guid c = Guid.NewGuid();
                Guid d = Guid.NewGuid();
                Guid p = Guid.NewGuid();

                Guid K = Guid.NewGuid();
                Guid I = Guid.NewGuid();

                DataSet oReturn = new DataSet("CONFIG");
                DataTable oDataTableFile = new DataTable("DATAFILE");
                oDataTableFile.Columns.Add("ID_FILENAME", typeof(string));
                oDataTableFile.Columns.Add("FILENAME", typeof(string));
                oDataTableFile.Columns.Add("DESCRIPTION", typeof(string));
                oDataTableFile.Columns.Add("KEY", typeof(string));
                oDataTableFile.Columns.Add("KEY_IV", typeof(string));
                oDataTableFile.Columns.Add("DT_CREATE", typeof(string));
                oDataTableFile.Columns.Add("DT_UPDATE", typeof(string));
                oReturn.Tables.Add(oDataTableFile);

                DataTable oDataTable = new DataTable("DATABASE");
                oDataTable.Columns.Add("ID_FILENAME", typeof(string));
                oDataTable.Columns.Add("ALIAS", typeof(string));
                oDataTable.Columns.Add("FILENAME", typeof(string));
                oDataTable.Columns.Add("DESCRIPTION", typeof(string));
                oDataTable.Columns.Add("TYPEDB", typeof(string));
                oDataTable.Columns.Add("DT_CREATE", typeof(string));
                oDataTable.Columns.Add("DT_UPDATE", typeof(string));
                oReturn.Tables.Add(oDataTable);

                DataTable oDataTableParaMeter = new DataTable("PARAMETER");
                oDataTableParaMeter.Columns.Add("ID_FILENAME", typeof(string));
                oDataTableParaMeter.Columns.Add("FILENAME", typeof(string));
                oDataTableParaMeter.Columns.Add("ALIAS", typeof(string));
                oDataTableParaMeter.Columns.Add("DESCRIPTION", typeof(string));
                oDataTableParaMeter.Columns.Add("TYPEDATA", typeof(string));
                oDataTableParaMeter.Columns.Add("DT_CREATE", typeof(string));
                oDataTableParaMeter.Columns.Add("DT_UPDATE", typeof(string));
                oReturn.Tables.Add(oDataTableParaMeter);

                DataRow oRown = oReturn.Tables["DATAFILE"].NewRow();
                oRown["ID_FILENAME"] = c.ToString();
                oRown["FILENAME"] = oFile;
                oRown["KEY"] = K.ToString();
                oRown["KEY_IV"] = I.ToString();
                oRown["DESCRIPTION"] = "Arquivo de configurações.";
                oRown["DT_CREATE"] = DateTime.Now.ToString();
                oRown["DT_UPDATE"] = DateTime.Now.ToString();
                oReturn.Tables[0].Rows.Add(oRown);

                DataRow dRown = oReturn.Tables["DATABASE"].NewRow();
                dRown["ID_FILENAME"] = d.ToString();
                dRown["ALIAS"] = "<KEY ou Alias> Nome da chamadas pra as aplicações ";
                dRown["FILENAME"] = "< Path do arquivo de configuração do banco de dados devera ser informado > ";
                dRown["DESCRIPTION"] = "Descrição do banco de dados. como funcionalidade e para que server";
                dRown["TYPEDB"] = "Tipo do Banco Oracle, MySql, Postgresql, SqlServer, Teradata";
                dRown["DT_CREATE"] = DateTime.Now.ToString();
                dRown["DT_UPDATE"] = DateTime.Now.ToString();
                oReturn.Tables["DATABASE"].Rows.Add(dRown);

                DataRow pRown = oReturn.Tables["PARAMETER"].NewRow();
                pRown["ID_FILENAME"] = d.ToString();
                pRown["FILENAME"] = "< Path do arquivo de configuração do banco de dados devera ser informado > ";
                pRown["ALIAS"] = "<KEY ou Alias> Nome da chamadas pra as aplicações ";
                pRown["DESCRIPTION"] = "Descrição do banco de dados. como funcionalidade e para que server";
                pRown["TYPEDATA"] = "Tipo de dados CONFIG - Para configuraçoes especificas ou PARAMETER - Para parametros de sistemas.";
                pRown["DT_CREATE"] = DateTime.Now.ToString();
                pRown["DT_UPDATE"] = DateTime.Now.ToString();
                oReturn.Tables[2].Rows.Add(pRown);
                SalveFileConfDts(@oFile, oReturn);
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Processo de Criação de Estrutura de dados
        /// </summary>
        /// <param name="p_Alias">Nome da Chave da estrutura que sera criada.</param>
        /// <returns></returns>
        protected DataTable StruConfigDatabase(String p_Alias)
        {
            DataTable oDataTable = new DataTable(p_Alias);
            oDataTable.Columns.Add("Field_Name", typeof(string));
            oDataTable.Columns.Add("Field_Type", typeof(string));
            oDataTable.Columns.Add("Field_Value", typeof(string));
            oDataTable.Columns.Add("Field_Dt_Create", typeof(string));
            return oDataTable;
        }
        /// <summary>
        /// Processo de montagem do arquivo de configuracao atraves da chave de criptografia
        /// os campos deverão ser separados por ponto e virgura (;) para realizar a estruturação do arquivo de acesso
        /// </summary>
        /// <param name="p_KeyPostgresSQL"> chave de conexão </param>
        public void KeyUrlConnectPostgreSQL(string p_AliasNAme, string p_KeyPostgresSQL)
        {
            try
            {
                String p_Desc = string.Empty;
                String p_Host = string.Empty;
                String p_User = string.Empty;
                String p_DBname = string.Empty;
                String p_Password = string.Empty;
                String p_Port = string.Empty;
                String p_ParameterExtra = string.Empty;

                /// Testando conexao 
                Console.WriteLine(" Validating database connection");
                Console.WriteLine(@p_KeyPostgresSQL);

                NpgsqlConnection dbConnection = new NpgsqlConnection(@p_KeyPostgresSQL);
                dbConnection.Open();

                Console.WriteLine(" Database Access Validated Successfully - OK ");
                dbConnection.Close();
                ///
                string[] oKey = p_KeyPostgresSQL.Split(';');
                foreach (var Sub in oKey)
                {
                    string[] oSub = Sub.Split('=');

                    foreach (var oColun in oSub)
                    {
                        switch (oColun[0].ToString().Trim().TrimStart().TrimEnd().ToUpper())
                        {
                            case "HOST":
                                p_Host = oColun[1].ToString();
                                break;
                            case "SERVER":
                                p_Host = oColun[1].ToString();
                                break;
                            case "USERNAME":
                                p_User = oColun[1].ToString();
                                break;
                            case "Password":
                                p_Password = oColun[1].ToString();
                                break;
                            case "Database":
                                p_DBname = oColun[1].ToString();
                                break;
                            case "port":
                                p_Port = oColun[1].ToString();
                                break;
                            default:
                                p_ParameterExtra = oColun[0].ToString() + ";" + oColun[1].ToString() + ";";
                                break;
                        }
                    }
                }
                /// Salvando parametros
                SetupPostgreSQL(p_AliasNAme,
                                p_Desc,
                                p_Host,
                                p_User,
                                p_DBname,
                                p_Password,
                                p_Port,
                                p_ParameterExtra);
            }
            catch (Exception)
            {
                Console.WriteLine(" ================================");
                Console.WriteLine("       ====[ E R R O ]======");
                Console.WriteLine(" ================================");
                throw;
            }
        }
        /// <summary>
        ///  Setup de parametrizacao de naco PostgreSQL
        /// </summary>
        /// <param name="p_Alias"></param>
        /// <param name="p_Desc"></param>
        /// <param name="p_Host"></param>
        /// <param name="p_User"></param>
        /// <param name="p_DBname"></param>
        /// <param name="p_Password"></param>
        /// <param name="p_Port"></param>
        public void SetupPostgreSQL(
                                    String p_Alias,
                                    String p_Desc,
                                    String p_Host,
                                    String p_User,
                                    String p_DBname,
                                    String p_Password,
                                    String p_Port,
                                    String p_ParameterExtra)
        {


            String key = "";

            DataTable Setup_dataTable = new DataTable();

            //String oKeyProject = "PROJECT";
            //String oKeyIV = "PROJECT";
            DataRow dRown;
            Setup_dataTable = StruConfigDatabase(p_Alias);
            dRown = Setup_dataTable.NewRow();

            dRown["Field_Name"] = "HOSTNAME";
            dRown["Field_Type"] = "Text";
            dRown["Field_Value"] = p_Host;
            dRown["Field_Dt_Create"] = DateTime.Now.ToString();
            Setup_dataTable.Rows.Add(dRown);

            dRown = Setup_dataTable.NewRow();
            dRown["Field_Name"] = "KEY_USER";
            dRown["Field_Type"] = "CRIP";
            dRown["Field_Value"] = oCryptography.Encrypt(key, @p_User ); // oCryptography.EncryptString(p_User, oKeyProject, oKeyIV);
            dRown["Field_Dt_Create"] = DateTime.Now.ToString();
            Setup_dataTable.Rows.Add(dRown);

            dRown = Setup_dataTable.NewRow();
            dRown["Field_Name"] = "KEY";
            dRown["Field_Type"] = "CRIP";
            dRown["Field_Value"] = oCryptography.Encrypt(key, @p_Password); // oCryptography.EncryptString(p_Password, oKeyProject, oKeyIV);
            dRown["Field_Dt_Create"] = DateTime.Now.ToString();
            Setup_dataTable.Rows.Add(dRown);

            dRown = Setup_dataTable.NewRow();
            dRown["Field_Name"] = "DBSCHEMA";
            dRown["Field_Type"] = "Text";
            dRown["Field_Value"] = p_DBname;
            dRown["Field_Dt_Create"] = DateTime.Now.ToString();
            Setup_dataTable.Rows.Add(dRown);


            dRown = Setup_dataTable.NewRow();
            dRown["Field_Name"] = "PORT";
            dRown["Field_Type"] = "Number";
            dRown["Field_Value"] = p_Port;
            dRown["Field_Dt_Create"] = DateTime.Now.ToString();
            Setup_dataTable.Rows.Add(dRown);


            dRown = Setup_dataTable.NewRow();
            dRown["Field_Name"] = "DATABASE";
            dRown["Field_Type"] = "Text";
            dRown["Field_Value"] = "POSTGRESQL";
            dRown["Field_Dt_Create"] = DateTime.Now.ToString();
            Setup_dataTable.Rows.Add(dRown);

            dRown = Setup_dataTable.NewRow();
            dRown["Field_Name"] = "PARAMETER_EXTRA";
            dRown["Field_Type"] = "Text";
            dRown["Field_Value"] = p_ParameterExtra;
            dRown["Field_Dt_Create"] = DateTime.Now.ToString();
            Setup_dataTable.Rows.Add(dRown);

            SalveParameterDataBase(p_Alias,
                                    "PostgreSQL",
                                    p_Desc,
                                    Setup_dataTable);

        }

        /// <summary>
        ///   Salvar parametros informados.
        /// </summary>
        /// <param name="p_KeyAlias">Alias ou Key de Chamada</param>
        /// <param name="p_TypeDb">Tipo de banco de dados </param>
        /// <param name="p_Descrip">Descricao da aplicacao</param>
        /// <param name="p_Parameters"> List de parametros</param>
        protected void SalveParameterDataBase(
            String p_KeyAlias,
            String p_TypeDb,
            String p_Descrip,
            DataTable p_Parameters
            )
        {


            DataSet oLoadParameterFW = new DataSet();
            DataSet DtDatabase = new DataSet("DATABASE_CONFIG");
            //	String oPath = null;
            try
            {
                /// Verificando estrtura de configuração do Projeto
                if (oFileIO.FileExiste(@oFile))
                {
                    try
                    {
                        StreamReader r = new StreamReader(@oFile);
                        string jsonString = r.ReadToEnd();
                        oLoadParameterFW = JsonConvert.DeserializeObject<DataSet>(jsonString);
                    }
                    catch (Exception) { throw; }
                }
                else
                {
                    try
                    {
                        /// O arquivo nao esteja criado sera criando e carregado.
                        /// Processo de criação do arquivo.
                        ///

                        CreateFileConf();

                        StreamReader r = new StreamReader(@oFile);
                        string jsonString = r.ReadToEnd();
                        oLoadParameterFW = JsonConvert.DeserializeObject<DataSet>(jsonString);
                    }
                    catch (Exception) { throw; }
                }
                /// Iniciando processo de gravação de dados da configurações do banco de dados.
                String oFilename = "SELECT FILE";
                foreach (DataRow oRow in oLoadParameterFW.Tables["DATABASE"].Rows)
                {
                    if (p_KeyAlias == oRow["ALIAS"].ToString())
                    {
                        oFilename = oRow["FILENAME"].ToString();
                    }
                }
                if (oFilename == "SELECT FILE")
                {
                    //try
                    //{
                    //	oPath = odirectoryIO.AddNivelMkDir(@"\NFL_Database\");
                    //}
                    //catch (Exception) { }

                    Guid d = Guid.NewGuid();
                    DataRow dRown = oLoadParameterFW.Tables["DATABASE"].NewRow();
                    dRown["ID_FILENAME"] = d.ToString();
                    dRown["ALIAS"] = p_KeyAlias;
                    dRown["FILENAME"] = oFileDatabase;
                    dRown["DESCRIPTION"] = p_Descrip;
                    dRown["TYPEDB"] = p_TypeDb;
                    dRown["DT_CREATE"] = DateTime.Now.ToString();
                    dRown["DT_UPDATE"] = DateTime.Now.ToString();
                    oLoadParameterFW.Tables["DATABASE"].Rows.Add(dRown);
                    DtDatabase.Tables.Add(p_Parameters);
                }
                else
                {
                    StreamReader r = new StreamReader(@oFilename);
                    string jsonString = r.ReadToEnd();
                    DtDatabase = JsonConvert.DeserializeObject<DataSet>(jsonString);
                    DtDatabase.Tables.Remove(p_KeyAlias);
                    DtDatabase.Tables.Add(p_Parameters);
                }
                SalveFileConfDts(@oFileDatabase, DtDatabase);
                SalveFileConfDts(@oFile, oLoadParameterFW);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
