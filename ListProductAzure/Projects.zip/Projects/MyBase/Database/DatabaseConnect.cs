﻿using MyBase.Config;
using MyBase.Database.MySQL;
using MyBase.Database.Oracle;
using MyBase.Database.Postgresql;
using MyBase.Database.SqlServer;
using MyBase.Database.Teradata;
using MyTools.Cripto;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace MyBase.Database
{
    public class DatabaseConect
    {

        Parameters oParameters = new Parameters();

        #region Estrutura de Bancos de Conexão
        /// <summary>
        /// Libs de Banco de Dados 
        /// </summary>
        DbOracle oDbOracle = new DbOracle();
        DbMySql oDbMySql = new DbMySql();
        DbPostgresql oDbPostgresql = new DbPostgresql();
        DbSqlServer oDbSqlServer = new DbSqlServer();
        DbTeradata oDbTeradata = new DbTeradata();
        Cryptography oCryptography = new Cryptography();
        #endregion


        #region Estrutura de Metodos Publicos da Classe
        /// <summary>
        ///  Processo de execução o Command DML em um Banco de Dados vi Processo DML
        ///  Necessio realizar o processo de configuração de Alias de acesso ao Banco de Dados
        ///  - Para este processo voce tera que solicitar um usuarios de serviço que tenha
        ///    acesso de realizar o Select na base de dadis
        /// </summary>
        /// <param name="KeyAlias"> Alias de identificação para o banco de dados </param>
        /// <param name="SelectDML"> Comando Select que sera executado no banco de dados
        ///  caso queira mandar mas de um comando SELECT para o Banco dados e necessarios
        ///  colocar (;) no final de cada SELECT. </param>
        /// <returns></returns>
        ///
        public DataSet ExecuteSelect(String KeyAlias, String SelectDML)
        {
            DataSet oDtSelect = new DataSet();
            DataSet oDtParameter = new DataSet();
            String oConnect = null;

            String oKeyPublic = oParameters.LoadKey(KeyAlias, "PUBLIC"); /// Criar Metodo para resgatar 
			String oTypeDatabase = oParameters.LoadTypeDatabase(KeyAlias);    /// Criar Metodo que retorna tipo de banco
			try
            {
                /// Carregar Parametros de Configuração
                oDtParameter = oParameters.LoadParameter(KeyAlias);
                /// Monta Chave de conexão ao banco de dados.
                oConnect = ConnectString(oDtParameter);
                /// Executa Query no banco de dados.
                oDtSelect = ExecuteQuery(oTypeDatabase,
                                         oConnect,
                                         SelectDML);
                return oDtSelect;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///  Processo de teste de conexão de dados
        /// </summary>
        /// <param name="KeyAlias"></param>
        /// <returns> Resultado dos teste realizado conexão com sucesso ou erro apresentado.</returns>
        public String ExecuteTest(String KeyAlias)
        {

            Console.WriteLine(" Start Valid Alias Name:" + KeyAlias);
            DataSet oDtParameter = new DataSet();
            String oConnect = null;
            String oReturn = null;

            String oKeyPublic = oParameters.LoadKey(KeyAlias, "PUBLIC"); /// Criar Metodo para resgatar 
			String oTypeDatabase = oParameters.LoadTypeDatabase(KeyAlias);    /// Criar Metodo que retorna tipo de banco
			try
            {
                /// Carregar Parametros de Configuração
                oDtParameter = oParameters.LoadParameter(KeyAlias);
                /// Monta Chave de conexão ao banco de dados.
                oConnect = ConnectString(oDtParameter);
                /// Executa Query no banco de dados.
                oReturn = TestConect(oTypeDatabase,
                                         oConnect);
                return oReturn;
            }
            catch (Exception)
            {
                throw;
            }
        }


        public String KeyDatabase(String KeyAlias)
        {

            //Console.WriteLine(" Start Valid Alias Name:" + KeyAlias);
            DataSet oDtParameter = new DataSet();
            String oConnect = null;

            String oKeyPublic = oParameters.LoadKey(KeyAlias, "PUBLIC"); /// Criar Metodo para resgatar 
			String oTypeDatabase = oParameters.LoadTypeDatabase(KeyAlias);    /// Criar Metodo que retorna tipo de banco
			try
            {
                /// Carregar Parametros de Configuração
                oDtParameter = oParameters.LoadParameter(KeyAlias);
                oConnect = ConnectString(oDtParameter);

                return oConnect;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Estrutura de Metodos da Privados da Classe
        /// <summary>
        ///  Processo de Execução no banco de dados atraves dos dados informacdos 
        /// </summary>
        /// <param name="oDatabase">Tipo de banco de dados que sera informando para conexão do banco de dados</param>
        /// <param name="oConnect"> Chave de Conexão no banco de dados</param>
        /// <param name="oQuery"> Query Select a ser executada no banco dados.</param>
        /// <returns></returns>
        protected DataSet ExecuteQuery(String oDatabase, String oConnect, String oQuery)
        {
            DataSet oDataSet = new DataSet();
            try
            {
                switch (oDatabase.ToUpper().Trim().TrimEnd().TrimStart())
                {
                    case "ORACLE":
                        oDataSet = oDbOracle.ExecuteSelect(oConnect, oQuery);
                        break;
                    case "MYSQL":
                        oDataSet = oDbMySql.ExecuteSelect(oConnect, oQuery);
                        break;
                    case "SQLSERVER":
                        oDataSet = oDbSqlServer.ExecuteSelect(oConnect, oQuery);
                        break;
                    case "POSTGRESQL":
                        oDataSet = oDbPostgresql.ExecuteSelect(oConnect, oQuery);
                        break;
                    case "TERADATA":
                        oDataSet = oDbTeradata.ExecuteSelect(oConnect, oQuery);
                        break;
                    default:
                        throw new InvalidOperationException("Tipo de base de acesso nao foi informanda corretamente !! Verifique !!");
                }

                return oDataSet;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///  Processo de teste conexão de ao banco de dados 
        /// </summary>
        /// <param name="oDatabase">Tipo de banco de dados </param>
        /// <param name="oConnect"> String de conexão de dados. </param>
        /// <returns></returns>
        protected String TestConect(String oDatabase, String oConnect)
        {
            String oRetorn = null;
            try
            {
                switch (oDatabase.ToUpper().Trim().TrimEnd().TrimStart())
                {
                    case "ORACLE":
                        oRetorn = oDbOracle.ExecuteTest(oConnect);
                        break;
                    case "MYSQL":
                        oRetorn = oDbMySql.ExecuteTest(oConnect);
                        break;
                    case "SQLSERVER":
                        oRetorn = oDbSqlServer.ExecuteTest(oConnect);
                        break;
                    case "POSTGRESQL":
                        oRetorn = oDbPostgresql.ExecuteTest(oConnect);

                        break;
                    default:
                        oRetorn = "Tipo de base de acesso nao foi informanda corretamente.";
                        break;
                }

                return oRetorn;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///  Retorna o dados de conexão
        /// </summary>
        /// <param name="oDataSetParamenter"> Entrada de dados para criação de chave de conexão de dados.</param>
        /// <returns></returns>
        protected String ConnectString(
            DataSet oDataSetParamenter)
        {
            try
            {
                String Key = "";
                String oConnect = "";
                String oDatabase = "";
                String Host = "";
                String User = "";
                String DBname = "";
                String Password = "";
                String Port = "5432";

                foreach (DataRow oRow in oDataSetParamenter.Tables[0].Rows)
                {

                    switch (oRow["Field_Name"].ToString())
                    {
                        case "DATABASE":
                            oDatabase = oRow["Field_Value"].ToString();
                            break;
                        case "HOSTNAME":
                            Host = oRow["Field_Value"].ToString();
                            break;
                        case "KEY_USER":
                            User = oCryptography.Decrypt(Key, oRow["Field_Value"].ToString());

                            break;
                        case "KEY":
                            Password = oCryptography.Decrypt(Key, oRow["Field_Value"].ToString());
                            break;
                        case "DBSCHEMA":
                            DBname = oRow["Field_Value"].ToString();
                            break;
                        case "PORT":
                            Port = oRow["Field_Value"].ToString();
                            break;
                        default:
                            break;
                    }

                }

                switch (oDatabase.ToUpper().Trim().TrimEnd().TrimStart())
                {
                    case "ORACLE":
                        oConnect = String.Format(
                                        "Server={0};Username={1};Database={2};Port={3};Password={4};SSLMode=Prefer",
                                        Host,
                                        User,
                                        DBname,
                                        Port,
                                        Password);
                        break;
                    case "MYSQL":
                        oConnect = String.Format(
                                        "Server={0};Username={1};Database={2};Port={3};Password={4};SSLMode=Prefer",
                                        Host,
                                        User,
                                        DBname,
                                        Port,
                                        Password);
                        break;
                    case "SQLSERVER":
                        oConnect = String.Format(
                                     "Server={0};Username={1};Database={2};Port={3};Password={4};SSLMode=Prefer",
                                     Host,
                                     User,
                                     DBname,
                                     Port,
                                     Password);
                        break;
                    case "POSTGRESQL":
                        oConnect = String.Format(
                                        "Host={0};Username={1};Database={2};Port={3};Password={4};SSLMode=Prefer",
                                        Host,
                                        User,
                                        DBname,
                                        Port,
                                        Password);
                        break;
                    default:
                        throw new InvalidOperationException("Tipo de base de acesso nao foi informanda corretamente !! Verifique !!");
                }
                return oConnect;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
