﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBase.Database.MySQL
{
    /// <summary>
    /// Classe de execução de Procedimentos no banco dados MySQL
    /// </summary>
    public class DbMySql
    {
        /// <summary>
        ///  Executar Query no banco de dados 
        /// </summary>
        /// <param name="oConnString"> Chave de Conexão no banco de dados</param>
        /// <param name="p_Select"> Query (Select a ser executado no banco de dados) podemos passar mais de uma query no final colocar (;)
        ///                         para iniciar uma novo select podendo caso informe mais de 1 select coloque (;) sempre no termino </param>
        /// <returns> Resultado do Query.</returns>
        public DataSet ExecuteSelect(String oConnString, String p_Select)
        {
            DataSet oReturn = new DataSet();
            try
            {
                using (MySqlConnection dbConnection = new MySqlConnection(oConnString))
                {
                    MySqlDataAdapter da = new MySqlDataAdapter();
                    da.SelectCommand = new MySqlCommand(p_Select, dbConnection);
                    da.Fill(oReturn);
                }
            }
            catch (Exception) { throw; }
            return oReturn;
        }

        /// <summary>
        /// Executando Teste de Conexão 
        /// </summary>
        /// <param name="oConnString"> Chave de conexão a ser testado</param>
        /// <returns></returns>
        public String ExecuteTest(String oConnString)
        {
            String oReturn = "";
            try
            {
                MySqlConnection dbConnection = new MySqlConnection(oConnString);
                dbConnection.Open();
                oReturn = "Connection Sucess|" + dbConnection.Database.ToString() + " State :" + dbConnection.State.ToString();
            }
            catch (Exception ex)
            {
                oReturn = "Error Connection|" + ex.Message.ToString();
            }
            return oReturn;
        }
    }
}
