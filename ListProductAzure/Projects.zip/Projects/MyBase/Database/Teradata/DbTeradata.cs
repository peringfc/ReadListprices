﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Teradata.Client.Provider;

namespace MyBase.Database.Teradata
{
    public  class DbTeradata
    {
        /// <summary>
        ///  Executar Query no banco de dados 
        /// </summary>
        /// <param name="oConnString"> Chave de Conexão no banco de dados</param>
        /// <param name="p_Select"> Query (Select a ser executado no banco de dados) podemos passar mais de uma query no final colocar (;)
        ///                         para iniciar uma novo select podendo caso informe mais de 1 select coloque (;) sempre no termino </param>
        /// <param name="Timeout"> Timeout de espera </param>
        /// <param name="alias_name"> alias name de conexão </param>
        /// <returns> Resultado do Query.</returns>
        public DataSet ExecuteSelect(String oConnString, String p_Select)
        {
            DataSet oReturn = new DataSet();
            try
            {
                using (TdConnection xtdConnection = new TdConnection(oConnString)) 
                {
                    xtdConnection.Open();
                    using (var xTdDataAdapter = new TdDataAdapter(p_Select, xtdConnection))
                    { 
                        xTdDataAdapter.SelectCommand.CommandTimeout = 1000;
                        xTdDataAdapter.Fill(oReturn);
                    }
                    xtdConnection.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return oReturn;
        }
        /// <summary>
        /// Executando Teste de Conexão 
        /// </summary>
        /// <param name="oConnString"> Chave de conexão a ser testado</param>
        /// <returns></returns>
        public String ExecuteTest(String oConnString)
        {
            String oReturn = "";
            try
            {
                using (TdConnection xtdConnection = new TdConnection(oConnString))
                {
                    xtdConnection.Open();
                    oReturn = "Connection Sucess|" + xtdConnection.Database.ToString() +
                        " State :" + xtdConnection.State.ToString();
                    xtdConnection.Close() ;
                }
            }
            catch (Exception ex)
            {
                oReturn = "Error Connection|" + ex.Message.ToString();
            }
            return oReturn;
        }
    }
}
