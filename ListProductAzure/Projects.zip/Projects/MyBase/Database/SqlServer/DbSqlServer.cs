﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace MyBase.Database.SqlServer
{
    /// <summary>
    /// Classe de execução de Procedimentos no banco dados SqlServer
    /// </summary>
    public class DbSqlServer
    {
        /// <summary>
        ///  Executar Query no banco de dados 
        /// </summary>
        /// <param name="oConnString"> Chave de Conexão no banco de dados</param>
        /// <param name="p_Select"> Query (Select a ser executado no banco de dados) podemos passar mais de uma query no final colocar (;)
        ///                         para iniciar uma novo select podendo caso informe mais de 1 select coloque (;) sempre no termino </param>
        /// <returns> Resultado do Query.</returns>

        public DataSet ExecuteSelect(String oConnString, String p_Select)
        {
            DataSet oReturn = new DataSet();
            try
            {
                using (SqlDataAdapter da = new SqlDataAdapter(p_Select, oConnString))
                {
                    da.Fill(oReturn);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return oReturn;
        }

        /// <summary>
        /// Executando Teste de Conexão 
        /// </summary>
        /// <param name="oConnString"> Chave de conexão a ser testado</param>
        /// <returns></returns>
        public String ExecuteTest(String oConnString)
        {
            String oReturn = "";
            try
            {
                SqlConnection dbConnection = new SqlConnection(oConnString);
                dbConnection.Open();
                oReturn = "Connection Sucess|" + dbConnection.Database.ToString() + " State :" + dbConnection.State.ToString();
            }
            catch (Exception ex)
            {
                oReturn = "Error Connection|" + ex.Message.ToString();
            }
            return oReturn;
        }

    }

}
