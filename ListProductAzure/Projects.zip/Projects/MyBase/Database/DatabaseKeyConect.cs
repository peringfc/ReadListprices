﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBase.Database
{
    public class DatabaseKeyConect
    {
        ////
        /// <summary>
        ///  Chave de acesso a base de dados.
        /// </summary>
        /// <param name="alias_connect"></param>
        /// <returns></returns>
        public string key(string alias_connect)
        {
            DatabaseConect oParameters = new DatabaseConect();
            return oParameters.KeyDatabase(alias_connect);
        }
    }

}
