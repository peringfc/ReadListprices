﻿using MyTools.Convert;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBase.Database
{
    public class DataBaseQuery
    {
        DatabaseConect oDatabaseConect = new DatabaseConect();
        XMLtoJSON oXMLtoJSON = new XMLtoJSON();
        /// <summary>
        ///    Pesquisa de uma Query (Select na base de dados selecioanda
        /// </summary>
        /// <param name="p_Alias"> Nome da Conexão ultilizada</param>
        /// <param name="p_Query"> Select a ser executado </param>
        /// <param name="p_Retorno"> Tipo de Retorno JSON ou XML </param>
        /// <returns> O retorno pode ser em XML ou Json caso nao seja informado o Default sera em Json</returns>
        public string ExecuteQuery (String p_Alias, String p_Query, String p_Retorno)
        {
            //String oRetorno = null;
            try
            {
                DataSet oPesquisa = new DataSet();
                oPesquisa = oDatabaseConect.ExecuteSelect(p_Alias, p_Query);
                switch (p_Retorno.ToUpper().Trim().TrimEnd().TrimStart())
                {
                    case "JSON":
                        return oXMLtoJSON.Convert(oPesquisa);
                    case "XML":
                        return oPesquisa.GetXml();
                    default:
                        return oXMLtoJSON.Convert(oPesquisa);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
