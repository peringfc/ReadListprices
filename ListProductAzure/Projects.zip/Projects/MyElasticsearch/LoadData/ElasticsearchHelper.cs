﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using Nest;

namespace MyElasticsearch.LoadData
{
    public class ElasticsearchHelper
    {
        private readonly ElasticClient _client;

        /// <summary>
        /// Conexäo ba base de dados do ELK
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="username"></param>
        /// <param name="password"></param>
        public ElasticsearchHelper(string uri, string username, string password)
        {
            var settings = new ConnectionSettings(new Uri(uri))
                .BasicAuthentication(username, password);
            _client = new ElasticClient(settings);
        }

        /// <summary>
        /// Converter um dataset em formato de Obj de POC de Lista.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSet"> Informa dataset para carregar no formato de POC</param>
        /// <returns></returns>
        public List<T> ConvertDataSetToPoc<T>(DataSet dataSet) where T : class, new()
        {
            var dataTable = dataSet.Tables[0];
            var pocList = new List<T>();
            foreach (DataRow row in dataTable.Rows)
            {
                var poc = new T();
                foreach (var prop in typeof(T).GetProperties())
                {
                    if (dataTable.Columns.Contains(prop.Name) && row[prop.Name] != DBNull.Value)
                    {
                        prop.SetValue(poc, Convert.ChangeType(row[prop.Name], prop.PropertyType));
                    }
                }
                pocList.Add(poc);
            }
            return pocList;
        }

        /// <summary>
        /// Processo que carrega um resultado de um array ou lista de Objetos em um base de dados ELK
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="pocList"> Lista de dados em formando de Objeto no formato de POC</param>
        /// <param name="indexName"> Nome do Indice que deve ser carregados os dados </param>
        /// <exception cref="Exception"></exception>
        public void IndexPocList<T>(List<T> pocList, string indexName) where T : class
        {
            var existsResponse = _client.Indices.Exists(indexName);
            if (!existsResponse.Exists)
            {
                var createIndexResponse = _client.Indices.Create(indexName, c => c
                    .Map<T>(m => m.AutoMap())
                );
                if (!createIndexResponse.IsValid)
                {
                    throw new Exception("Failed ELK to create index: " + createIndexResponse.ServerError.Error.Reason);
                }
            }

            var bulkResponse = _client.Bulk(b => b
                .IndexMany(pocList, (descriptor, poc) => descriptor.Index(indexName))
            );

            if (bulkResponse.Errors)
            {
                throw new Exception("Failed  ELK to index documents: " + bulkResponse.ItemsWithErrors.First().Error.Reason);
            }
        }
    }
}
