﻿using System;
using System.Collections.Generic;
using Nest;

namespace MyElasticsearch.Elasticsearch
{
    public class ElasticsearchService
    {
        private readonly ElasticClient _client;

        /// <summary>
        ///  Realiza conexão ao banco de dados 
        /// </summary>
        /// <param name="uri"> URL do banco Elasticsearch </param>
        /// <param name="username"> Usuario </param>
        /// <param name="password"> Senha de acesso </param>
        public ElasticsearchService(string uri, string username, string password)
        {
            var settings = new ConnectionSettings(new Uri(uri))
                .BasicAuthentication(username, password);
            _client = new ElasticClient(settings);
        }

        /// <summary>
        ///  Realiza o pesquisa so KQL na base do Elasticsearch
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="indexName"> Indice de pesquis </param>
        /// <param name="query"> Query que devera ser realizado </param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public List<T> Search<T>(string indexName, string query) where T : class
        {
            var searchResponse = _client.Search<T>(s => s
                .Index(indexName)
                .Query(q => q
                    .QueryString(qs => qs
                        .Query(query)
                    )
                )
            );

            if (!searchResponse.IsValid)
            {
                throw new Exception("Failed to execute search query: " + searchResponse.ServerError.Error.Reason);
            }
            return searchResponse.Documents.ToList();
        }
    }
}
