﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyElasticsearch.Structuring
{
    public class ELK_Config_Access
    {
        public string? ELK_User { get; set; }
        public string? ELK_Pwd { get; set; }
        public string? ELK_URL { get; set; }
    }
}
