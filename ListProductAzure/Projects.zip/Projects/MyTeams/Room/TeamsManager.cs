﻿using Microsoft.Graph;
using Microsoft.Identity.Client;
//using Microsoft.Graph.Models;
namespace MyTeams.Room
{

    /// <summary>
    ///   Para criar uma classe em C# que se conecta ao Microsoft Teams, cria uma sala (time), adiciona usuários através de seus emails, envia uma mensagem para todos os membros e retorna o ID da sala criada, você pode usar a biblioteca Microsoft.Graph. Aqui está um exemplo detalhado de como implementar essa funcionalidade.
    ///      Passo a Passo
    ///      Configurar o Microsoft Graph:
    ///      Registre uma aplicação no Azure Active Directory(Azure AD) e atribua 
    ///      permissões adequadas, 
    ///      como Group.ReadWrite.All e Chat.ReadWrite.
    ///      Instalar Pacotes Necessários:
    ///  Instale os pacotes NuGet Microsoft.Graph e Microsoft.Identity.Client:
    ///     dotnet add package Microsoft.Graph
    ///     dotnet add package Microsoft.Identity.Client
    /// </summary>


    //public class TeamsManager
    //{
    //    private readonly GraphServiceClient _graphClient;
    //    private readonly List<string> _userEmails;

    //    public TeamsManager(string clientId, string tenantId, string clientSecret, List<string> userEmails)
    //    {
    //        _userEmails = userEmails;
    //        _graphClient = Authenticate(clientId, tenantId, clientSecret).GetAwaiter().GetResult();
    //    }

    //    private async Task<GraphServiceClient> Authenticate(string clientId, string tenantId, string clientSecret)
    //    {
    //        IConfidentialClientApplication app = ConfidentialClientApplicationBuilder
    //            .Create(clientId)
    //            .WithTenantId(tenantId)
    //            .WithClientSecret(clientSecret)
    //            .Build();

    //        var authProvider = new ClientCredentialProvider(app);
    //        return new GraphServiceClient(authProvider);
    //    }

    //    public async Task<string> CreateTeamAndSendMessage(string teamName, string channelName)
    //    {
    //        // Criar o time
    //        var team = new Team
    //        {
    //            DisplayName = teamName,
    //            Description = "Time criado por um bot",
    //            Visibility = TeamVisibilityType.Private
    //        };

    //        var createdTeam = await _graphClient.Teams.Request().AddAsync(team);

    //        // Criar um canal
    //        var channel = new Channel
    //        {
    //            DisplayName = channelName,
    //            Description = "Canal criado por um bot"
    //        };

    //        var createdChannel = await _graphClient.Teams[createdTeam.Id].Channels.Request().AddAsync(channel);

    //        // Adicionar usuários ao time
    //        foreach (var email in _userEmails)
    //        {
    //            try
    //            {
    //                var user = await _graphClient.Users[email].Request().GetAsync();
    //                var member = new AadUserConversationMember
    //                {
    //                    Roles = new List<string> { "member" },
    //                    UserId = user.Id
    //                };
    //                await _graphClient.Teams[createdTeam.Id].Members.Request().AddAsync(member);
    //            }
    //            catch (ServiceException ex)
    //            {
    //                Console.WriteLine($"Erro ao adicionar usuário {email}: {ex.Message}");
    //            }
    //        }

    //        // Enviar mensagem
    //        await SendMessage(createdTeam.Id, createdChannel.Id, "Olá pessoal");

    //        // Retornar o ID da sala criada
    //        return createdTeam.Id;
    //    }

    //    private async Task SendMessage(string teamId, string channelId, string messageText)
    //    {
    //        var chatMessage = new ChatMessage
    //        {
    //            Body = new ItemBody
    //            {
    //                ContentType = BodyType.Text,
    //                Content = messageText
    //            }
    //        };

    //        await _graphClient.Teams[teamId].Channels[channelId].Messages.Request().AddAsync(chatMessage);
    //    }
    //}
}

//exemplo
//class Program
//{
//    static async Task Main()
//    {
//        string clientId = "YOUR_CLIENT_ID"; // Substitua pelo seu Client ID
//        string tenantId = "YOUR_TENANT_ID"; // Substitua pelo seu Tenant ID
//        string clientSecret = "YOUR_CLIENT_SECRET"; // Substitua pelo seu Client Secret
//        List<string> userEmails = new List<string>
//        {
//            "user1@example.com", // Substitua pelos emails dos usuários
//            "user2@example.com"
//        };

//        var teamsManager = new TeamsManager(clientId, tenantId, clientSecret, userEmails);
//        string teamId = await teamsManager.CreateTeamAndSendMessage("Nome do Time", "Nome do Canal");
//        Console.WriteLine($"ID do time criado: {teamId}");
//    }
}