﻿using Microsoft.Graph;
using Microsoft.Identity.Client;
using MyTeams.Room;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyTeams.Room
{
    public class TeamsMessageFetcher
    {
        private readonly GraphServiceClient _graphClient;

        public TeamsMessageFetcher(string clientId, string tenantId, string clientSecret)
        {
            _graphClient = Authenticate(clientId, tenantId, clientSecret).GetAwaiter().GetResult();
        }

        private async Task<GraphServiceClient> Authenticate(string clientId, string tenantId, string clientSecret)
        {
            IConfidentialClientApplication app = ConfidentialClientApplicationBuilder
                .Create(clientId)
                .WithTenantId(tenantId)
                .WithClientSecret(clientSecret)
                .Build();

            var authProvider = new ClientCredentialProvider(app);
            return new GraphServiceClient(authProvider);
        }

        public async Task<List<TeamsMessageDetails>> FetchMessages(string teamId, string channelId)
        {
            var messages = new List<TeamsMessageDetails>();

            try
            {
                var chatMessages = await _graphClient.Teams[teamId].Channels[channelId].Messages
                    .Request()
                    .GetAsync();

                // Iterar sobre as mensagens e adicionar aos detalhes
                do
                {
                    foreach (var message in chatMessages)
                    {
                        var senderEmail = message.From.User?.Email ?? "Desconhecido";
                        var senderName = message.From.User?.DisplayName ?? "Desconhecido";

                        messages.Add(new TeamsMessageDetails
                        {
                            MessageId = message.Id,
                            SenderName = senderName,
                            SenderEmail = senderEmail,
                            MessageContent = message.Body.Content,
                            SentTime = message.CreatedDateTime.Value
                        });
                    }

                    // Verifica se há mais mensagens
                    chatMessages = chatMessages.NextPageRequest != null ? await chatMessages.NextPageRequest.GetAsync() : null;

                } while (chatMessages != null);
            }
            catch (ServiceException ex)
            {
                Console.WriteLine($"Erro ao buscar mensagens: {ex.Message}");
            }

            return messages;
        }
    }

    public class TeamsMessageDetails
    {
        public string? MessageId { get; set; }
        public string? SenderName { get; set; }
        public string? SenderEmail { get; set; }
        public string? MessageContent { get; set; }
        public DateTimeOffset SentTime { get; set; }
    }
}


////exemplo
//class Program
//{
//    static async Task Main()
//    {
//        string clientId = "YOUR_CLIENT_ID"; // Substitua pelo seu Client ID
//        string tenantId = "YOUR_TENANT_ID"; // Substitua pelo seu Tenant ID
//        string clientSecret = "YOUR_CLIENT_SECRET"; // Substitua pelo seu Client Secret
//        string teamId = "YOUR_TEAM_ID"; // Substitua pelo ID do time
//        string channelId = "YOUR_CHANNEL_ID"; // Substitua pelo ID do canal

//        var messageFetcher = new TeamsMessageFetcher(clientId, tenantId, clientSecret);
//        var messages = await messageFetcher.FetchMessages(teamId, channelId);

//        foreach (var message in messages)
//        {
//            Console.WriteLine($"ID: {message.MessageId}");
//            Console.WriteLine($"Nome: {message.SenderName}");
//            Console.WriteLine($"Email: {message.SenderEmail}");
//            Console.WriteLine($"Mensagem: {message.MessageContent}");
//            Console.WriteLine($"Data/Hora: {message.SentTime}");
//            Console.WriteLine(new string('-', 20));
//        }
//    }
//}