﻿namespace MyTestNFT
{
    public class Class1
    {

    }
}
