﻿
namespace MySmtpServer
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            string smtpServer = "smtp.yourserver.com";
            int smtpPort = 587; // Porta do servidor SMTP real
            string smtpUsername = "your-email@example.com";
            string smtpPassword = "your-email-password";

            var emailForwarder = new EmailForwarder(smtpServer, smtpPort, smtpUsername, smtpPassword);
            var smtpServerEmulator = new SmtpServer(25, emailForwarder); // Porta do servidor SMTP emulado

            await smtpServerEmulator.StartAsync();
        }
    }
}
