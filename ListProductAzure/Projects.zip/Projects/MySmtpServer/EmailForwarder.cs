﻿using System;
using System.Linq;
using System.Net;
using System.Net.Mail;

namespace MySmtpServer
{
    public class EmailForwarder
    {
        private readonly string _smtpServer;
        private readonly int _smtpPort;
        private readonly string _smtpUsername;
        private readonly string _smtpPassword;

        public EmailForwarder(string smtpServer, int smtpPort, string smtpUsername, string smtpPassword)
        {
            _smtpServer = smtpServer;
            _smtpPort = smtpPort;
            _smtpUsername = smtpUsername;
            _smtpPassword = smtpPassword;
        }

        public void ForwardEmail(string htmlContent, string emailAddresses, string subject)
        {
            var mailMessage = new MailMessage();
            mailMessage.From = new MailAddress(_smtpUsername);

            foreach (var email in emailAddresses.Split(';').Where(e => !string.IsNullOrWhiteSpace(e)))
            {
                mailMessage.To.Add(email.Trim());
            }

            mailMessage.Subject = subject;
            mailMessage.Body = htmlContent;
            mailMessage.IsBodyHtml = true;

            using (var smtpClient = new SmtpClient(_smtpServer, _smtpPort))
            {
                smtpClient.Credentials = new NetworkCredential(_smtpUsername, _smtpPassword);
                smtpClient.EnableSsl = true; // Defina para false se o servidor não usar SSL
                smtpClient.Send(mailMessage);
            }
        }
    }
}
