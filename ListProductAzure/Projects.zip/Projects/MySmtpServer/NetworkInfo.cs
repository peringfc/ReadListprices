﻿
using System;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
namespace MySmtpServer
{
    public class NetworkInfo
    {
        public static void ListIPAddresses()
        {
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                Console.WriteLine($"Interface: {ni.Name}");
                IPInterfaceProperties properties = ni.GetIPProperties();

                foreach (UnicastIPAddressInformation ip in properties.UnicastAddresses)
                {
                    if (ip.Address.AddressFamily == AddressFamily.InterNetwork ||
                        ip.Address.AddressFamily == AddressFamily.InterNetworkV6)
                    {
                        Console.WriteLine($"  IP Address : {ip.Address}");
                    }
                }
            }
        }
    }
}
