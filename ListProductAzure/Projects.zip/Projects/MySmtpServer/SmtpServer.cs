﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;


namespace MySmtpServer
{
    public class SmtpServer
    {
        private readonly int _port;
        private readonly EmailForwarder _emailForwarder;

        public SmtpServer(int port, EmailForwarder emailForwarder)
        {
            _port = port;
            _emailForwarder = emailForwarder;
        }

        public async Task StartAsync()
        {
            TcpListener listener = new TcpListener(IPAddress.Any, _port);
            listener.Start();
            Console.WriteLine($"+------------------------------------+");
            Console.WriteLine($"|  SMTP Server Simples MySMTPServer  ");
            Console.WriteLine($"|  IP...: {IPAddress.Any}.");
            Console.WriteLine($"|  Port.: {_port}.");
            Console.WriteLine($"+------------------------------------+");
            NetworkInfo.ListIPAddresses();

            while (true)
            {
                var client = await listener.AcceptTcpClientAsync();
                _ = HandleClientAsync(client);
            }
        }

        private async Task HandleClientAsync(TcpClient client)
        {
            using (var networkStream = client.GetStream())
            using (var reader = new StreamReader(networkStream, Encoding.ASCII))
            using (var writer = new StreamWriter(networkStream, Encoding.ASCII) { AutoFlush = true })
            {
                await writer.WriteLineAsync("220 Simple SMTP Server");

                string sender = null;
                string recipients = null;
                StringBuilder data = new StringBuilder();

                string line;
                while ((line = await reader.ReadLineAsync()) != null)
                {
                    Console.WriteLine($"Received: {line}");
                    if (line.StartsWith("HELO") || line.StartsWith("EHLO"))
                    {
                        await writer.WriteLineAsync("250 Hello");
                    }
                    else if (line.StartsWith("MAIL FROM:"))
                    {
                        sender = line.Substring(10).Trim();
                        await writer.WriteLineAsync("250 OK");
                    }
                    else if (line.StartsWith("RCPT TO:"))
                    {
                        if (recipients == null)
                        {
                            recipients = line.Substring(8).Trim();
                        }
                        else
                        {
                            recipients += ";" + line.Substring(8).Trim();
                        }
                        await writer.WriteLineAsync("250 OK");
                    }
                    else if (line.StartsWith("DATA"))
                    {
                        await writer.WriteLineAsync("354 End data with <CR><LF>.<CR><LF>");
                        while ((line = await reader.ReadLineAsync()) != ".")
                        {
                            data.AppendLine(line);
                        }
                        await writer.WriteLineAsync("250 OK");

                        // Process the received email
                        string subject = "Forwarded Email"; // Customize as needed
                        _emailForwarder.ForwardEmail(data.ToString(), recipients, subject);
                        data.Clear();
                    }
                    else if (line.StartsWith("QUIT"))
                    {
                        await writer.WriteLineAsync("221 Bye");
                        break;
                    }
                    else
                    {
                        await writer.WriteLineAsync("502 Command not implemented");
                    }
                }
            }

            client.Close();
        }
    }
}
