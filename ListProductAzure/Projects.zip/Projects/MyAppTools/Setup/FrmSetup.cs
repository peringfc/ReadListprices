﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyAppTools.Setup
{
    public partial class FrmSetup : Form
    {
        public FrmSetup()
        {
            InitializeComponent();
            txtSearch.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmSetupBase oFrmSetupBase = new FrmSetupBase();
            oFrmSetupBase.ShowDialog();
        }
    }
}
