﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyAppTools.Collection.Metrics.Business
{
    public partial class FrmComponetsChart : Form
    {
        public FrmComponetsChart()
        {
            InitializeComponent();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmHelpChartELK oFrmHelpChartELK =new FrmHelpChartELK();
            oFrmHelpChartELK.ShowDialog();
        }
    }
}
