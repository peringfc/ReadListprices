﻿namespace MyAppTools.Collection.Metrics.Business
{
    partial class FrmBusinessMetrics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            groupBox1 = new GroupBox();
            button1 = new Button();
            button2 = new Button();
            comboBox1 = new ComboBox();
            label1 = new Label();
            groupBox2 = new GroupBox();
            dataGridView1 = new DataGridView();
            groupBox3 = new GroupBox();
            lbl_coluns = new Label();
            lbl_rows_total = new Label();
            lblTempo_execucao = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            groupBox4 = new GroupBox();
            lbl_Valid_Query = new Label();
            groupBox5 = new GroupBox();
            comboBox2 = new ComboBox();
            groupBox6 = new GroupBox();
            dataGridView2 = new DataGridView();
            button3 = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Dock = DockStyle.Fill;
            textBox1.Location = new Point(3, 27);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(751, 202);
            textBox1.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox1);
            groupBox1.Location = new Point(12, 6);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(757, 232);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Query - Select";
            // 
            // button1
            // 
            button1.Location = new Point(1026, 51);
            button1.Name = "button1";
            button1.Size = new Size(210, 34);
            button1.TabIndex = 3;
            button1.Text = "Salve Query";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(784, 51);
            button2.Name = "button2";
            button2.Size = new Size(207, 34);
            button2.TabIndex = 4;
            button2.Text = "Validar Query";
            button2.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(867, 12);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(369, 33);
            comboBox1.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(775, 9);
            label1.Name = "label1";
            label1.Size = new Size(86, 25);
            label1.TabIndex = 6;
            label1.Text = "Database";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(dataGridView1);
            groupBox2.Location = new Point(12, 238);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(757, 291);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Grid";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(3, 27);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(751, 261);
            dataGridView1.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(lbl_coluns);
            groupBox3.Controls.Add(lbl_rows_total);
            groupBox3.Controls.Add(lblTempo_execucao);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(label3);
            groupBox3.Controls.Add(label2);
            groupBox3.Location = new Point(784, 91);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(452, 126);
            groupBox3.TabIndex = 8;
            groupBox3.TabStop = false;
            groupBox3.Text = "Dados";
            // 
            // lbl_coluns
            // 
            lbl_coluns.AutoSize = true;
            lbl_coluns.Location = new Point(184, 88);
            lbl_coluns.Name = "lbl_coluns";
            lbl_coluns.Size = new Size(52, 25);
            lbl_coluns.TabIndex = 5;
            lbl_coluns.Text = "0000";
            // 
            // lbl_rows_total
            // 
            lbl_rows_total.AutoSize = true;
            lbl_rows_total.Location = new Point(184, 57);
            lbl_rows_total.Name = "lbl_rows_total";
            lbl_rows_total.Size = new Size(144, 25);
            lbl_rows_total.TabIndex = 4;
            lbl_rows_total.Text = "000.000.000.000";
            // 
            // lblTempo_execucao
            // 
            lblTempo_execucao.AutoSize = true;
            lblTempo_execucao.Location = new Point(184, 27);
            lblTempo_execucao.Name = "lblTempo_execucao";
            lblTempo_execucao.Size = new Size(80, 25);
            lblTempo_execucao.TabIndex = 3;
            lblTempo_execucao.Text = "00:00:00";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(32, 88);
            label4.Name = "label4";
            label4.Size = new Size(146, 25);
            label4.TabIndex = 2;
            label4.Text = "Total de Colunas:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 57);
            label3.Name = "label3";
            label3.Size = new Size(132, 25);
            label3.TabIndex = 1;
            label3.Text = "Total de Linhas:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 27);
            label2.Name = "label2";
            label2.Size = new Size(172, 25);
            label2.TabIndex = 0;
            label2.Text = "Tempo de execução:";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(lbl_Valid_Query);
            groupBox4.Location = new Point(12, 535);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(757, 79);
            groupBox4.TabIndex = 10;
            groupBox4.TabStop = false;
            groupBox4.Text = "Regras Query";
            // 
            // lbl_Valid_Query
            // 
            lbl_Valid_Query.AutoSize = true;
            lbl_Valid_Query.Location = new Point(6, 27);
            lbl_Valid_Query.Name = "lbl_Valid_Query";
            lbl_Valid_Query.Size = new Size(103, 25);
            lbl_Valid_Query.TabIndex = 3;
            lbl_Valid_Query.Text = "- No Valid -";
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(comboBox2);
            groupBox5.Location = new Point(784, 223);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(452, 76);
            groupBox5.TabIndex = 13;
            groupBox5.TabStop = false;
            groupBox5.Text = "Tempo de Coleta:";
            // 
            // comboBox2
            // 
            comboBox2.AutoCompleteMode = AutoCompleteMode.Suggest;
            comboBox2.AutoCompleteSource = AutoCompleteSource.ListItems;
            comboBox2.FlatStyle = FlatStyle.Popup;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "01 - Hora", "01 - Minuto", "03 - Minutos", "05 - Minutos", "06 - Horas", "12 - Horas", "15 - Minutos", "24 - Horas", "40 - Minutos" });
            comboBox2.Location = new Point(6, 30);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(440, 33);
            comboBox2.TabIndex = 14;
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(dataGridView2);
            groupBox6.Location = new Point(784, 305);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(452, 224);
            groupBox6.TabIndex = 14;
            groupBox6.TabStop = false;
            groupBox6.Text = "Dados do Dashboard";
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToAddRows = false;
            dataGridView2.AllowUserToDeleteRows = false;
            dataGridView2.AllowUserToOrderColumns = true;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Dock = DockStyle.Fill;
            dataGridView2.Location = new Point(3, 27);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.ReadOnly = true;
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.Size = new Size(446, 194);
            dataGridView2.TabIndex = 0;
            // 
            // button3
            // 
            button3.Image = Properties.Resources.Monitor;
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(784, 535);
            button3.Name = "button3";
            button3.Size = new Size(446, 67);
            button3.TabIndex = 15;
            button3.Text = "Dashboards";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // FrmBusinessMetrics
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1248, 626);
            Controls.Add(button3);
            Controls.Add(groupBox6);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Controls.Add(comboBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmBusinessMetrics";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Business Database Metrics Collection";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private GroupBox groupBox1;
        private Button button1;
        private Button button2;
        private ComboBox comboBox1;
        private Label label1;
        private GroupBox groupBox2;
        private DataGridView dataGridView1;
        private GroupBox groupBox3;
        private Label lbl_coluns;
        private Label lbl_rows_total;
        private Label lblTempo_execucao;
        private Label label4;
        private Label label3;
        private Label label2;
        private GroupBox groupBox4;
        private Label lbl_Valid_Query;
        private GroupBox groupBox5;
        private ComboBox comboBox2;
        private GroupBox groupBox6;
        private DataGridView dataGridView2;
        private Button button3;
    }
}