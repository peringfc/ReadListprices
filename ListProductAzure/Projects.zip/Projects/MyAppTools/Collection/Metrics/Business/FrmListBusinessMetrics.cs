﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyAppTools.Collection.Metrics.Business
{
    public partial class FrmListBusinessMetrics : Form
    {
        public FrmListBusinessMetrics()
        {
            InitializeComponent();
            txtSearch.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmBusinessMetrics oFrmBusinessMetrics = new FrmBusinessMetrics();
            oFrmBusinessMetrics.ShowDialog();
        }
    }
}
