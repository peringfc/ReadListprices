﻿namespace MyAppTools.Collection.Metrics.Business
{
    partial class FrmListBusinessMetrics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridConfig = new DataGridView();
            groupBox1 = new GroupBox();
            button2 = new Button();
            button1 = new Button();
            txtSearch = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridConfig).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridConfig
            // 
            dataGridConfig.AllowUserToAddRows = false;
            dataGridConfig.AllowUserToDeleteRows = false;
            dataGridConfig.AllowUserToOrderColumns = true;
            dataGridConfig.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridConfig.Dock = DockStyle.Fill;
            dataGridConfig.Location = new Point(0, 69);
            dataGridConfig.Name = "dataGridConfig";
            dataGridConfig.ReadOnly = true;
            dataGridConfig.RowHeadersWidth = 62;
            dataGridConfig.Size = new Size(994, 625);
            dataGridConfig.TabIndex = 3;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(txtSearch);
            groupBox1.Dock = DockStyle.Top;
            groupBox1.Location = new Point(0, 0);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(994, 69);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            // 
            // button2
            // 
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Image = Properties.Resources.Search;
            button2.Location = new Point(817, 23);
            button2.Name = "button2";
            button2.RightToLeft = RightToLeft.Yes;
            button2.Size = new Size(164, 33);
            button2.TabIndex = 2;
            button2.Text = "Nova Metrica";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(638, 23);
            button1.Name = "button1";
            button1.Size = new Size(164, 34);
            button1.TabIndex = 1;
            button1.Text = "Pesquisa";
            button1.UseVisualStyleBackColor = true;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(7, 23);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(625, 31);
            txtSearch.TabIndex = 0;
            // 
            // FrmListBusinessMetrics
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(994, 694);
            Controls.Add(dataGridConfig);
            Controls.Add(groupBox1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmListBusinessMetrics";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Metricas";
            ((System.ComponentModel.ISupportInitialize)dataGridConfig).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridConfig;
        private GroupBox groupBox1;
        private Button button2;
        private Button button1;
        private TextBox txtSearch;
    }
}