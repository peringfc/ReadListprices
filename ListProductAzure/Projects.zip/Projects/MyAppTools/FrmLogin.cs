namespace MyAppTools
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void butLogin_Click(object sender, EventArgs e)
        {
            FrmMain ofrmMain = 
                new FrmMain(
                    txtLogin.Text,
                    txtUrl.Text,
                    txtPwd.Text);
            ofrmMain.ShowDialog();
        }
    }
}
