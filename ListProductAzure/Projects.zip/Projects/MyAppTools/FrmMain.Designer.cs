﻿namespace MyAppTools
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            butSetup = new Button();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            statusStrip1 = new StatusStrip();
            tool_login = new ToolStripStatusLabel();
            tool_url = new ToolStripStatusLabel();
            tool_Msg = new ToolStripStatusLabel();
            statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // butSetup
            // 
            butSetup.Image = Properties.Resources.Updates;
            butSetup.ImageAlign = ContentAlignment.TopLeft;
            butSetup.Location = new Point(12, 12);
            butSetup.Name = "butSetup";
            butSetup.Size = new Size(224, 181);
            butSetup.TabIndex = 0;
            butSetup.Text = "Setup";
            butSetup.TextAlign = ContentAlignment.BottomRight;
            butSetup.UseVisualStyleBackColor = true;
            butSetup.Click += butSetup_Click;
            // 
            // button1
            // 
            button1.Enabled = false;
            button1.Image = Properties.Resources.App_Service_Domains;
            button1.ImageAlign = ContentAlignment.TopLeft;
            button1.Location = new Point(472, 12);
            button1.Name = "button1";
            button1.Size = new Size(224, 181);
            button1.TabIndex = 1;
            button1.Text = "Analise Sintática";
            button1.TextAlign = ContentAlignment.BottomRight;
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Enabled = false;
            button2.Image = Properties.Resources.Azure_Data_Catalog;
            button2.ImageAlign = ContentAlignment.TopLeft;
            button2.Location = new Point(242, 199);
            button2.Name = "button2";
            button2.Size = new Size(224, 180);
            button2.TabIndex = 2;
            button2.Text = "Databases";
            button2.TextAlign = ContentAlignment.BottomRight;
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Image = Properties.Resources.Application_Gateways;
            button3.ImageAlign = ContentAlignment.TopLeft;
            button3.Location = new Point(702, 13);
            button3.Name = "button3";
            button3.Size = new Size(224, 180);
            button3.TabIndex = 3;
            button3.Text = "Coletas Metricas Database";
            button3.TextAlign = ContentAlignment.BottomRight;
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Enabled = false;
            button4.Image = Properties.Resources.Time_Series_Insights_Environments;
            button4.ImageAlign = ContentAlignment.TopLeft;
            button4.Location = new Point(702, 199);
            button4.Name = "button4";
            button4.Size = new Size(224, 180);
            button4.TabIndex = 7;
            button4.Text = "Coletas Ativos";
            button4.TextAlign = ContentAlignment.BottomRight;
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Enabled = false;
            button5.Image = Properties.Resources.Container_Registries;
            button5.ImageAlign = ContentAlignment.TopLeft;
            button5.Location = new Point(242, 13);
            button5.Name = "button5";
            button5.Size = new Size(224, 180);
            button5.TabIndex = 6;
            button5.Text = "Analise Container";
            button5.TextAlign = ContentAlignment.BottomRight;
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Enabled = false;
            button6.Image = Properties.Resources.Azure_Database_Migration_Services;
            button6.ImageAlign = ContentAlignment.TopLeft;
            button6.Location = new Point(472, 199);
            button6.Name = "button6";
            button6.Size = new Size(224, 180);
            button6.TabIndex = 5;
            button6.Text = "Analise Bancos";
            button6.TextAlign = ContentAlignment.BottomRight;
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Enabled = false;
            button7.Image = Properties.Resources.Active_Directory_Connect_Health;
            button7.ImageAlign = ContentAlignment.TopLeft;
            button7.Location = new Point(12, 199);
            button7.Name = "button7";
            button7.Size = new Size(224, 180);
            button7.TabIndex = 4;
            button7.Text = "Analise de Logs";
            button7.TextAlign = ContentAlignment.BottomRight;
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Enabled = false;
            button8.Image = Properties.Resources.Automation_Accounts;
            button8.ImageAlign = ContentAlignment.TopLeft;
            button8.Location = new Point(702, 385);
            button8.Name = "button8";
            button8.Size = new Size(224, 180);
            button8.TabIndex = 11;
            button8.Text = "Execução de Testes";
            button8.TextAlign = ContentAlignment.BottomRight;
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Enabled = false;
            button9.Image = Properties.Resources.Web_Environment;
            button9.ImageAlign = ContentAlignment.TopLeft;
            button9.Location = new Point(472, 385);
            button9.Name = "button9";
            button9.Size = new Size(224, 180);
            button9.TabIndex = 10;
            button9.Text = "Injetoras";
            button9.TextAlign = ContentAlignment.BottomRight;
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Enabled = false;
            button10.Image = Properties.Resources.Virtual_Clusters;
            button10.ImageAlign = ContentAlignment.TopLeft;
            button10.Location = new Point(12, 385);
            button10.Name = "button10";
            button10.Size = new Size(224, 180);
            button10.TabIndex = 9;
            button10.Text = "Analise de SO (Linux)";
            button10.TextAlign = ContentAlignment.BottomRight;
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Enabled = false;
            button11.Image = Properties.Resources.Event_Grid_Domains;
            button11.ImageAlign = ContentAlignment.TopLeft;
            button11.Location = new Point(242, 385);
            button11.Name = "button11";
            button11.Size = new Size(224, 180);
            button11.TabIndex = 8;
            button11.Text = "Analise de Testes";
            button11.TextAlign = ContentAlignment.BottomRight;
            button11.UseVisualStyleBackColor = true;
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(24, 24);
            statusStrip1.Items.AddRange(new ToolStripItem[] { tool_login, tool_url, tool_Msg });
            statusStrip1.Location = new Point(0, 580);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(936, 32);
            statusStrip1.TabIndex = 12;
            statusStrip1.Text = "statusStrip1";
            // 
            // tool_login
            // 
            tool_login.Name = "tool_login";
            tool_login.Size = new Size(56, 25);
            tool_login.Text = "Login";
            // 
            // tool_url
            // 
            tool_url.Name = "tool_url";
            tool_url.Size = new Size(179, 25);
            tool_url.Text = "toolStripStatusLabel1";
            // 
            // tool_Msg
            // 
            tool_Msg.Name = "tool_Msg";
            tool_Msg.Size = new Size(100, 25);
            tool_Msg.Text = "Mensagem";
            // 
            // FrmMain
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(936, 612);
            Controls.Add(statusStrip1);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button4);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(butSetup);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmMain";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main";
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button butSetup;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel tool_Msg;
        private ToolStripStatusLabel tool_login;
        private ToolStripStatusLabel tool_url;
    }
}