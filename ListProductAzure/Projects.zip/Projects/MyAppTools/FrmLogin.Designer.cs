﻿namespace MyAppTools
{
    partial class FrmLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label3 = new Label();
            txtUrl = new TextBox();
            label2 = new Label();
            label1 = new Label();
            txtPwd = new TextBox();
            txtLogin = new TextBox();
            butLogin = new Button();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtUrl);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtPwd);
            groupBox1.Controls.Add(txtLogin);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(386, 181);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "User";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(54, 115);
            label3.Name = "label3";
            label3.Size = new Size(43, 25);
            label3.TabIndex = 5;
            label3.Text = "URL";
            // 
            // txtUrl
            // 
            txtUrl.Location = new Point(116, 112);
            txtUrl.Name = "txtUrl";
            txtUrl.Size = new Size(255, 31);
            txtUrl.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 67);
            label2.Name = "label2";
            label2.Size = new Size(87, 25);
            label2.TabIndex = 3;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(41, 27);
            label1.Name = "label1";
            label1.Size = new Size(56, 25);
            label1.TabIndex = 2;
            label1.Text = "Login";
            // 
            // txtPwd
            // 
            txtPwd.Location = new Point(116, 64);
            txtPwd.Name = "txtPwd";
            txtPwd.PasswordChar = '#';
            txtPwd.Size = new Size(255, 31);
            txtPwd.TabIndex = 1;
            // 
            // txtLogin
            // 
            txtLogin.Location = new Point(116, 21);
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(257, 31);
            txtLogin.TabIndex = 0;
            // 
            // butLogin
            // 
            butLogin.Location = new Point(96, 216);
            butLogin.Name = "butLogin";
            butLogin.Size = new Size(112, 34);
            butLogin.TabIndex = 1;
            butLogin.Text = "Connect";
            butLogin.UseVisualStyleBackColor = true;
            butLogin.Click += butLogin_Click;
            // 
            // button2
            // 
            button2.Location = new Point(246, 216);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 2;
            button2.Text = "Cancel";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Enterprise_Applications;
            pictureBox1.Location = new Point(404, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(192, 194);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // FrmLogin
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(604, 262);
            Controls.Add(pictureBox1);
            Controls.Add(button2);
            Controls.Add(butLogin);
            Controls.Add(groupBox1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private Label label1;
        private TextBox txtPwd;
        private TextBox txtLogin;
        private Button butLogin;
        private Button button2;
        private PictureBox pictureBox1;
        private Label label3;
        private TextBox txtUrl;
    }
}
