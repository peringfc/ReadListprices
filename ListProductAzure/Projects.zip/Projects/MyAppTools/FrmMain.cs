﻿using MyAppTools.Collection.Metrics.Business;
using MyAppTools.Setup;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyAppTools
{
    public partial class FrmMain : Form
    {
        public FrmMain(string p_login, 
                       string p_host_url,
                       string p_pwd)
        {
            InitializeComponent();
            tool_url.Text = p_host_url;
            tool_login.Text = p_login;
            msg($"Connect Sucess !!! {p_login} - {DateTime.Now.ToString()}");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmListBusinessMetrics oFrmListBusinessMetrics = new FrmListBusinessMetrics();
            oFrmListBusinessMetrics.ShowDialog();
        }

        private void butSetup_Click(object sender, EventArgs e)
        {
            FrmSetup oFrmSetup = new FrmSetup();
            oFrmSetup.ShowDialog();
        }


        private void msg(string p_msg) 
        {
            tool_Msg.Text = p_msg;
        }
    }
}
