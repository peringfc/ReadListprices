﻿using MyOfficeEmail.Invite;
using System;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace MyOfficeEmail.Invite
{
    public class OutlookInvitation
    {
        public string Subject { get; set; }
        public string HtmlBody { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public string TimeZone { get; set; }

        public OutlookInvitation(string subject, string htmlBody, DateTime startDateTime, DateTime endDateTime, string timeZone)
        {
            Subject = subject;
            HtmlBody = htmlBody;
            StartDateTime = startDateTime;
            EndDateTime = endDateTime;
            TimeZone = timeZone;
        }

        public void SendInvitations(string emailList)
        {
            var emailAddresses = emailList.Split(';');
            foreach (var email in emailAddresses)
            {
                SendEmail(email.Trim());
            }
        }

        private void SendEmail(string recipientEmail)
        {
            try
            {
                using (var smtpClient = new SmtpClient("smtp.your-email-provider.com"))
                {
                    smtpClient.Port = 587; // Ajuste a porta se necessário
                    smtpClient.Credentials = new NetworkCredential("your-email@example.com", "your-email-password");
                    smtpClient.EnableSsl = true;

                    var mailMessage = new MailMessage
                    {
                        From = new MailAddress("your-email@example.com"),
                        Subject = Subject,
                        Body = GenerateHtmlBody(),
                        IsBodyHtml = true,
                    };
                    mailMessage.To.Add(recipientEmail);

                    // Adiciona o convite no formato ICS como anexo
                    var icsFileName = $"{Subject}.ics";
                    var icsContent = GenerateIcsContent();
                    mailMessage.Attachments.Add(new Attachment(new System.IO.MemoryStream(Encoding.UTF8.GetBytes(icsContent)), icsFileName, "text/calendar"));

                    smtpClient.Send(mailMessage);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao enviar o email para {recipientEmail}: {ex.Message}");
            }
        }

        private string GenerateHtmlBody()
        {
            var sb = new StringBuilder();
            sb.AppendLine(HtmlBody);
            sb.AppendLine($"<p>Data e Hora de Início: {StartDateTime} ({TimeZone})</p>");
            sb.AppendLine($"<p>Data e Hora de Término: {EndDateTime} ({TimeZone})</p>");
            return sb.ToString();
        }

        private string GenerateIcsContent()
        {
            var sb = new StringBuilder();
            sb.AppendLine("BEGIN:VCALENDAR");
            sb.AppendLine("VERSION:2.0");
            sb.AppendLine("PRODID:-//Your Organization//Your Product//EN");
            sb.AppendLine("CALSCALE:GREGORIAN");
            sb.AppendLine("METHOD:PUBLISH");
            sb.AppendLine("BEGIN:VEVENT");
            sb.AppendLine($"UID:{Guid.NewGuid()}");
            sb.AppendLine($"SUMMARY:{Subject}");
            sb.AppendLine($"DTSTART:{StartDateTime:yyyyMMddTHHmmssZ}");
            sb.AppendLine($"DTEND:{EndDateTime:yyyyMMddTHHmmssZ}");
            sb.AppendLine($"DESCRIPTION:{HtmlBody.Replace("\n", "\\n")}");
            sb.AppendLine("END:VEVENT");
            sb.AppendLine("END:VCALENDAR");
            return sb.ToString();
        }
    }
}


//Exemplo
//class Program
//{
//    static void Main()
//    {
//        string emailList = "recipient1@example.com; recipient2@example.com";
//        string subject = "Convite para o Evento";
//        string htmlBody = "<h1>Você está convidado para o evento!</h1><p>Por favor, confirme sua presença.</p>";
//        DateTime startDateTime = new DateTime(2024, 8, 15, 14, 0, 0, DateTimeKind.Utc); // Exemplo de data e hora de início
//        DateTime endDateTime = new DateTime(2024, 8, 15, 16, 0, 0, DateTimeKind.Utc); // Exemplo de data e hora de término
//        string timeZone = "UTC-3"; // Exemplo de fuso horário

//        var invitation = new OutlookInvitation(subject, htmlBody, startDateTime, endDateTime, timeZone);
//        invitation.SendInvitations(emailList);
//    }
//}