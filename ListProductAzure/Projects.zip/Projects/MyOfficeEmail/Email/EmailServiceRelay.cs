﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace MyOfficeEmail.Email
{
    public class EmailServiceRelay(string smtpServer, int smtpPort)
    {
        private readonly string _smtpServer = smtpServer;
        private readonly int _smtpPort = smtpPort;

        public void SendEmail(string htmlContent, string emailAddresses, string subject)
        {
            var mailMessage = new MailMessage();
            mailMessage.From = new MailAddress("no-reply@example.com"); // Ajuste o endereço "from" conforme necessário

            foreach (var email in emailAddresses.Split(';').Where(e => !string.IsNullOrWhiteSpace(e)))
            {
                mailMessage.To.Add(email.Trim());
            }

            mailMessage.Subject = subject;
            mailMessage.Body = htmlContent;
            mailMessage.IsBodyHtml = true;

            using (var smtpClient = new SmtpClient(_smtpServer, _smtpPort))
            {
                smtpClient.EnableSsl = false; // Desativar SSL, pois não há autenticação
                smtpClient.UseDefaultCredentials = true; // Usar credenciais padrão (sem autenticação)
                smtpClient.Send(mailMessage);
            }
        }
    }
}
