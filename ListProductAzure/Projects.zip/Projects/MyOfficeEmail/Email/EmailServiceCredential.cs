﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MyOfficeEmail.Email
{
    public class EmailServiceCredential(string smtpServer, int smtpPort, string smtpUsername, string smtpPassword)
    {
        private readonly string _smtpServer = smtpServer;
        private readonly int _smtpPort = smtpPort;
        private readonly string _smtpUsername = smtpUsername;
        private readonly string _smtpPassword = smtpPassword;

        public void SendEmail(string htmlContent, string emails, string subject)
        {
            var mailMessage = new MailMessage();
            mailMessage.From = new MailAddress(_smtpUsername);
            foreach (var email in emails.Split(';'))
            {
                mailMessage.To.Add(email);
            }

            mailMessage.Subject = subject;
            mailMessage.Body = htmlContent;
            mailMessage.IsBodyHtml = true;

            using (var smtpClient = new SmtpClient(_smtpServer, _smtpPort))
            {
                smtpClient.Credentials = new NetworkCredential(_smtpUsername, _smtpPassword);
                smtpClient.EnableSsl = true;
                smtpClient.Send(mailMessage);
            }
        }
    }
}
