﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibMyNFT_Tools.Table
{
    public class ConfigManager
    {
        public DataTable LoadManagerInjector()
        {
            DataTable tb = new DataTable();
            try
            {
                String oFile = @"ManageInjector.xml";
                if (File.Exists(oFile))
                {
                    tb.ReadXml(oFile);
                }
                else
                {
                    tb = StruManagerInjector();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return tb;
        }

        public void SalveManagerInjector(DataTable tb)
        {
            try
            {
                String oFile = @"ManageInjector.xml";
                tb.WriteXml(oFile, XmlWriteMode.WriteSchema);
            }
            catch (Exception)
            {
                throw;
            }
        }


        public DataTable StruManagerInjector()
        {
            DataTable tb = new DataTable("Injectors");
            try
            {
                tb.Columns.Add("State", typeof(bool));
                tb.Columns.Add("Status", typeof(string));
                tb.Columns.Add("Injector", typeof(string));
                tb.Columns.Add("NameMachine", typeof(string));
                tb.Columns.Add("IPaddress", typeof(string));
                tb.Columns.Add("Port", typeof(int));
                tb.Columns.Add("Treads_Max", typeof(int));
                tb.Columns.Add("Position", typeof(string));
                tb.Columns.Add("DtCreate", typeof(DateTime));
                tb.Columns.Add("OS", typeof(string));
                tb.Columns.Add("Memory", typeof(string));
                tb.Columns.Add("CPU", typeof(string));
                tb.Columns.Add("Sockets", typeof(string));
                tb.Columns.Add("Nucleos", typeof(string));
                tb.Columns.Add("NDisk", typeof(string));
                tb.Columns.Add("DiskWork", typeof(string));
                tb.Columns.Add("SpaceTotalDisk", typeof(string));
                tb.Columns.Add("SpaceDiskFree", typeof(string));
                tb.Columns.Add("ID_Injector", typeof(string));
                tb.Columns.Add("SendReturn", typeof(string));
            }
            catch (Exception)
            {
                throw;
            }
            return tb;
        }
    }

}
