﻿using LibMyNFT_Tools.Structure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Data;
using System.Reflection.PortableExecutable;
using LibMyNFT_Tools.Table;

namespace LibMyNFT_Tools.Procedure
{
    public class ProcessInjector
    {
        public void AddInjector(Stru_Injector Injector)
        {
            try
            {
                DataTable oDataInjetor = new DataTable();
                ConfigManager oInjector = new ConfigManager();
                oDataInjetor = oInjector.LoadManagerInjector();
                DataRow dr;
                dr = oDataInjetor.NewRow();
                dr["Injector"] = Injector.Injector;
                dr["NameMachine"] = Injector.NameMachine;
                dr["IPaddress"] = Injector.IPaddress;
                dr["Position"] = Injector.Position;
                dr["DtCreate"] = DateTime.Now;
                dr["Port"] = Injector.Port;
                dr["Treads_Max"] = Injector.Treads;
                dr["Status"] = "Not Validated";
                dr["State"] = false;
                dr["ID_Injector"] = Guid.NewGuid().ToString();
                oDataInjetor.Rows.Add(dr);
                oInjector.SalveManagerInjector(oDataInjetor);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void RemoveInjector(Stru_Injector Injector)
        {
            try
            {
                DataTable oDataInjetor = new DataTable();
                ConfigManager oInjector = new ConfigManager();
                oDataInjetor = oInjector.LoadManagerInjector();
                foreach (DataRow row in oDataInjetor.Rows)
                {
                    if (Injector.IPaddress == row["IPaddress"].ToString())
                    {
                        if (Injector.Port.ToString() == row["Port"].ToString())
                        {
                            oDataInjetor.Rows.Remove(row);
                        }
                    }
                }
                oInjector.SalveManagerInjector(oDataInjetor);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public DataTable ValidInjector()
        {
            try
            {
                DataTable oDataInjetor = new DataTable();
                ConfigManager oInjector = new ConfigManager();
                oDataInjetor = oInjector.LoadManagerInjector();

                Communications.Message oCommunication = new Communications.Message();

                int i = 0;
                foreach (DataRow RowInjector in oDataInjetor.Rows)
                {
                    try
                    {
                        if (oCommunication.TestConnet(
                            RowInjector["IPaddress"].ToString(),
                            int.Parse(RowInjector["Port"].ToString()))
                           )
                        {
                            oDataInjetor.Rows[i]["Status"] = "Valid. OK - " + DateTime.Now.ToString();
                            oDataInjetor.Rows[i]["State"] = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        oDataInjetor.Rows[i]["Status"] = "INVALID - " + DateTime.Now.ToString();
                        oDataInjetor.Rows[i]["State"] = false;
                        oDataInjetor.Rows[i]["SendReturn"] = ex.Message.ToString();
                    }
                    i++;
                }
                return oDataInjetor;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
