﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace LibMyNFT_Tools.Convert
{
    public class ObjectConvert
    {
        public string ObjectStrinJson(object obj)
        {
            return JsonSerializer.Serialize(obj);
        }
    }
}
