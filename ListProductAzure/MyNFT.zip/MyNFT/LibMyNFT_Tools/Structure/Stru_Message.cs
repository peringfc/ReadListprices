﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibMyNFT_Tools.Structure
{
    public class Stru_Message
    {
        public string? Id_Message_Send { get; set; }
        public string? Id_Message_Return { get; set; }
        public string? Operation { get; set; }
        public string? Operation_Message { get; set; }
        public string? IPaddress_Send { get; set; }
        public DateTime DtCreate { get; set; }
        public string? Id_Procedure { get; set; }
        public string? Id_PlanTest { get; set; }
    }
}
