﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibMyNFT_Tools.Structure
{
    public class Stru_Injector
    {
        // Stru_Injector myDeserializedClass = JsonConvert.DeserializeObject<Stru_Injector>(myJsonResponse);
        public string? ID_Injector { get; set; }
        public string? Injector { get; set; }
        public string? NameMachine { get; set; }
        public string? IPaddress { get; set; }
        public DateTime DtCreate { get; set; }
        public int Port { get; set; }
        public int Treads { get; set; }
        public string? Position { get; set; }
        public string? Status { get; set; }
        public bool State { get; set; }
    }

}
