﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibMyNFT_Tools.Structure
{
    public class StruFiles
    {
        public string? Id_File { get; set; }
        public string? File_Path { get; set; }
        public string? Type_File { get; set; }
        public DateTime? DtCreate { get; set; }
    }
}
