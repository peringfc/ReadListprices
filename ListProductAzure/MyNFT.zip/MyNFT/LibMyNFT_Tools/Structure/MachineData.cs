﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibMyNFT_Tools.Structure
{
    public class MachineData
    {
        public string? NameMachine { get; set; }
        public List<string>? IPMachine { get; set; }
        public DateTime DateValid { get; set; }
        public string? gcMemoryInfo { get; set; }
        public string? installedMemory { get; set; }
        public string? physicalMemory { get; set; }
        public string? startTime { get; set; }
        public string? startCpuUsage { get; set; }
        public string? endTime { get; set; }
        public string? endCpuUsage { get; set; }
        public string? cpuUsedMs { get; set; }
        public string? totalMsPassed { get; set; }
        public string? cpuUsageTotal { get; set; }
        public List<Drives>? Drive { get; set; }
    }
    public class Drives
    {
        public int id { get; set; }
        public string? Name { get; set; }
        public string? DriveType { get; set; }
        public string? VolumeLabel { get; set; }
        public string? DriveFormat { get; set; }
        public string? AvailableFreeSpace { get; set; }
        public string? TotalFreeSpace { get; set; }
        public string? TotalSize { get; set; }
        public Boolean? Ready { get; set; }

    }
}
