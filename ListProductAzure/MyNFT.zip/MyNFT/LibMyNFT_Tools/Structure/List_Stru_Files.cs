﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibMyNFT_Tools.Structure
{
    public class List_Stru_Files
    {
        public List<StruFiles>? ListFiles { get; set; }
    }
}
