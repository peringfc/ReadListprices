﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibMyNFT_Tools.Structure
{
    public class Stru_PlanTest
    {
        public string? Id_PlanTest { get; set; }
        public string? Status { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public int QtdeRequest { get; set; }
        public int QtdeUsers { get; set; }
        public string? TimeReponse { get; set; }
        public DateTime DtCreate { get; set; }
        public DateTime DtSchedule { get; set; }
        public string? UserCreate { get; set; }
    }
}
