namespace WinMyNFT
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void butLogin_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.ShowDialog(this);
        }


    }
}
