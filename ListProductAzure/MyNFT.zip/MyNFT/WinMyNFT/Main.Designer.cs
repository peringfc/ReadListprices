﻿namespace WinMyNFT
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            butConfig = new Button();
            butTestExecut = new Button();
            butDash = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(butDash);
            groupBox1.Controls.Add(butTestExecut);
            groupBox1.Controls.Add(butConfig);
            groupBox1.Location = new Point(3, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(751, 62);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Injetoras";
            // 
            // butConfig
            // 
            butConfig.Location = new Point(17, 24);
            butConfig.Name = "butConfig";
            butConfig.Size = new Size(198, 23);
            butConfig.TabIndex = 0;
            butConfig.Text = "Configuração";
            butConfig.UseVisualStyleBackColor = true;
            // 
            // butTestExecut
            // 
            butTestExecut.Location = new Point(221, 24);
            butTestExecut.Name = "butTestExecut";
            butTestExecut.Size = new Size(198, 23);
            butTestExecut.TabIndex = 1;
            butTestExecut.Text = "Testes em Execução";
            butTestExecut.UseVisualStyleBackColor = true;
            // 
            // butDash
            // 
            butDash.Location = new Point(425, 24);
            butDash.Name = "butDash";
            butDash.Size = new Size(198, 23);
            butDash.TabIndex = 2;
            butDash.Text = "DashBoard";
            butDash.UseVisualStyleBackColor = true;
            butDash.Click += butDash_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(762, 450);
            Controls.Add(groupBox1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Main";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Menu de Injetoras";
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button butTestExecut;
        private Button butConfig;
        private Button butDash;
    }
}