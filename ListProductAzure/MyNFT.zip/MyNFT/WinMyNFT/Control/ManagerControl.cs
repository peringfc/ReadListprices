﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinMyNFT.Control
{
    public partial class ManagerControl : Form
    {
        public ManagerControl()
        {
            InitializeComponent();
        }
    }
}
