﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinMyNFT.Injector
{
    public partial class DashBordInjector : Form
    {
        public DashBordInjector()
        {
            InitializeComponent();


            
        }

        private void injectoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadInjetoras();
        }


        /// <summary>
        ///  Processo de carregar as injetoras para teste
        /// </summary>
        private void LoadInjetoras()
        {

            int Ii = 0;
            for (int i = 0; i < 30; i++)
            {
                DashBoardInjectores oDashBoardInjectores = new DashBoardInjectores();
                oDashBoardInjectores.MdiParent = this;
                oDashBoardInjectores.Text = "Injector:" + i.ToString() + " " + DateTime.Now.ToString();
                oDashBoardInjectores.Show();
                Ii++;
                toolLoadInjetoras.ProgressBar.Value = i;
            }
            OrderHorizontal();
            DashExecucao oDashExecucao = new DashExecucao(Ii);
            oDashExecucao.Show();
            toolLoadInjetoras.ProgressBar.Value = 0;

        }

        private void CloseInjetoras()
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void validarInjetorasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CloseInjetoras();
        }

        private void OrderHorizontal()
        {
            this.LayoutMdi(System.Windows.Forms.MdiLayout.TileHorizontal);
        }

        private void OrderVertical()
        {
            this.LayoutMdi(System.Windows.Forms.MdiLayout.TileVertical);
        }

        private void OrderCascate()
        {
            this.LayoutMdi(System.Windows.Forms.MdiLayout.Cascade);
        }

        private void verticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderVertical();
        }

        private void horizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderHorizontal();
        }

        private void cascataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderCascate();
        }
    }

}
