﻿namespace WinMyNFT.Injector
{
    partial class DashExecucao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            lblStatus = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            dataGridView1 = new DataGridView();
            lblErros = new Label();
            lblRequest = new Label();
            lblInjetoras = new Label();
            lblEncerradas = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(12, 12);
            button2.Name = "button2";
            button2.Size = new Size(38, 23);
            button2.TabIndex = 12;
            button2.Text = "stop";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(56, 12);
            button1.Name = "button1";
            button1.Size = new Size(38, 23);
            button1.TabIndex = 11;
            button1.Text = "start";
            button1.UseVisualStyleBackColor = true;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI", 15F);
            lblStatus.Location = new Point(112, 7);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(65, 28);
            lblStatus.TabIndex = 13;
            lblStatus.Text = "Status";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label1.Location = new Point(12, 54);
            label1.Name = "label1";
            label1.Size = new Size(56, 15);
            label1.TabIndex = 14;
            label1.Text = "Injetoras";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(12, 78);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 15;
            label2.Text = "Requests";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(12, 106);
            label3.Name = "label3";
            label3.Size = new Size(35, 15);
            label3.TabIndex = 16;
            label3.Text = "Erros";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 135);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(374, 150);
            dataGridView1.TabIndex = 17;
            // 
            // lblErros
            // 
            lblErros.AutoSize = true;
            lblErros.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblErros.ForeColor = Color.Red;
            lblErros.Location = new Point(94, 106);
            lblErros.Name = "lblErros";
            lblErros.Size = new Size(35, 15);
            lblErros.TabIndex = 20;
            lblErros.Text = "Erros";
            // 
            // lblRequest
            // 
            lblRequest.AutoSize = true;
            lblRequest.Location = new Point(94, 78);
            lblRequest.Name = "lblRequest";
            lblRequest.Size = new Size(54, 15);
            lblRequest.TabIndex = 19;
            lblRequest.Text = "Requests";
            // 
            // lblInjetoras
            // 
            lblInjetoras.AutoSize = true;
            lblInjetoras.Location = new Point(94, 54);
            lblInjetoras.Name = "lblInjetoras";
            lblInjetoras.Size = new Size(52, 15);
            lblInjetoras.TabIndex = 18;
            lblInjetoras.Text = "Injetoras";
            // 
            // lblEncerradas
            // 
            lblEncerradas.AutoSize = true;
            lblEncerradas.Location = new Point(175, 54);
            lblEncerradas.Name = "lblEncerradas";
            lblEncerradas.Size = new Size(52, 15);
            lblEncerradas.TabIndex = 21;
            lblEncerradas.Text = "Injetoras";
            // 
            // DashExecucao
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(398, 295);
            Controls.Add(lblEncerradas);
            Controls.Add(lblErros);
            Controls.Add(lblRequest);
            Controls.Add(lblInjetoras);
            Controls.Add(dataGridView1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblStatus);
            Controls.Add(button2);
            Controls.Add(button1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "DashExecucao";
            Text = "Teste ";
            Load += DashExecucao_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private Label lblStatus;
        private Label label1;
        private Label label2;
        private Label label3;
        private DataGridView dataGridView1;
        private Label lblErros;
        private Label lblRequest;
        private Label lblInjetoras;
        private Label lblEncerradas;
    }
}