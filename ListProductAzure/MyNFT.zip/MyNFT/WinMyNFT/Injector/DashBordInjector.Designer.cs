﻿namespace WinMyNFT.Injector
{
    partial class DashBordInjector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuInject = new MenuStrip();
            injectoresToolStripMenuItem = new ToolStripMenuItem();
            ordernarToolStripMenuItem = new ToolStripMenuItem();
            verticalToolStripMenuItem = new ToolStripMenuItem();
            horizontalToolStripMenuItem = new ToolStripMenuItem();
            cascataToolStripMenuItem = new ToolStripMenuItem();
            validarInjetorasToolStripMenuItem = new ToolStripMenuItem();
            liberarExecuçãoDoTesteToolStripMenuItem = new ToolStripMenuItem();
            startToolStripMenuItem = new ToolStripMenuItem();
            stopToolStripMenuItem = new ToolStripMenuItem();
            statusStrip1 = new StatusStrip();
            toolLoadInjetoras = new ToolStripProgressBar();
            menuInject.SuspendLayout();
            statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuInject
            // 
            menuInject.Items.AddRange(new ToolStripItem[] { injectoresToolStripMenuItem, ordernarToolStripMenuItem, validarInjetorasToolStripMenuItem, liberarExecuçãoDoTesteToolStripMenuItem });
            menuInject.Location = new Point(0, 0);
            menuInject.Name = "menuInject";
            menuInject.Size = new Size(800, 24);
            menuInject.TabIndex = 1;
            menuInject.Text = "menuStrip1";
            // 
            // injectoresToolStripMenuItem
            // 
            injectoresToolStripMenuItem.Name = "injectoresToolStripMenuItem";
            injectoresToolStripMenuItem.Size = new Size(70, 20);
            injectoresToolStripMenuItem.Text = "Injectores";
            injectoresToolStripMenuItem.Click += injectoresToolStripMenuItem_Click;
            // 
            // ordernarToolStripMenuItem
            // 
            ordernarToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { verticalToolStripMenuItem, horizontalToolStripMenuItem, cascataToolStripMenuItem });
            ordernarToolStripMenuItem.Name = "ordernarToolStripMenuItem";
            ordernarToolStripMenuItem.Size = new Size(66, 20);
            ordernarToolStripMenuItem.Text = "Ordernar";
            // 
            // verticalToolStripMenuItem
            // 
            verticalToolStripMenuItem.Name = "verticalToolStripMenuItem";
            verticalToolStripMenuItem.Size = new Size(129, 22);
            verticalToolStripMenuItem.Text = "Vertical";
            verticalToolStripMenuItem.Click += verticalToolStripMenuItem_Click;
            // 
            // horizontalToolStripMenuItem
            // 
            horizontalToolStripMenuItem.Name = "horizontalToolStripMenuItem";
            horizontalToolStripMenuItem.Size = new Size(129, 22);
            horizontalToolStripMenuItem.Text = "Horizontal";
            horizontalToolStripMenuItem.Click += horizontalToolStripMenuItem_Click;
            // 
            // cascataToolStripMenuItem
            // 
            cascataToolStripMenuItem.Name = "cascataToolStripMenuItem";
            cascataToolStripMenuItem.Size = new Size(129, 22);
            cascataToolStripMenuItem.Text = "Cascata";
            cascataToolStripMenuItem.Click += cascataToolStripMenuItem_Click;
            // 
            // validarInjetorasToolStripMenuItem
            // 
            validarInjetorasToolStripMenuItem.Name = "validarInjetorasToolStripMenuItem";
            validarInjetorasToolStripMenuItem.Size = new Size(102, 20);
            validarInjetorasToolStripMenuItem.Text = "Validar Injetoras";
            validarInjetorasToolStripMenuItem.Click += validarInjetorasToolStripMenuItem_Click;
            // 
            // liberarExecuçãoDoTesteToolStripMenuItem
            // 
            liberarExecuçãoDoTesteToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { startToolStripMenuItem, stopToolStripMenuItem });
            liberarExecuçãoDoTesteToolStripMenuItem.Name = "liberarExecuçãoDoTesteToolStripMenuItem";
            liberarExecuçãoDoTesteToolStripMenuItem.Size = new Size(154, 20);
            liberarExecuçãoDoTesteToolStripMenuItem.Text = "Liberar execução do Teste";
            // 
            // startToolStripMenuItem
            // 
            startToolStripMenuItem.Name = "startToolStripMenuItem";
            startToolStripMenuItem.Size = new Size(98, 22);
            startToolStripMenuItem.Text = "Start";
            // 
            // stopToolStripMenuItem
            // 
            stopToolStripMenuItem.Name = "stopToolStripMenuItem";
            stopToolStripMenuItem.Size = new Size(98, 22);
            stopToolStripMenuItem.Text = "Stop";
            // 
            // statusStrip1
            // 
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolLoadInjetoras });
            statusStrip1.Location = new Point(0, 428);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(800, 22);
            statusStrip1.TabIndex = 3;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolLoadInjetoras
            // 
            toolLoadInjetoras.Name = "toolLoadInjetoras";
            toolLoadInjetoras.Size = new Size(100, 16);
            // 
            // DashBordInjector
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(statusStrip1);
            Controls.Add(menuInject);
            IsMdiContainer = true;
            MainMenuStrip = menuInject;
            Name = "DashBordInjector";
            Text = "Dashboard - Injectores";
            WindowState = FormWindowState.Maximized;
            menuInject.ResumeLayout(false);
            menuInject.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuInject;
        private ToolStripMenuItem injectoresToolStripMenuItem;
        private ToolStripMenuItem ordernarToolStripMenuItem;
        private ToolStripMenuItem validarInjetorasToolStripMenuItem;
        private ToolStripMenuItem verticalToolStripMenuItem;
        private ToolStripMenuItem horizontalToolStripMenuItem;
        private ToolStripMenuItem cascataToolStripMenuItem;
        private ToolStripMenuItem liberarExecuçãoDoTesteToolStripMenuItem;
        private ToolStripMenuItem startToolStripMenuItem;
        private ToolStripMenuItem stopToolStripMenuItem;
        private StatusStrip statusStrip1;
        private ToolStripProgressBar toolLoadInjetoras;
    }
}