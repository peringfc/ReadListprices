﻿using LibMyNFT_Tools.Structure;
using NetMQ;
using NetMQ.Sockets;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgentMyNFT.Manager
{
    public class Injector
    {
        LibMyNFT_Tools.Structure.Stru_Message oMessage = new LibMyNFT_Tools.Structure.Stru_Message();
        public string QueueName = "???";

        Manager.ScreenMsg oScreenMsg = new ScreenMsg();
        Manager.ScreenMsg screenMsg = new Manager.ScreenMsg();

        LibMyNFT_Tools.Convert.ObjectConvert ObjectConvert = new LibMyNFT_Tools.Convert.ObjectConvert();

        private void runCMD(string arguments)
        {
            Guid g = Guid.NewGuid();
            string Folder_CSV = @"D:\Performance\Results\CSV";
            string Folder_HTML = @"D:\Performance\Results\Report\HTML";
            string Folder_Summary = @"D:\Performance\Results\summary";
            string FileOpen = @"D:\Performance\apache-jmeter-5.5\bin\jmeter.bat";

            string FileArg = $"-n -t {arguments} -l {Folder_CSV}\\{g.ToString()}.csv -e -o {Folder_HTML}\\{g.ToString()} > {Folder_Summary}\\{g.ToString()}.log ";
            //QueueName = FileOpen + FileArg;

            screenMsg.CanvasSecreen(g.ToString(), 3, 18);
            screenMsg.CanvasSecreen("Jmeter", 7, 18);
            screenMsg.CanvasSecreen(FileOpen, 8, 18);
            screenMsg.CanvasSecreen(Folder_CSV, 9, 18);
            screenMsg.CanvasSecreen(Folder_HTML, 10, 18);
            screenMsg.CanvasSecreen(Folder_Summary, 11, 18);
            screenMsg.CanvasSecreen(DateTime.Now.ToString(), 16, 18);

            QueueName = g.ToString();

            Process proc = new();
            proc.StartInfo.FileName = FileOpen;
            proc.StartInfo.Arguments = FileArg;
            proc.Start();
            screenMsg.Message("Process:" + g.ToString() + " OK !");
        }

        public void execute()
        {
            {
                try
                {
                    using (var server = new ResponseSocket())
                    {
                        server.Bind("tcp://*:5556");

                        Boolean Status = true;
                        while (Status)
                        {
                            string msg = server.ReceiveFrameString();

                            Stru_Message Send_Message = JsonConvert.DeserializeObject<Stru_Message>(msg);
                            string oRetorno = "Sem Retorno";
                            try
                            {
                                switch (Send_Message.Operation)
                                {
                                    case "Valid Inject":
                                        oMessage.Id_Message_Return = Guid.NewGuid().ToString();
                                        oMessage.Operation_Message = "Inject Valid - OK";

                                        screenMsg.CanvasSecreen(oMessage.Operation, 7, 18);
                                        screenMsg.CanvasSecreen(oMessage.Operation_Message, 8, 18);
                                        screenMsg.CanvasSecreen(DateTime.Now.ToString(), 16, 18);

                                        break;

                                    case "Run Planned Test":
                                        runCMD(msg);
                                        oRetorno = "Open:" + QueueName;
                                        break;

                                    case "Strem Execute":
                                        break;
                                    case "APP Quit":
                                        Status = false;
                                        break;

                                    case "Infrastructure":
                                        LibMyNFT_Tools.Tools.Hardware hardware = new LibMyNFT_Tools.Tools.Hardware();
                                        MachineData oMachine = new MachineData();
                                        oMachine = hardware.Machine();
                                        string xMachine = System.Text.Json.JsonSerializer.Serialize(oMachine);

                                        oMessage.DtCreate = DateTime.Now;
                                        oMessage.Id_Message_Send = Send_Message.Id_Message_Send;
                                        oMessage.Id_Message_Return = Guid.NewGuid().ToString();
                                        oMessage.IPaddress_Send = Send_Message.IPaddress_Send;
                                        oMessage.Operation = Send_Message.Operation + " - Return";
                                        oMessage.Operation_Message = xMachine;

                                        screenMsg.CanvasSecreen(oMessage.Operation, 7, 18);
                                        screenMsg.CanvasSecreen(oMessage.Operation_Message, 20, 18);
                                        screenMsg.CanvasSecreen(DateTime.Now.ToString(), 8, 18);
                                        break;

                                    case "Copy Robo":
                                        try
                                        {
                                            string path = @"d:\temp\MyTest.jmx";
                                            if (!File.Exists(path))
                                            {
                                                // Create a file to write to.
                                                using (StreamWriter sw = File.CreateText(path))
                                                {
                                                    sw.WriteLine(Send_Message.Operation_Message);
                                                }
                                            }
                                        }
                                        catch (Exception)
                                        {
                                            throw;
                                        }

                                        oMessage.DtCreate = DateTime.Now;
                                        oMessage.Id_Message_Send = Send_Message.Id_Message_Send;
                                        oMessage.Id_Message_Return = Guid.NewGuid().ToString();
                                        oMessage.IPaddress_Send = Send_Message.IPaddress_Send;
                                        oMessage.Operation = Send_Message.Operation + " - Return";
                                        oMessage.Operation_Message = "Salve com success !!!";
                                        screenMsg.CanvasSecreen(oMessage.Operation, 7, 18);
                                        screenMsg.CanvasSecreen(oMessage.Operation_Message, 20, 18);
                                        screenMsg.CanvasSecreen(DateTime.Now.ToString(), 8, 18);
                                        screenMsg.Message(oMessage.Operation_Message);
                                        
                                        break;

                                    case "Copy mass of data":
                                        break;

                                    case "Cancel Execute":
                                        break;

                                    case "Setup Manager Injector":
                                        break;

                                    default:
                                        screenMsg.Message(" Transação não identificada", ConsoleColor.Red);
                                        break;
                                }
                            }
                            catch (Exception ex)
                            {
                                oRetorno = ex.Message.ToString();
                                screenMsg.Message(oRetorno);
                            }
                            server.SendFrame(ObjectConvert.ObjectStrinJson(oMessage));
                        }
                    }
                }
                catch (Exception ex)
                {
                    screenMsg.Message(DateTime.Now.ToString() + " " + ex.Message.ToString());
                }


            }
        }
    }

}
