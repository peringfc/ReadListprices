﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using System.Text.RegularExpressions;
using LibMyNFT_Tools.Structure;
using LibMyNFT_Tools.Tools;

namespace AgentMyNFT.Manager
{
    public class ScreenMsg
    {
        public void CanvasSecreen(string s, int lin, int col, ConsoleColor? color = null)
        {
            try
            {
                Console.SetCursorPosition(col, lin);
                if (color.HasValue)
                {
                    var oldColor = System.Console.ForegroundColor;
                    if (color == oldColor)
                        Console.Write(s);
                    else
                    {
                        Console.ForegroundColor = color.Value;
                        Console.Write(s);
                        Console.ForegroundColor = oldColor;
                    }
                }
                else
                    Console.Write(s);

            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.SetCursorPosition(18, 1);
                Console.Write(e.Message);
            }
        }

        public void MountScreen()
        {
            Console.Clear();
            Console.WriteLine("+===================================================================================================+");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("+===================================================================================================+");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("+---------------------------------------------------------------------------------------------------+");

        }
        public void Message(string Msg, ConsoleColor? color = null)
        {
            CanvasSecreen(Msg, 18, 2, ConsoleColor.Green);
        }
        public void MessageError(string Msg, ConsoleColor? color = null)
        {
            CanvasSecreen(Msg, 18, 2, ConsoleColor.Red);
        }

        public void PrintMachine() 
        {
            Hardware hardware = new Hardware();
            MachineData machineData = new MachineData();
            machineData = hardware.Machine();
            CanvasSecreen("Machine..:" + machineData.NameMachine, 20, 2, ConsoleColor.DarkYellow);
            CanvasSecreen("CPU Use..:" + machineData.cpuUsageTotal, 21, 2, ConsoleColor.DarkYellow);
            CanvasSecreen("Mem Use..:" + machineData.gcMemoryInfo, 22, 2, ConsoleColor.DarkYellow);
            CanvasSecreen("Drives Use...........................................:" , 23, 2, ConsoleColor.DarkYellow);

            CanvasSecreen( machineData.NameMachine,   20, 12, ConsoleColor.Yellow);
            CanvasSecreen( machineData.cpuUsageTotal, 21, 12, ConsoleColor.Yellow);
            CanvasSecreen( machineData.gcMemoryInfo,  22, 12, ConsoleColor.Yellow);
           


            int lin = 24;
            for (int i = 0; i < machineData.Drive.Count; i++)
            {
                CanvasSecreen( machineData.Drive[i].Name.ToString() + " Total:"+
                                machineData.Drive[i].TotalSize.ToString() + " Free:" +
                                machineData.Drive[i].TotalFreeSpace.ToString() + " " +
                                machineData.Drive[i].VolumeLabel.ToString() + " ", 
                                lin++, 2, ConsoleColor.Yellow);
            }
            lin = 20;
            for (int i = 0; i < machineData.IPMachine.Count; i++)
            {
                CanvasSecreen($"->", lin, 60, ConsoleColor.DarkYellow);
                CanvasSecreen(machineData.IPMachine[i].ToString(), lin++, 63, ConsoleColor.Yellow);
            }

        }
    }
}
