﻿using LibMyNFT_Tools.Structure;
using LibMyNFT_Tools.Tools;

namespace AgentMyNFT
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Manager.Injector oInjector = new Manager.Injector();
            Manager.ScreenMsg screenMsg = new Manager.ScreenMsg();

            screenMsg.MountScreen();
            screenMsg.CanvasSecreen("Injector Management.", 1, 2, ConsoleColor.Red);
            screenMsg.CanvasSecreen("Agent. - Version:1.0 -", 1, 70,ConsoleColor.Magenta);
            screenMsg.CanvasSecreen("Project........:",  3, 2, ConsoleColor.Yellow);
            screenMsg.CanvasSecreen("Requesting user:",  4, 2, ConsoleColor.Yellow);
            screenMsg.CanvasSecreen("Workstation....:",  5, 2, ConsoleColor.Yellow);
            screenMsg.CanvasSecreen("Task...........:",  7, 2, ConsoleColor.Yellow);
            screenMsg.CanvasSecreen("Command........:",  8, 2, ConsoleColor.Yellow);
            screenMsg.CanvasSecreen("Start..........:", 16, 2, ConsoleColor.DarkYellow);
            screenMsg.Message("Active.");

            screenMsg.PrintMachine();

            oInjector.execute();
        }
    }
}
