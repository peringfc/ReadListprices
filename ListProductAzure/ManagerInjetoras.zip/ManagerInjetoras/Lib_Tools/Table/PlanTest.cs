﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Lib_Tools.Table
{
    /// <summary>
    /// Estrutura de plano de teste
    /// </summary>
    public class PlanTest
    {
        /// <summary>
        /// Carrega Lista de plano de teste realizando o preparados para execução.
        /// </summary>
        /// <returns></returns>
        public DataSet LoadListPlanTest()
        {
            DataSet dts = new DataSet();
            try
            {
                String oFile = @"ManagePlanTest.xml";
                if (File.Exists(oFile))
                {
                    dts.ReadXml(oFile);
                }
                else
                {
                    dts = stru_test_plan_list();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return dts;
        }

        /// <summary>
        /// Salva o Plano de teste 
        /// </summary>
        /// <param name="dts">Dataset com o plano de teste que sera realizado</param>
        public void SalveManagerPlanTest(DataSet dts)
        {
            try
            {
                String oFile = @"ManagePlanTest.xml";
                dts.WriteXml(oFile, XmlWriteMode.WriteSchema);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Salvar plano de teste
        /// </summary>
        /// <param name="dts"></param>
        /// <param name="plantest"></param>
        public void SalvePlanTest(DataSet dts, string plantest)
        {
            try
            {
                String oFile = $"PlanTest_{plantest}.xml";
                dts.WriteXml(oFile, XmlWriteMode.WriteSchema);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Carrega Plano de teste 
        /// </summary>
        /// <param name="plantest">ID do plano de teste a ser carregado</param>
        /// <returns></returns>
        public DataSet LoadPlanTest(string plantest)
        {
            DataSet dts = new DataSet();
            try
            {
                String oFile = $"PlanTest_{plantest}.xml";
                if (File.Exists(oFile))
                {
                    dts.ReadXml(oFile);
                }
                else
                {
                    dts = StruPlanTest();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return dts;
        }

        /// <summary>
        ///  Lista de Plano de teste realizando na Aplicação
        /// </summary>
        /// <returns>Retorna a lista de teste realizados e cadastrado na aplicação</returns>
        private DataSet stru_test_plan_list()
        {
            DataSet dts = new DataSet("Test_Plan_List");
            try
            {
                DataTable tb = new DataTable("Plan");
                tb.Columns.Add("Id_PlanTest", typeof(string));
                tb.Columns.Add("Status", typeof(string));
                tb.Columns.Add("Name", typeof(string));
                tb.Columns.Add("Description", typeof(string));
                tb.Columns.Add("QtdeRequest", typeof(int));
                tb.Columns.Add("QtdeUsers", typeof(int));
                tb.Columns.Add("TimeReponse", typeof(string));
                tb.Columns.Add("DtCreate", typeof(DateTime));
                tb.Columns.Add("DtSchedule", typeof(string));
                tb.Columns.Add("DtStart", typeof(string));
                tb.Columns.Add("DtTEnd", typeof(string));
                tb.Columns.Add("UserCreate", typeof(string));
                dts.Tables.Add(tb);
            }
            catch (Exception)
            {
                throw;
            }
            return dts;
        }

        /// <summary>
        /// Estrutura do plando de teste que sera realizado como estrutura de arquivos , e robos e injetores que 
        /// sera executada
        /// </summary>
        /// <returns></returns>
        private DataSet StruPlanTest()
        {
            DataSet dts = new DataSet("PlanTest");
            try
            {
                DataTable tb = new DataTable("Plan");
                tb.Columns.Add("Id_PlanTest", typeof(string));
                tb.Columns.Add("Status", typeof(string));
                tb.Columns.Add("Name", typeof(string));
                tb.Columns.Add("Description", typeof(string));
                tb.Columns.Add("QtdeRequest", typeof(int));
                tb.Columns.Add("QtdeUsers", typeof(int));
                tb.Columns.Add("TimeReponse", typeof(string));
                tb.Columns.Add("DtCreate", typeof(DateTime));
                tb.Columns.Add("DtSchedule", typeof(string));
                tb.Columns.Add("DtStart", typeof(string));
                tb.Columns.Add("DtTEnd", typeof(string));
                tb.Columns.Add("UserCreate", typeof(string));
                dts.Tables.Add(tb);

                DataTable tbfiles = new DataTable("PlanFile");
                tbfiles.Columns.Add("Id_File", typeof(string));
                tbfiles.Columns.Add("Id_PlanTest", typeof(string));
                tbfiles.Columns.Add("Status", typeof(string));
                tbfiles.Columns.Add("Name", typeof(string));
                tbfiles.Columns.Add("Path", typeof(string));
                tbfiles.Columns.Add("Size", typeof(string));
                tbfiles.Columns.Add("Type", typeof(string));
                tbfiles.Columns.Add("DtCreate", typeof(DateTime));
                tbfiles.Columns.Add("UserCreate", typeof(string));
                dts.Tables.Add(tbfiles);

                DataTable tbfilesInjector = new DataTable("PlanInjetor");
<<<<<<< HEAD

                tbfilesInjector.Columns.Add("Injector", typeof(string));
                tbfilesInjector.Columns.Add("NameMachine", typeof(string));
                tbfilesInjector.Columns.Add("IPaddress", typeof(string));
                tbfilesInjector.Columns.Add("Port", typeof(string));
                tbfilesInjector.Columns.Add("Treads", typeof(string));
                tbfilesInjector.Columns.Add("Position", typeof(string));
=======
                tbfilesInjector.Columns.Add("Id_File", typeof(string));
                tbfilesInjector.Columns.Add("Id_PlanTest", typeof(string));
                tbfilesInjector.Columns.Add("ID_Injector", typeof(string));
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219
                tbfilesInjector.Columns.Add("Status", typeof(string));
                tbfilesInjector.Columns.Add("Path", typeof(string));
                tbfilesInjector.Columns.Add("Size", typeof(string));
                tbfilesInjector.Columns.Add("Type", typeof(int));
                tbfilesInjector.Columns.Add("DtCreate", typeof(DateTime));
                tbfilesInjector.Columns.Add("UserCreate", typeof(string));
<<<<<<< HEAD
                tbfilesInjector.Columns.Add("Id_File", typeof(string));
                tbfilesInjector.Columns.Add("Id_PlanTest", typeof(string));
                tbfilesInjector.Columns.Add("ID_Injector", typeof(string));
=======
                dts.Tables.Add(tbfilesInjector);

>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219

                DataTable tbInjector = new DataTable("ExecuteInjetor");
                tbInjector.Columns.Add("Id_File", typeof(string));
                tbInjector.Columns.Add("Id_PlanTest", typeof(string));
                tbInjector.Columns.Add("ID_Injector", typeof(string));
                tbInjector.Columns.Add("Status", typeof(string));
                tbInjector.Columns.Add("Path", typeof(string));
                tbInjector.Columns.Add("Size", typeof(string));
                tbInjector.Columns.Add("Type", typeof(int));
                tbInjector.Columns.Add("DtCreate", typeof(DateTime));
                tbInjector.Columns.Add("UserCreate", typeof(string));
                tbInjector.Columns.Add("QtdeRequest", typeof(int));
                tbInjector.Columns.Add("QtdeUsers", typeof(int));
                tbInjector.Columns.Add("TimeReponse", typeof(string));

                tbInjector.Columns.Add("summary_Starting", typeof(string));
                tbInjector.Columns.Add("summary_end", typeof(string));
                tbInjector.Columns.Add("Rampup", typeof(int));

                tbInjector.Columns.Add("Summarysub_qtde", typeof(int));
                tbInjector.Columns.Add("Summarysub_time", typeof(string));
                tbInjector.Columns.Add("Summarysub_timerequest", typeof(string));
                tbInjector.Columns.Add("Summarysub_avg", typeof(int));
                tbInjector.Columns.Add("Summarysub_min", typeof(int));
                tbInjector.Columns.Add("Summarysub_max", typeof(int));
                tbInjector.Columns.Add("Summarysub_err", typeof(int));
                tbInjector.Columns.Add("Summarysub_err_per", typeof(float));
                tbInjector.Columns.Add("Summarysub_user_active", typeof(int));
                tbInjector.Columns.Add("Summarysub_user_started", typeof(int));
                tbInjector.Columns.Add("Summarysub_user_finished", typeof(int));

                tbInjector.Columns.Add("Summary_qtde", typeof(int));
                tbInjector.Columns.Add("Summary_time", typeof(string));
                tbInjector.Columns.Add("Summary_timerequest", typeof(string));
                tbInjector.Columns.Add("Summary_avg", typeof(int));
                tbInjector.Columns.Add("Summary_min", typeof(int));
                tbInjector.Columns.Add("Summary_max", typeof(int));
                tbInjector.Columns.Add("Summary_err", typeof(int));
                tbInjector.Columns.Add("Summary_err_per", typeof(float));

                dts.Tables.Add(tbInjector);


            }
            catch (Exception)
            {
                throw;
            }
            return dts;
        }
    }
}
