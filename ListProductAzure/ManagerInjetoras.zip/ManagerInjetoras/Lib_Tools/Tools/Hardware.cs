﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using Lib_Tools.Structure;
using System.Net;

namespace Lib_Tools.Tools
{
    public class Hardware
    {
        public MachineData Machine()
        {
            try
            {
                MachineData oMachine = new MachineData();
                
                DriveInfo[] allDrives = DriveInfo.GetDrives();

                List<string> ListIp = new List<string>();

                List<Drives> ListDrives = new List<Drives>();

                string server = Dns.GetHostName();
                IPHostEntry heserver = Dns.GetHostEntry(server);

                int i = 0 ;
                foreach (DriveInfo d in allDrives)
                {
                    Drives oDrive = new Drives();
                    oDrive.id = i;
                    i++;

                    oDrive.Name = d.Name.ToString();
                    oDrive.DriveType = d.DriveType.ToString();
                    if (d.IsReady == true)
                    {
                        oDrive.VolumeLabel = d.VolumeLabel;
                        oDrive.DriveFormat = d.DriveFormat;
                        oDrive.AvailableFreeSpace = String.Format("{0:0,0.0}", d.AvailableFreeSpace / 1048576.0); 
                        oDrive.TotalFreeSpace = String.Format("{0:0,0.0}", d.TotalFreeSpace / 1048576.0);
                        oDrive.TotalSize = String.Format("{0:0,0.0}", d.TotalSize / 1048576.0);  
                        oDrive.Ready = true;
                    }
                    else
                    {
                        oDrive.Ready = false;
                    }

                    ListDrives.Add(oDrive);
                }

                var gcMemoryInfo = GC.GetGCMemoryInfo();
                var installedMemory = (double)gcMemoryInfo.TotalAvailableMemoryBytes / 1048576.0;
                var physicalMemory = (double)installedMemory / 1048576.0;
                var startTime = DateTime.UtcNow;
                var startCpuUsage = Process.GetCurrentProcess().TotalProcessorTime;
                var endTime = DateTime.UtcNow;
                var endCpuUsage = Process.GetCurrentProcess().TotalProcessorTime;
                var cpuUsedMs = (endCpuUsage - startCpuUsage).TotalMilliseconds;
                var totalMsPassed = (endTime - startTime).TotalMilliseconds;
                var cpuUsageTotal = cpuUsedMs / (Environment.ProcessorCount * totalMsPassed);

                oMachine.NameMachine = server;

                foreach (var item in heserver.AddressList)
                {
                    ListIp.Add(item.ToString());
                }

                oMachine.IPMachine = ListIp;

                oMachine.DateValid = DateTime.Now;
                oMachine.gcMemoryInfo = gcMemoryInfo.HighMemoryLoadThresholdBytes.ToString();
                oMachine.installedMemory = String.Format("{0:0,0.0}", installedMemory);  
                oMachine.physicalMemory = String.Format("{0:0,0.0}", physicalMemory);
                oMachine.startTime = startTime.ToString();
                oMachine.startCpuUsage = startCpuUsage.TotalMicroseconds.ToString();
                oMachine.endTime = endTime.ToString();
                oMachine.endCpuUsage = endCpuUsage.ToString();
                oMachine.cpuUsedMs = cpuUsedMs.ToString();
                oMachine.totalMsPassed = String.Format("{0:0,0.0}", (double)totalMsPassed); 
                oMachine.cpuUsageTotal  = String.Format("{0:0,0.0}", (double)cpuUsageTotal); 
                oMachine.Drive = ListDrives;

                return oMachine;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
