﻿using Lib_Tools.Structure;
using NetMQ;
using NetMQ.Sockets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Net;
using System.Threading.Tasks;

namespace Lib_Tools.Communications
{
    public class Message
    {
        public string sendMsg(string server, Stru_Message message)
        {
            using (var client = new RequestSocket())
            {
                client.Connect(server);
                client.SendFrame(JsonSerializer.Serialize(message));
                var msg = client.ReceiveFrameString();
                return msg.ToString();
            }
        }

        public Boolean TestConnet(string IPaddress, int port)
        {
            Boolean oCheck = false;
            TcpClient tc = null;
            try
            {
                tc = new TcpClient(IPaddress, port);
                oCheck = true;
            }
            catch (SocketException)
            {
                throw;
            }
            finally
            {
                if (tc != null)
                {
                    tc.Close();
                }
            }
            return oCheck;
        }
    }
}
