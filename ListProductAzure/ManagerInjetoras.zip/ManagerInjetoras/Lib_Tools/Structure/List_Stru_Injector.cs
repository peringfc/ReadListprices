﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib_Tools.Structure
{
    public class List_Stru_Injector
    {
        public List<Stru_Injector>? ListInjector { get; set; }
    }
 }
