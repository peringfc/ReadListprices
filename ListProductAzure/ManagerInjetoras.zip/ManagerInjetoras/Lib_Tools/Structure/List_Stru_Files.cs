﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib_Tools.Structure
{
    public class List_Stru_Files
    {
        public List<StruFiles>? ListFiles { get; set; }
    }
}
