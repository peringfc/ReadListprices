<<<<<<< HEAD
﻿using Lib_Tools.Convert;
using Lib_Tools.Structure;
using Lib_Tools.Table;
using Newtonsoft.Json;
using System.Data;
using System.Reflection.PortableExecutable;
using Lib_Tools.Tools;

=======
﻿using Lib_Tools.Structure;
using Lib_Tools.Table;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219

namespace Lib_Tools.Procedure
{
    public class ProcessInjector
    {
        public void AddInjector(Stru_Injector Injector)
        {
            try
            {
                DataTable oDataInjetor = new DataTable();
                ConfigManager oInjector = new ConfigManager();
                oDataInjetor = oInjector.LoadManagerInjector();
                DataRow dr;
                dr = oDataInjetor.NewRow();
                dr["Injector"] = Injector.Injector;
                dr["NameMachine"] = Injector.NameMachine;
                dr["IPaddress"] = Injector.IPaddress;
                dr["Position"] = Injector.Position;
                dr["DtCreate"] = DateTime.Now;
                dr["Port"] = Injector.Port;
                dr["Treads_Max"] = Injector.Treads;
                dr["Status"] = "Not Validated";
                dr["State"] = false;
                dr["ID_Injector"] = Guid.NewGuid().ToString();
                oDataInjetor.Rows.Add(dr);
                oInjector.SalveManagerInjector(oDataInjetor);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void RemoveInjector(Stru_Injector Injector)
        {
            try
            {
                DataTable oDataInjetor = new DataTable();
                ConfigManager oInjector = new ConfigManager();
                oDataInjetor = oInjector.LoadManagerInjector();
                foreach (DataRow row in oDataInjetor.Rows)
                {
                    if (Injector.IPaddress == row["IPaddress"].ToString())
                    {
                        if (Injector.Port.ToString() == row["Port"].ToString())
                        {
                            oDataInjetor.Rows.Remove(row);
                        }
                    }
                }
                oInjector.SalveManagerInjector(oDataInjetor);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public DataTable ValidInjector()
        {
            try
            {
                DataTable oDataInjetor = new DataTable();
                ConfigManager oInjector = new ConfigManager();
                oDataInjetor = oInjector.LoadManagerInjector();

                Lib_Tools.Communications.Message oCommunication = new Lib_Tools.Communications.Message();

                int i = 0;
                foreach (DataRow RowInjector in oDataInjetor.Rows)
                {
                    try
                    {
                        if (oCommunication.TestConnet(
<<<<<<< HEAD
                            RowInjector["IPaddress"].ToString(),
                            int.Parse(RowInjector["Port"].ToString()))
                           )
                        {
                            oDataInjetor.Rows[i]["Status"] = "Valid. OK - " + DateTime.Now.ToString();
                            oDataInjetor.Rows[i]["State"] = true;
                         
                        }
                    }
                    catch (Exception ex)
                    {
                        oDataInjetor.Rows[i]["Status"] = "INVALID - " + DateTime.Now.ToString();
                        oDataInjetor.Rows[i]["State"] = false;
                        oDataInjetor.Rows[i]["SendReturn"] = ex.Message.ToString();
=======
                             RowInjector["IPaddress"].ToString(),
                             int.Parse(
                                 RowInjector["Port"].ToString()
                                 ))
                            )
                        {
                            oDataInjetor.Rows[i]["Status"] = "Valid. OK - " + DateTime.Now.ToString();
                            oDataInjetor.Rows[i]["State"] = true;
                        }
                    }
                    catch (Exception)
                    {
                        oDataInjetor.Rows[i]["Status"] = "INVALID - " + DateTime.Now.ToString();
                        oDataInjetor.Rows[i]["State"] = false;
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219
                    }
                    i++;
                }
                return oDataInjetor;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
