﻿using Lib_Tools.Structure;
using Lib_Tools.Table;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib_Tools.Procedure
{
    public class ProcessPlanTest
    {
        public void AddPlantest(Stru_PlanTest Plantest)
        {
            try
            {
                DataSet DtPlanTest = new DataSet();
                PlanTest oPlanTest = new PlanTest();
                DtPlanTest = oPlanTest.LoadListPlanTest();
                DataRow dr;
                dr = DtPlanTest.Tables[0].NewRow();
                DataTable tb = new DataTable("Plan");
                dr["Id_PlanTest"] = Plantest.Id_PlanTest;
                dr["Name"] = Plantest.Name;
                dr["Description"] = Plantest.Description;
                dr["QtdeRequest"] = Plantest.QtdeRequest;
                dr["QtdeUsers"] = Plantest.QtdeUsers;
                dr["DtCreate"] = DateTime.Now.ToString();
                dr["UserCreate"] = Plantest.UserCreate;
                dr["DtSchedule"] = Plantest.DtSchedule;
                DtPlanTest.Tables[0].Rows.Add(dr);
                oPlanTest.SalveManagerPlanTest(DtPlanTest);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
