﻿// See https://aka.ms/new-console-template for more information
using NetMQ;

ManagerInjetoras.Manager.Injector oInjector = new ManagerInjetoras.Manager.Injector();
ManagerInjetoras.Manager.ScreenMsg screenMsg = new ManagerInjetoras.Manager.ScreenMsg();

screenMsg.MountScreen();
screenMsg.CanvasSecreen("Injector Management.", 1, 2);
screenMsg.CanvasSecreen("Version: 1.0", 1, 80);
screenMsg.CanvasSecreen("Project........:", 3, 2);
screenMsg.CanvasSecreen("Requesting user:", 4, 2);
screenMsg.CanvasSecreen("Workstation....:", 5, 2);
screenMsg.CanvasSecreen("Task...........:", 7, 2);
screenMsg.CanvasSecreen("Command........:", 8, 2);
screenMsg.CanvasSecreen("Start..........:", 16, 2);

screenMsg.Message("Active.");
oInjector.execute();







