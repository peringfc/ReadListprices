﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagerInjetoras.Manager
{
    public class ScreenMsg
    {
        public void CanvasSecreen(string s, int lin, int col)
        {
            try
            {
                Console.SetCursorPosition( col, lin);
                Console.Write(s);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.SetCursorPosition(18,1);
                Console.Write(e.Message);
            }
        }

        public void MountScreen() 
        {
            Console.Clear();
            Console.WriteLine("+---------------------------------------------------------------------------------------------------+");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("+---------------------------------------------------------------------------------------------------+");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("|                                                                                                   |");
            Console.WriteLine("+---------------------------------------------------------------------------------------------------+");

        }


        public void Message(string Msg)
        {
            CanvasSecreen(Msg, 18, 2);
        }


    }
}
