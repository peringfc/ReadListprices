﻿namespace Orchestrator
{
    partial class FrmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabOrchestrator = new System.Windows.Forms.TabControl();
            this.tabInjector = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.oListInjectors = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tabWork = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.butPlanTest = new System.Windows.Forms.Button();
            this.lblip = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tabpa = new System.Windows.Forms.TabControl();
            this.tabPlanTest = new System.Windows.Forms.TabPage();
            this.DataGridPlanTest = new System.Windows.Forms.DataGridView();
            this.TabTest = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dataGridSelectInjector = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dataGridSelectFiles = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblUserValid = new System.Windows.Forms.Label();
            this.groupPlanTest = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.lblPosition = new System.Windows.Forms.Label();
            this.txtPosition = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textRequest = new System.Windows.Forms.TextBox();
            this.textQtdeUSer = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_id_plantest = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabOrchestrator.SuspendLayout();
            this.tabInjector.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.oListInjectors)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabWork.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabpa.SuspendLayout();
            this.tabPlanTest.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridPlanTest)).BeginInit();
            this.TabTest.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSelectInjector)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSelectFiles)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupPlanTest.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabOrchestrator
            // 
            this.tabOrchestrator.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabOrchestrator.Controls.Add(this.tabInjector);
            this.tabOrchestrator.Controls.Add(this.tabWork);
            this.tabOrchestrator.Controls.Add(this.tabPage7);
            this.tabOrchestrator.Dock = System.Windows.Forms.DockStyle.Right;
            this.tabOrchestrator.Location = new System.Drawing.Point(908, 0);
            this.tabOrchestrator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabOrchestrator.Multiline = true;
            this.tabOrchestrator.Name = "tabOrchestrator";
            this.tabOrchestrator.SelectedIndex = 0;
            this.tabOrchestrator.Size = new System.Drawing.Size(648, 639);
            this.tabOrchestrator.TabIndex = 0;
            // 
            // tabInjector
            // 
            this.tabInjector.Controls.Add(this.groupBox2);
            this.tabInjector.Controls.Add(this.groupBox1);
            this.tabInjector.Location = new System.Drawing.Point(30, 4);
            this.tabInjector.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabInjector.Name = "tabInjector";
            this.tabInjector.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabInjector.Size = new System.Drawing.Size(614, 631);
            this.tabInjector.TabIndex = 0;
            this.tabInjector.Text = "injectors";
            this.tabInjector.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.oListInjectors);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 67);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(608, 560);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "List";
            // 
            // oListInjectors
            // 
            this.oListInjectors.AllowUserToAddRows = false;
            this.oListInjectors.AllowUserToDeleteRows = false;
            this.oListInjectors.AllowUserToOrderColumns = true;
            this.oListInjectors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.oListInjectors.Dock = System.Windows.Forms.DockStyle.Fill;
            this.oListInjectors.Location = new System.Drawing.Point(3, 24);
            this.oListInjectors.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.oListInjectors.Name = "oListInjectors";
            this.oListInjectors.ReadOnly = true;
            this.oListInjectors.RowHeadersWidth = 51;
            this.oListInjectors.RowTemplate.Height = 25;
            this.oListInjectors.Size = new System.Drawing.Size(602, 532);
            this.oListInjectors.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(3, 4);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(608, 63);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(157, 25);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(94, 29);
            this.button4.TabIndex = 2;
            this.button4.Text = "Refresh";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(331, 24);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(86, 31);
            this.button7.TabIndex = 1;
            this.button7.Text = "Valid Injectors";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(7, 24);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 31);
            this.button1.TabIndex = 0;
            this.button1.Text = "Add +";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabWork
            // 
            this.tabWork.Controls.Add(this.dataGridView2);
            this.tabWork.Location = new System.Drawing.Point(30, 4);
            this.tabWork.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabWork.Name = "tabWork";
            this.tabWork.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabWork.Size = new System.Drawing.Size(614, 631);
            this.tabWork.TabIndex = 1;
            this.tabWork.Text = "Works in Progress";
            this.tabWork.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 4);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 25;
            this.dataGridView2.Size = new System.Drawing.Size(608, 623);
            this.dataGridView2.TabIndex = 1;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.dataGridView3);
            this.tabPage7.Controls.Add(this.txtLog);
            this.tabPage7.Location = new System.Drawing.Point(30, 4);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage7.Size = new System.Drawing.Size(614, 631);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "Log";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.Location = new System.Drawing.Point(3, 4);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 25;
            this.dataGridView3.Size = new System.Drawing.Size(608, 623);
            this.dataGridView3.TabIndex = 1;
            // 
            // txtLog
            // 
            this.txtLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLog.Location = new System.Drawing.Point(3, 4);
            this.txtLog.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.Size = new System.Drawing.Size(608, 623);
            this.txtLog.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.butPlanTest);
            this.groupBox3.Controls.Add(this.lblip);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Size = new System.Drawing.Size(908, 63);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dados do Orchestrator";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(657, 20);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(178, 31);
            this.button5.TabIndex = 7;
            this.button5.Text = "Refresh";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // butPlanTest
            // 
            this.butPlanTest.Location = new System.Drawing.Point(451, 20);
            this.butPlanTest.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butPlanTest.Name = "butPlanTest";
            this.butPlanTest.Size = new System.Drawing.Size(178, 31);
            this.butPlanTest.TabIndex = 6;
            this.butPlanTest.Text = "Mount Test Plan";
            this.butPlanTest.UseVisualStyleBackColor = true;
            this.butPlanTest.Click += new System.EventHandler(this.butPlanTest_Click);
            // 
            // lblip
            // 
            this.lblip.AutoSize = true;
            this.lblip.Location = new System.Drawing.Point(80, 25);
            this.lblip.Name = "lblip";
            this.lblip.Size = new System.Drawing.Size(21, 20);
            this.lblip.TabIndex = 1;
            this.lblip.Text = "IP";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Endereço";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tabpa);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Location = new System.Drawing.Point(0, 63);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Size = new System.Drawing.Size(908, 576);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Execution plan";
            // 
            // tabpa
            // 
            this.tabpa.Controls.Add(this.tabPlanTest);
            this.tabpa.Controls.Add(this.TabTest);
            this.tabpa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabpa.Location = new System.Drawing.Point(3, 24);
            this.tabpa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabpa.Name = "tabpa";
            this.tabpa.SelectedIndex = 0;
            this.tabpa.Size = new System.Drawing.Size(902, 548);
            this.tabpa.TabIndex = 1;
            // 
            // tabPlanTest
            // 
            this.tabPlanTest.Controls.Add(this.DataGridPlanTest);
            this.tabPlanTest.Location = new System.Drawing.Point(4, 29);
            this.tabPlanTest.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPlanTest.Name = "tabPlanTest";
            this.tabPlanTest.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPlanTest.Size = new System.Drawing.Size(894, 515);
            this.tabPlanTest.TabIndex = 1;
            this.tabPlanTest.Text = "Plan Test";
            this.tabPlanTest.UseVisualStyleBackColor = true;
            // 
            // DataGridPlanTest
            // 
            this.DataGridPlanTest.AllowUserToAddRows = false;
            this.DataGridPlanTest.AllowUserToDeleteRows = false;
            this.DataGridPlanTest.AllowUserToOrderColumns = true;
            this.DataGridPlanTest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridPlanTest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DataGridPlanTest.Location = new System.Drawing.Point(3, 4);
            this.DataGridPlanTest.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DataGridPlanTest.Name = "DataGridPlanTest";
            this.DataGridPlanTest.ReadOnly = true;
            this.DataGridPlanTest.RowHeadersWidth = 51;
            this.DataGridPlanTest.RowTemplate.Height = 25;
            this.DataGridPlanTest.Size = new System.Drawing.Size(888, 507);
            this.DataGridPlanTest.TabIndex = 1;
            this.DataGridPlanTest.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridPlanTest_CellClick);
            this.DataGridPlanTest.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridPlanTest_CellContentClick);
            this.DataGridPlanTest.DoubleClick += new System.EventHandler(this.DataGridPlanTest_DoubleClick);
            // 
            // TabTest
            // 
            this.TabTest.Controls.Add(this.groupBox7);
            this.TabTest.Controls.Add(this.groupBox6);
            this.TabTest.Controls.Add(this.groupBox5);
            this.TabTest.Location = new System.Drawing.Point(4, 29);
            this.TabTest.Name = "TabTest";
            this.TabTest.Padding = new System.Windows.Forms.Padding(3);
            this.TabTest.Size = new System.Drawing.Size(894, 515);
            this.TabTest.TabIndex = 2;
            this.TabTest.Text = "Teste";
            this.TabTest.UseVisualStyleBackColor = true;
            this.TabTest.Click += new System.EventHandler(this.TabTest_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dataGridSelectInjector);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(3, 159);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(888, 132);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Injectores";
            // 
            // dataGridSelectInjector
            // 
            this.dataGridSelectInjector.AllowUserToAddRows = false;
            this.dataGridSelectInjector.AllowUserToOrderColumns = true;
            this.dataGridSelectInjector.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridSelectInjector.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridSelectInjector.Location = new System.Drawing.Point(3, 23);
            this.dataGridSelectInjector.Name = "dataGridSelectInjector";
            this.dataGridSelectInjector.ReadOnly = true;
            this.dataGridSelectInjector.RowHeadersWidth = 51;
            this.dataGridSelectInjector.RowTemplate.Height = 29;
            this.dataGridSelectInjector.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridSelectInjector.Size = new System.Drawing.Size(882, 106);
            this.dataGridSelectInjector.TabIndex = 1;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dataGridSelectFiles);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox6.Location = new System.Drawing.Point(3, 291);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(888, 221);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Files";
            // 
            // dataGridSelectFiles
            // 
            this.dataGridSelectFiles.AllowUserToAddRows = false;
            this.dataGridSelectFiles.AllowUserToOrderColumns = true;
            this.dataGridSelectFiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridSelectFiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridSelectFiles.Location = new System.Drawing.Point(3, 23);
            this.dataGridSelectFiles.Name = "dataGridSelectFiles";
            this.dataGridSelectFiles.ReadOnly = true;
            this.dataGridSelectFiles.RowHeadersWidth = 51;
            this.dataGridSelectFiles.RowTemplate.Height = 29;
            this.dataGridSelectFiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridSelectFiles.Size = new System.Drawing.Size(882, 195);
            this.dataGridSelectFiles.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblUserValid);
            this.groupBox5.Controls.Add(this.groupPlanTest);
            this.groupBox5.Controls.Add(this.textRequest);
            this.groupBox5.Controls.Add(this.textQtdeUSer);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.txt_id_plantest);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.textName);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox5.Location = new System.Drawing.Point(3, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(888, 156);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Plan Test";
            // 
            // lblUserValid
            // 
            this.lblUserValid.AutoSize = true;
            this.lblUserValid.Location = new System.Drawing.Point(777, 20);
            this.lblUserValid.Name = "lblUserValid";
            this.lblUserValid.Size = new System.Drawing.Size(17, 20);
            this.lblUserValid.TabIndex = 24;
            this.lblUserValid.Text = "0";
            // 
            // groupPlanTest
            // 
            this.groupPlanTest.Controls.Add(this.button8);
            this.groupPlanTest.Controls.Add(this.button6);
            this.groupPlanTest.Controls.Add(this.lblPosition);
            this.groupPlanTest.Controls.Add(this.txtPosition);
            this.groupPlanTest.Controls.Add(this.button3);
            this.groupPlanTest.Controls.Add(this.button2);
            this.groupPlanTest.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupPlanTest.Location = new System.Drawing.Point(3, 85);
            this.groupPlanTest.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupPlanTest.Name = "groupPlanTest";
            this.groupPlanTest.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupPlanTest.Size = new System.Drawing.Size(882, 68);
            this.groupPlanTest.TabIndex = 23;
            this.groupPlanTest.TabStop = false;
            this.groupPlanTest.Visible = false;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(455, 21);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(169, 31);
            this.button8.TabIndex = 24;
            this.button8.Text = "Prepare Environment";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button6
            // 
<<<<<<< HEAD
=======
            this.button6.Enabled = false;
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219
            this.button6.Location = new System.Drawing.Point(630, 20);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(99, 31);
            this.button6.TabIndex = 23;
            this.button6.Text = "Execute";
            this.button6.UseVisualStyleBackColor = true;
<<<<<<< HEAD
            this.button6.Click += new System.EventHandler(this.button6_Click_3);
=======
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Location = new System.Drawing.Point(263, 24);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(73, 20);
            this.lblPosition.TabIndex = 22;
            this.lblPosition.Text = "Injectores";
            // 
            // txtPosition
            // 
            this.txtPosition.FormattingEnabled = true;
            this.txtPosition.Items.AddRange(new object[] {
            "Internal",
            "External"});
            this.txtPosition.Location = new System.Drawing.Point(342, 22);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(107, 28);
            this.txtPosition.TabIndex = 21;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(131, 16);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 31);
            this.button3.TabIndex = 1;
            this.button3.Text = "Mass of data";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 16);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(116, 31);
            this.button2.TabIndex = 0;
            this.button2.Text = "Select Robos";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // textRequest
            // 
            this.textRequest.Location = new System.Drawing.Point(618, 56);
            this.textRequest.Name = "textRequest";
            this.textRequest.ReadOnly = true;
            this.textRequest.Size = new System.Drawing.Size(136, 27);
            this.textRequest.TabIndex = 22;
            this.textRequest.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textQtdeUSer
            // 
            this.textQtdeUSer.Location = new System.Drawing.Point(618, 20);
            this.textQtdeUSer.Name = "textQtdeUSer";
            this.textQtdeUSer.ReadOnly = true;
            this.textQtdeUSer.Size = new System.Drawing.Size(136, 27);
            this.textQtdeUSer.TabIndex = 21;
            this.textQtdeUSer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(534, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 20);
            this.label5.TabIndex = 20;
            this.label5.Text = "Qtde. User";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(510, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 20);
            this.label6.TabIndex = 18;
            this.label6.Text = "Qtde. Request";
            // 
            // txt_id_plantest
            // 
            this.txt_id_plantest.Location = new System.Drawing.Point(124, 56);
            this.txt_id_plantest.Name = "txt_id_plantest";
            this.txt_id_plantest.ReadOnly = true;
            this.txt_id_plantest.Size = new System.Drawing.Size(380, 27);
            this.txt_id_plantest.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "Id Plan Test";
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(124, 20);
            this.textName.Name = "textName";
            this.textName.ReadOnly = true;
            this.textName.Size = new System.Drawing.Size(380, 27);
            this.textName.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Name Test";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1556, 639);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.tabOrchestrator);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Orchestrator";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tabOrchestrator.ResumeLayout(false);
            this.tabInjector.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.oListInjectors)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.tabWork.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.tabpa.ResumeLayout(false);
            this.tabPlanTest.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridPlanTest)).EndInit();
            this.TabTest.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSelectInjector)).EndInit();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridSelectFiles)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupPlanTest.ResumeLayout(false);
            this.groupPlanTest.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tabOrchestrator;
        private TabPage tabInjector;
        private GroupBox groupBox2;
        private GroupBox groupBox1;
        private Button button1;
        private TabPage tabWork;
        private TabPage tabPage7;
        private TextBox txtLog;
        private Button button7;
        private GroupBox groupBox3;
        private Label lblip;
        private Label label1;
        private GroupBox groupBox4;
        private DataGridView oListInjectors;
        private DataGridView dataGridView2;
        private DataGridView dataGridView3;
        private TabControl tabpa;
        private TabPage tabPlanTest;
        private DataGridView DataGridPlanTest;
        private Button button4;
        private Button butPlanTest;
        private Button button5;
        private TabPage TabTest;
        private GroupBox groupBox7;
        private DataGridView dataGridSelectInjector;
        private GroupBox groupBox6;
        private DataGridView dataGridSelectFiles;
        private GroupBox groupBox5;
        private TextBox textName;
        private Label label2;
        private TextBox txt_id_plantest;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textRequest;
        private TextBox textQtdeUSer;
        private GroupBox groupPlanTest;
        private Button button3;
        private Button button2;
        private Label lblPosition;
        private ComboBox txtPosition;
        private Button button8;
        private Button button6;
        private Label lblUserValid;
    }
}