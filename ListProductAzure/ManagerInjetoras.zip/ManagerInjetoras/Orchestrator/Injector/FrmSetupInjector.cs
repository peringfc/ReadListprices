﻿using Lib_Tools.Procedure;
using Lib_Tools.Structure;
using NetMQ;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;
<<<<<<< HEAD
using Lib_Tools.Tools;
=======
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219

namespace Orchestrator.Injector
{
    public partial class FrmSetupInjector : Form
    {

        Lib_Tools.Communications.Message oCommunication = new Lib_Tools.Communications.Message();
        Lib_Tools.Structure.Stru_Message oMessage = new Lib_Tools.Structure.Stru_Message();

        public FrmSetupInjector()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (oCommunication.TestConnet(txtIP.Text, int.Parse(txtIPPort.Text)))
                {
                    try
                    {
                        string Machine = "tcp://" + txtIP.Text + ":" + txtIPPort.Text;
                        oMessage.DtCreate = DateTime.Now;
                        oMessage.Id_Message_Send = Guid.NewGuid().ToString();
                        oMessage.Id_Message_Return = "-";
                        oMessage.IPaddress_Send = "--";
                        oMessage.Operation = "Valid Inject";
                        oMessage.Operation_Message = "Test";
                        Stru_Message Send_Message = JsonConvert.DeserializeObject<Stru_Message>(oCommunication.sendMsg(Machine, oMessage));
                        lblStatus.Text = Send_Message.Operation_Message;
                        LblID.Text = Send_Message.Id_Message_Return;
                        LblDateCreate.Text = Send_Message.DtCreate.ToString();
                        lblState.Text = Send_Message.Operation;
                        if (lblStatus.Text == "Inject Valid - OK")
                        {
                            butSalve.Visible = true;
<<<<<<< HEAD
=======



>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219
                        }
                        else
                        {
                            butSalve.Visible = false;
                        }

                    }
                    catch (Exception ex)
                    {
                        lblStatus.Text = "Error";
                        LblID.Text = ex.Message.ToString();
                        LblDateCreate.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }


        private void ValidInjector()
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtServer.Text.TrimStart().TrimEnd().Trim() == "")
            {
                MessageBox.Show(lblName.Text + " Mandatory!!");
                txtServer.SelectAll();
                txtServer.Focus();
            }
            else
            {

                
                if (txtTreads.Text.TrimStart().TrimEnd().Trim() == "")
                {
                    MessageBox.Show(lblTreads.Text + " Mandatory!!");
                    txtServer.SelectAll();
                    txtServer.Focus();
                }
                else
                {
                    if (txtPosition.Text.TrimStart().TrimEnd().Trim() == "")
                    {
                        MessageBox.Show(lblTreads.Text + " Mandatory!!");
                        txtServer.SelectAll();
                        txtServer.Focus();
                    }
                    else
                    {
                        try
                        {
                            ProcessInjector oProcessInjector = new ProcessInjector();
                            Stru_Injector AddInjetor = new Stru_Injector();
                            AddInjetor.Injector = txtServer.Text;
                            AddInjetor.NameMachine = txtdesc.Text;
                            AddInjetor.IPaddress = txtIP.Text;
                            AddInjetor.Port = int.Parse(txtIPPort.Text);
                            AddInjetor.Treads = int.Parse(txtTreads.Text);
                            AddInjetor.Position = txtPosition.Text;
                            
                            oProcessInjector.AddInjector(AddInjetor);
                            MessageBox.Show(lblName.Text + " " + txtServer.Text + " Successfully registered !!!");
                            Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error:" + ex.Message.ToString());
                        }
                    }
                }
            }
        }
<<<<<<< HEAD

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (oCommunication.TestConnet(txtIP.Text, int.Parse(txtIPPort.Text)))
                {
                    try
                    {
                        string Machine = "tcp://" + txtIP.Text + ":" + txtIPPort.Text;
                        oMessage.DtCreate = DateTime.Now;
                        oMessage.Id_Message_Send = Guid.NewGuid().ToString();
                        oMessage.Id_Message_Return = "-";
                        oMessage.IPaddress_Send = "--";
                        oMessage.Operation = "Infrastructure";
                        oMessage.Operation_Message = "---";
                        Stru_Message Send_Message = JsonConvert.DeserializeObject<Stru_Message>(oCommunication.sendMsg(Machine, oMessage));
                        lblStatus.Text = Send_Message.Operation;
                        LblID.Text = Send_Message.Id_Message_Return;
                        LblDateCreate.Text = Send_Message.DtCreate.ToString();
                        lblState.Text = Send_Message.Operation;
                        txtdesc.Text = Send_Message.Operation_Message;

                        if (lblStatus.Text == "Infrastructure - Return")
                        {
                            butSalve.Visible = true;
                        }
                        else
                        {
                            butSalve.Visible = false;
                        }

                    }
                    catch (Exception ex)
                    {
                        lblStatus.Text = "Error";
                        LblID.Text = ex.Message.ToString();
                        LblDateCreate.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
=======
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219
    }
}
