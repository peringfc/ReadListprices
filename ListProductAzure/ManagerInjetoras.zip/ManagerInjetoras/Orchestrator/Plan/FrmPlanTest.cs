﻿using Lib_Tools.Structure;
using Lib_Tools.Table;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Orchestrator.Plan
{
    public partial class FrmPlanTest : Form
    {
        public FrmPlanTest()
        {
            InitializeComponent();
            textDtCreate.Text = DateTime.Now.ToString();
            textName.Focus();
            txt_id_plantest.Text = Guid.NewGuid().ToString();
            textUser.Text = Environment.UserName + " - " + Environment.UserDomainName;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Lib_Tools.Procedure.ProcessPlanTest oProcessPlanTest = new Lib_Tools.Procedure.ProcessPlanTest();
                Stru_PlanTest oPlanTest = new Stru_PlanTest();
                oPlanTest.Id_PlanTest = txt_id_plantest.Text;
                oPlanTest.Name = textName.Text;
                oPlanTest.Description = txtDescription.Text;
                oPlanTest.QtdeRequest = int.Parse(textRequest.Value.ToString());
                oPlanTest.QtdeUsers = int.Parse(textQtdeUSer.Value.ToString());
                oPlanTest.DtSchedule = txtDtSchedule.Value;

                oPlanTest.UserCreate = textUser.Text;
                oProcessPlanTest.AddPlantest(oPlanTest);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
