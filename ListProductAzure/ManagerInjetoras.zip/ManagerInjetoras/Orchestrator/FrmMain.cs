using Lib_Tools.Procedure;
using Lib_Tools.Structure;
using Lib_Tools.Table;
using NetMQ;
using Newtonsoft.Json;
using Orchestrator.Injector;
using Orchestrator.Plan;
using System;
using System.Data;
<<<<<<< HEAD
using System.IO;
=======
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219
using System.Net;

namespace Orchestrator
{
    public partial class FrmMain : Form
    {
        Lib_Tools.Communications.Message oCommunication = new Lib_Tools.Communications.Message();
        Lib_Tools.Structure.Stru_Message oMessage = new Lib_Tools.Structure.Stru_Message();
        Lib_Tools.Table.PlanTest oPlanTest = new Lib_Tools.Table.PlanTest();

        List<StruFiles> ListFiles = new List<StruFiles>();
        DataTable oDataInjetor = new DataTable();

        DataSet DtsPlanTest = new DataSet();
        DataSet DtsTest = new DataSet();

        public FrmMain()
        {
            InitializeComponent();
            // Carregando dados 
            loadScreen();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            send();
        }


        private void send()
        {
            //string oServer = "tcp://127.0.0.1:5556";
//            string oMsg = txtRobo.Text;
            //lblStart.Text = oCommunication.sendMsg(oServer, oMsg); 
//            txtLog.Text = txtLog.Text + lblStart.Text + "\n";
            try
            {
                //                string Machine = "tcp://" + txtIP.Text + ":" + txtIPPort.Text;
                oMessage.DtCreate = DateTime.Now;
                oMessage.Id_Message_Send = Guid.NewGuid().ToString();
                oMessage.Id_Message_Return = "-";
                oMessage.IPaddress_Send = "--";
                oMessage.Operation = "Run Planned Test";
                oMessage.Operation_Message = "Test";

                //Stru_Message Send_Message = JsonConvert.DeserializeObject<Stru_Message>(oCommunication.sendMsg(Machine, oMessage));

                //lblStatus.Text = Send_Message.Operation_Message;
                //LblID.Text = Send_Message.Id_Message_Return;
                //LblDateCreate.Text = Send_Message.DtCreate.ToString();
                //lblState.Text = Send_Message.Operation;

            }
            catch (Exception ex)
            {
                //lblStatus.Text = "Error";
                //LblID.Text = ex.Message.ToString();
                //LblDateCreate.Text = "";
            }

        }

        private void button6_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmSetupInjector frmSetupInjector = new FrmSetupInjector();
            frmSetupInjector.ShowDialog(this);
            frmSetupInjector.Dispose();
            LoadDataInjector();
        }

        private void button3_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void SelectFile(string TypeFile)
        {
            var fileContent = string.Empty;
            var filePath = string.Empty;

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                //openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    //Get the path of specified file
                    filePath = openFileDialog.FileName;

                    DataRow dr;
                    dr = DtsTest.Tables["PlanFile"].NewRow();

                    dr["Id_File"] = Guid.NewGuid().ToString();
                    dr["Id_PlanTest"] = txt_id_plantest.Text;
                    dr["Status"] = "Select File";
                    dr["Name"] = openFileDialog.SafeFileName.ToString();
                    dr["Path"] = openFileDialog.FileName;
                    dr["Size"] = DateTime.Now.ToString();
                    dr["Type"] = TypeFile;
                    dr["UserCreate"] = Environment.UserName + " - " + Environment.UserDomainName;
                    dr["DtCreate"] = DateTime.Now;
                    DtsTest.Tables["PlanFile"].Rows.Add(dr);
                    oPlanTest.SalvePlanTest(DtsTest, txt_id_plantest.Text);
                    LoadPlanner();
                    LoadPlanTest();
                }
            }
        }

        private void loadScreen()
        {
            LoadPlanTest();
            LoadDataInjector();
            LoadInjector();
        }
        private void LoadPlanner()
        {
            // dataFiles.DataSource = 
        }

        private void LoadInjector()
        {
            oListInjectors.DataSource = oDataInjetor;
            oListInjectors.Refresh();
            oListInjectors.ReadOnly = true;
        }

        private void LoadDataInjector()
        {
            ConfigManager oInjector = new ConfigManager();
            oDataInjetor = oInjector.LoadManagerInjector();
            LoadInjector();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                ValidInjector();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                ValidInjector();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void ValidInjector()
        {
            ProcessInjector oProcessInjector = new ProcessInjector();
            oDataInjetor = oProcessInjector.ValidInjector();
            LoadInjector();
        }

        private void LoadPlanTest()
        {
            DtsPlanTest = oPlanTest.LoadListPlanTest();
            DataGridPlanTest.DataSource = DtsPlanTest.Tables[0];
            DataGridPlanTest.Refresh();
        }

        private void LoadTest(String id_test)
        {
            DtsTest = oPlanTest.LoadPlanTest(id_test);
            dataGridSelectInjector.DataSource = DtsTest.Tables["PlanFile"];
            dataGridSelectFiles.DataSource = DtsTest.Tables["PlanInjetor"];
            dataGridSelectFiles.Refresh();
            dataGridSelectInjector.Refresh();
        }

        private void butPlanTest_Click(object sender, EventArgs e)
        {
            FrmPlanTest oFrmPlanTest = new FrmPlanTest();
            oFrmPlanTest.ShowDialog();
            oFrmPlanTest.Dispose();
            groupPlanTest.Visible = true;
            LoadPlanTest();
        }

        private void button6_Click_2(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            LoadPlanTest();
        }

        private void TabTest_Click(object sender, EventArgs e)
        {

        }

        private void DataGridPlanTest_DoubleClick(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SelectFile("Robo");
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            SelectFile("Mass of data");
        }

        private void DataGridPlanTest_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SelectPlantTeste(sender, e); 
        }

        private void DataGridPlanTest_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SelectPlantTeste(sender, e);
        }

        private void SelectPlantTeste(object sender, DataGridViewCellEventArgs e) 
        {
            textName.Text = DataGridPlanTest.Rows[e.RowIndex].Cells["Name"].Value.ToString();
            textQtdeUSer.Text = DataGridPlanTest.Rows[e.RowIndex].Cells["QtdeUsers"].Value.ToString();
            textRequest.Text = DataGridPlanTest.Rows[e.RowIndex].Cells["QtdeRequest"].Value.ToString();
            txt_id_plantest.Text = DataGridPlanTest.Rows[e.RowIndex].Cells["Id_PlanTest"].Value.ToString();
            LoadTest(txt_id_plantest.Text);
            tabpa.SelectedTab = TabTest;
            groupPlanTest.Visible = true;
            LoadPlanTest();
        }

        private void button8_Click(object sender, EventArgs e)
        {

            lblUserValid.Text = "0";
            if (txtPosition.Text.Trim().TrimEnd().TrimStart() == "")
            {
                MessageBox.Show("Selecting the type of injectors is mandatory !!");
                txtPosition.Focus();
            }
            else
            {
                try
                {
                    ValidInjector();

                    foreach (DataRow Iinjetor in oDataInjetor.Rows)
                    {
                        if (Iinjetor["State"].ToString() == "True")
                        {
                            if (txtPosition.Text == Iinjetor["Position"].ToString())
                            {
                                lblUserValid.Text = (int.Parse(lblUserValid.Text) + int.Parse(Iinjetor["Treads_Max"].ToString())).ToString();
                            }
                        }
                    }

                    if (int.Parse(textQtdeUSer.Text) >= int.Parse(lblUserValid.Text))
                    {
<<<<<<< HEAD
                        MessageBox.Show($"Required processing capacity is {textQtdeUSer.Text}" +
                            $" and available capacity is {lblUserValid.Text}");
=======
                        MessageBox.Show($"Required processing capacity is {textQtdeUSer.Text} and available capacity is {lblUserValid.Text}");
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219
                    }
                    else
                    {
                        MessageBox.Show("Capacity available, File Copy will start - Environment Preparation will Start");
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void PrepareEnvironment()
        { 
        
             // Processo Copia de Robos pra ambiente 
             // Processo de Copia de Massa de dados 
             // Relacioamento de Injetoraas do ambiente
             // Liberar ambiente para execução do Teste.
            
        
        
        }
<<<<<<< HEAD

        private void button6_Click_3(object sender, EventArgs e)
        {
            try
            {
                string ofile = @"D:\Performance\jmx\mydatabase\mydatabase.jmx";

                string readText = File.ReadAllText(ofile);

                string Machine = "tcp://127.0.0.1:5556";
                oMessage.DtCreate = DateTime.Now;
                oMessage.Id_Message_Send = Guid.NewGuid().ToString();
                oMessage.Id_Message_Return = "-";
                oMessage.IPaddress_Send = "--";
                oMessage.Operation = "Copy Robo";
                oMessage.Operation_Message = readText;

                Stru_Message Send_Message = JsonConvert.DeserializeObject<Stru_Message>(oCommunication.sendMsg(Machine, oMessage));

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
=======
>>>>>>> 154f076d5cc3156474913fdba56a0faa7aceb219
    }
}